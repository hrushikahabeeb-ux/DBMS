# Expo Demonstration Guide

Everything below runs against real services and MongoDB data. Nothing is mocked.

## Before visitors arrive (2 minutes)

1. Start the stack (`docker compose up -d` or `./run_local.sh`).
2. Reset data: **Settings > Expo demo mode > Reset demo data** as `admin@smartshift.ai`, or `python -m scripts.seed`.
3. Open two browser windows: one signed in as **er.manager@smartshift.ai / Manager@123**, one private window ready for **ananya.sharma@smartshift.ai / Employee@123**.
4. Open **Settings** and confirm all six service rows show `ok` (API, optimizer, worker, notifications, analytics, Redis queue).

The seed creates 30 employees in three departments, three weeks of published schedules produced by the optimizer, approved and pending leave, a pending swap, and an **empty Emergency draft for next week** which is the live generation target.

## The ten-step workflow

| Step | Where | What to do | What to point out |
|---|---|---|---|
| 1 | Overview | Show KPIs, weekly distribution, coverage heatmap, alerts | All numbers are aggregation pipelines over MongoDB; next week's Emergency draft shows as open (red) |
| 2 | AI Schedule Generator | Department Emergency, next week's draft, keep all three presets, click **Generate schedule** | Job goes to Redis, the worker calls the optimizer service; progress bar follows the real job state |
| 3 | Same page | Walk through the comparison table and charts; apply **Balanced**; publish | 100% coverage, zero violations; round robin shows hard violations; Balanced beats greedy on preferences and cost; Well-being has the highest fairness |
| 4 | Shift Planner | Filter Emergency, go to next week, drag a Morning assignment down to the Night slot | Backend rejects it: "Only 0h rest next to ..."; the calendar reverts. Click an assignment to show **Why was this employee assigned?** |
| 5 | Emergency Replacement | Mark an upcoming published assignment absent ("Called in sick") | The slot is released inside a transaction |
| 6 | Same page | Expand the top candidate | Every hard check passes; score breakdown and formula are visible; ruled-out colleagues show reasons |
| 7 | Same page | Click **Approve** | Re-validated in a transaction; a second approval attempt would be refused; both employees notified live |
| 8 | Employee window | Sign in as Ananya; open **My Schedule** | Only her published shifts are visible; the bell shows new notifications over WebSocket |
| 9 | Shift Swaps (employee) | New swap request on an upcoming shift, pick a colleague | Backend validates both sides before the request is created; the colleague accepts, the manager approves atomically |
| 10 | Workforce Analytics | Show coverage, utilization, hours, night/weekend distribution, fairness score, optimization comparison; export CSV | Fairness formula is printed under the score; comparison table is the stored run |

## Five-minute live script

**0:00 - Problem (30 s).** "Hospitals schedule hundreds of shifts a month by hand. Hidden rule violations, unfair night shifts and last-minute sick calls are constant. SmartShift AI treats this as a constraint optimization problem."

**0:30 - Dashboard (30 s).** Overview page. "Live data from MongoDB. Next week's Emergency department has no schedule yet."

**1:00 - Generate (60 s).** AI Schedule Generator, generate with three presets. "This is Google OR-Tools CP-SAT, the same solver family used in industrial planning. Rest periods, weekly limits, qualifications, leave and availability are hard constraints; fairness, preferences and cost are weighted objectives." Point at the table: "Every preset has zero violations. The naive round-robin approach most teams use breaks rest rules. Balanced mode satisfies 100% of stated preferences and is cheaper than greedy. Well-being spreads night shifts most evenly." Apply Balanced, publish.

**2:00 - Safety and explainability (45 s).** Shift Planner: drag a morning shift onto the night slot. "The backend refuses: only zero hours of rest." Click an assignment: "Why was this nurse assigned? Here are the exact checks the optimizer used."

**2:45 - Emergency recovery (60 s).** Emergency Replacement: mark a nurse absent. "Within a second we get every colleague checked against all rules and ranked by a transparent score." Approve the top candidate. Switch to the employee window: the notification arrives in real time.

**3:45 - Employee self-service (30 s).** In the employee window show My Schedule and request a swap. "The swap is validated for both people before it is even sent."

**4:15 - Analytics and architecture (45 s).** Workforce Analytics: fairness score with its formula, coverage heatmap, CSV export. Settings: the six services. "Five independent processes communicate over authenticated HTTP and a Redis queue, with MongoDB transactions protecting every multi-document change. Forty automated tests, including concurrency tests, verify it."

## Screenshots to capture for the report

Overview (dark and light), generator results table and charts, planner week view, conflict dialog after an invalid drag, explain dialog, emergency candidates with an expanded breakdown, employee dashboard, swap workflow, analytics page, settings service-health card, Swagger UI at `/docs`.

## If something goes wrong

- **Optimizer row is down in Settings:** generation jobs stay queued and are retried up to three times; restart the optimizer and they complete.
- **Redis down:** the API returns a clear 503 for generation; notifications are written directly to MongoDB.
- **Data drifted during rehearsals:** reset demo data (step 2 of preparation).
