# Course Outcome Mapping - SmartShift AI

Status legend: **Verified** = implemented and exercised by automated tests or a recorded run in the development environment. **Implemented, not executed** = code/configuration exists but could not be run in the development environment. Nothing is marked complete without evidence.

Development environment used for verification: Python 3.13, MongoDB 8.0.23 (single-node replica set `rs0`), Redis 7, Node 22, Chromium (Playwright) for UI checks. Test command: `cd backend && pytest -q` -> **40 passed**.

---

## CO1 - Database Implementation and Operations (15 marks)

| Requirement | Implementation | Source files | Status |
|---|---|---|---|
| Database creation and configuration | Idempotent initializer creates 13 collections with strict `$jsonSchema` validators, indexes and default rules | `backend/app/database/init_db.py`, `schema.py` | Verified |
| At least 10 meaningful collections | 13: users, employees, departments, shifts, schedules, assignments, availability, leave_requests, swap_requests, notifications, scheduling_rules, optimization_runs, audit_logs | `app/database/mongo.py` | Verified |
| CRUD | Employees, departments, users, schedules, assignments, availability, leave, swaps | `app/api/*.py` | Verified |
| Validation and schema enforcement | Pydantic at the API; `$jsonSchema` (`validationLevel: strict`) in MongoDB | `app/schemas/models.py`, `app/database/schema.py` | Verified |
| One-to-many and many-to-many | department->schedules->shifts->assignments (references); employees.department_ids <-> departments; users.managed_department_ids <-> departments; `$lookup` joins | `schema.py`, `api/departments.py`, `analytics_service.py` | Verified |
| Aggregation pipelines | Overview KPIs, coverage heatmap, hours/overtime by ISO week, utilization, labour cost, leave trends, shortages, profile hours history | `app/entrypoints/analytics_service.py`, `api/employees.py` | Verified |
| Indexing and query optimization | 35 indexes (plus _id) incl. compound, multikey, text and partial indexes | `app/database/schema.py` | Verified |
| Unique constraints | employee_code, emails, department code/name, (department, start_date), (schedule, date, template), partial unique active (shift, employee), partial unique open swap per assignment, notification dedupe | `schema.py` | Verified |
| Sorting, filtering, pagination | `GET /api/employees?search&department_id&skill&status&sort&page&page_size`; schedules, leave, audit logs | `api/employees.py`, `utils/ids.py` | Verified |
| Atomic operations and transactions | Conditional `$inc` capacity guard; `with_transaction` for every multi-document change; employee `version` bump for write-conflict serialization | `app/services/assignment_service.py`, `schedule_service.py`, `workflow_service.py`, `database/mongo.py` | Verified |
| Backup and restore | `mongodump`/`mongorestore` commands (local, Atlas, Docker) | `README.md` section 12 | Documented (commands not executed here) |
| Explain-plan comparison | Each query explained with forced COLLSCAN vs planner-chosen index | `app/database/explain.py`, `GET /api/analytics/query-performance` | Verified |

**API endpoints:** `/api/employees*`, `/api/departments*`, `/api/schedules*`, `/api/assignments*`, `/api/analytics/*`, `/api/audit-logs`.

**MongoDB operations used:** `insert_one/many`, `find`, `find_one_and_update`, `update_one/many` with `$set/$inc/$push/$addToSet`, `delete_one/many`, `count_documents`, `distinct`, `aggregate` with `$match/$lookup (pipeline form)/$group/$project/$addFields/$unwind/$dateToString/$map/$filter/$sort/$skip/$limit`, `create_indexes`, `collMod`, `explain`, sessions and transactions.

**Tests:** `test_employee_crud_and_validation`, `test_mongodb_schema_validation_rejects_bad_documents`, `test_department_crud`, `test_concurrent_assignments_cannot_overfill_or_double_book`, `test_analytics_gateway_and_aggregations` (asserts every explained query uses an index), `test_audit_log_written`.

**Demonstration:** `python -m scripts.co1_demo` regenerates [CO1_RESULTS.md](CO1_RESULTS.md) from live queries.

**Actual results (from CO1_RESULTS.md):**

| Query | Docs examined, COLLSCAN | Docs examined, indexed | Index | Reduction |
|---|---:|---:|---|---:|
| Employee assignments in a 14-day window | 484 | 4 | employee_start | 121x |
| Active employees of a department | 30 | 13 | dept_status | 2.3x |
| Shifts of a schedule ordered by start | 252 | 21 | schedule_start | 12x |
| Unread notifications for a user | 37 | 1 | user_unread | 37x |
| Department assignments by date and status | 484 | 32 | dept_start_status | 15.1x |

Transaction demo: a callback that wrote two documents and then raised left both unchanged (version 1 -> 1, 0 audit rows); the committed variant applied both. Invalid documents were rejected by the validator with code 121.

**Screenshots to capture:** Swagger employees list with filters; `docs/CO1_RESULTS.md`; MongoDB Compass showing validators and indexes; analytics page.

**Completion:** Verified (backup/restore documented).

---

## CO2 - Backend and REST API Development (15 marks)

| Requirement | Implementation | Status |
|---|---|---|
| RESTful CRUD APIs | 67 operations across 9 routers on the main API | Verified |
| GET, POST, PUT/PATCH, DELETE | e.g. `GET/POST /employees`, `PATCH /employees/{id}`, `DELETE /employees/{id}`, `PUT /availability`, `PUT /rules`, `DELETE /assignments/{id}` | Verified |
| Pydantic request/response validation | `app/schemas/models.py` (field constraints, custom validators, `Page[T]`, `EmployeeOut`, `UserOut`, `TokenResponse`); optimizer contract in `app/optimization/types.py` | Verified |
| JWT authentication | `app/core/security.py`, `/api/auth/login`, `/api/auth/token` (OAuth2 for Swagger), `/api/auth/register` | Verified |
| Role-based authorization | `require_roles`, `require_admin`, `require_manager`, `CurrentUser.require_department` (department scope) | Verified |
| Proper HTTP status codes | 200, 201, 202 (queued jobs), 204, 401, 403, 404, 409 (conflicts/duplicates), 422 (validation), 503 (dependency down) | Verified |
| Centralized exception handling | `app/core/errors.py`: consistent `{error: {code, message, details, correlation_id}}` | Verified |
| Pagination, filtering, sorting | `Page` model, `page_meta`, `parse_sort` with whitelist | Verified |
| OpenAPI/Swagger | `/docs` on every service; exported `docs/openapi-main-api.json` | Verified |
| Modular routers and services | `app/api/*` (HTTP), `app/services/*` (business logic), `app/optimization/*` (engine) | Verified |
| Environment-based configuration | `pydantic-settings` in `app/core/config.py`, `.env.example` | Verified |
| Automated API tests | `tests/test_api.py` (20 tests) via HTTPX ASGI transport against real MongoDB/Redis | Verified |
| Postman collection | `docs/postman/SmartShift-AI.postman_collection.json` (67 requests, login script stores the token) | Generated; not run in Postman here |

**Tests:** `test_login_success_and_failure`, `test_protected_routes_require_token`, `test_passwords_are_hashed`, `test_role_permissions`, `test_department_scoped_authorization`, `test_register_requires_existing_employee`, `test_employee_crud_and_validation` (422 with field list, 409 duplicate), plus the workflow tests below.

**Demonstration:** open `http://localhost:8000/docs`, authorize with `er.manager@smartshift.ai`, call `GET /api/employees?skill=ACLS&sort=-hourly_wage&page=1&page_size=5`, then try an ICU department filter to show 403.

**Screenshots:** Swagger UI; a 409 conflict body with failed checks; 403 for out-of-scope department.

**Completion:** Verified.

---

## CO3 - Distributed Backend and Integration (15 marks)

| Requirement | Implementation | Status |
|---|---|---|
| Main API service | `app/entrypoints/main_api.py` (:8000) | Verified |
| Scheduling optimization service (separate FastAPI process) | `app/entrypoints/optimizer_service.py` (:8001): `/optimize`, `/validate`, `/check-pair`, `/health` | Verified |
| Notification service | `app/entrypoints/notification_service.py` (:8002): event consumer, persistence, WebSocket `/ws`, reminders | Verified |
| Analytics service | `app/entrypoints/analytics_service.py` (:8003): aggregation pipelines, exports, explain plans | Verified |
| Authenticated inter-service HTTP | `X-Service-Token` header checked with constant-time comparison (`verify_service_token`) | Verified |
| Redis-backed task queue | `smartshift:jobs` list, reliable `BLMOVE` to a processing list, crash recovery on worker start | Verified |
| Asynchronous background processing | Worker process `app/entrypoints/worker.py`; notification consumer task | Verified |
| Job IDs and status tracking | `optimization_runs` documents (`queued -> running -> completed/failed`, progress, attempts); `GET /api/runs/{id}` | Verified |
| WebSocket live notifications | `/ws?token=` with JWT; frontend reconnects with backoff | Verified (browser showed "Live" badge and toasts) |
| Health checks | `/health` on all services; aggregated `GET /api/system/health` incl. worker heartbeat and queue depth | Verified |
| Timeouts and bounded retries | `ServiceClient`: per-service timeouts, 3 attempts with exponential backoff; worker re-queues up to 3 job attempts | Verified |
| Structured logging and correlation IDs | JSON logs; `X-Correlation-ID` propagated HTTP -> Redis job -> worker -> optimizer -> event -> notification service | Verified |
| Graceful handling of unavailability | 503 with message; Redis-down fallback writes notifications directly; optimizer outage retried | Verified |
| Docker Compose | `docker-compose.yml` (mongo replica set, redis, 5 backend processes, nginx frontend) | Implemented, not executed (no Docker daemon in the build environment); YAML validated |

**Data ownership:** the main API writes workforce collections; the worker writes `optimization_runs`; the notification service writes `notifications`; the analytics service is read-only; the optimizer owns no data. MongoDB is the only persistent store; Redis carries transient jobs and events.

**Actual results:**

- One request traced across four processes with correlation ID `expo-trace-0001`: main API `POST /generate` (202) -> worker `job started` -> optimizer `POST /optimize` 200 in 356.8 ms -> worker `job finished` -> notification service `event processed: optimization.completed`.
- Outage test (`expo-degrade-01`): with the optimizer stopped, the worker logged three failed calls (attempts 1-3), `optimizer unavailable, job will be retried`, re-queued the job, and completed it after the optimizer restarted. `/api/system/health` reported the optimizer as down meanwhile.

**Tests:** `test_schedule_generation_apply_publish` (job queued in Redis, processed, results persisted), `test_simulation_never_modifies_schedule`, `test_analytics_gateway_and_aggregations` (main API -> analytics service over HTTP with service token).

**Demonstration:** Settings page service-health card; run `./run_local.sh` and show five processes (`ps`); stop the optimizer, generate, restart, watch the job finish.

**Completion:** Verified, except Docker Compose execution.

---

## CO4 - Problem Solving, Innovation and Optimization (20 marks)

| # | Requirement | Where | Evidence |
|---|---|---|---|
| 1 | CP-SAT shift optimization | `app/optimization/solver.py` | `test_full_coverage_without_violations` |
| 2 | Availability constraints | `constraints.static_checks`, eligibility | `test_skills_leave_availability_respected` |
| 3 | Skill matching and skill mix | eligibility + skill-mix constraint | `test_skill_mix_enforced` |
| 4 | Weekly hour limits (incl. other departments) | weekly constraint with fixed hours | `test_weekly_hour_limit_is_respected` |
| 5 | Minimum rest | pairwise conflict constraints | `test_minimum_rest_and_overlap` |
| 6 | Overlap prevention | same | same; `test_concurrent_assignments_cannot_overfill_or_double_book` |
| 7 | Fair workload distribution | deviation from proportional fair share | fairness metric, presets comparison |
| 8 | Night and weekend balance | balance terms (unpopular-night group) | Well-being preset night equity 0.80 vs 0.33 |
| 9 | Preference optimization | preference penalty | `test_cpsat_beats_baselines_on_preferences_and_violations` |
| 10 | Labour cost optimization | normalized cost + overtime terms | `test_cost_preset_is_cheaper_than_wellbeing` |
| 11 | Emergency replacement | `assignment_service.replacement_candidates`, deterministic ranking | `test_emergency_replacement_flow` |
| 12 | Infeasible schedule detection | `diagnose()`, `INFEASIBLE`/`PARTIAL` | `test_infeasible_when_understaffing_disallowed`, `test_invalid_lock_is_reported_not_fabricated`, `test_partial_schedule_reports_unfilled_shifts` |
| 13 | Explainable decisions | `explain_assignment` | `test_invalid_manual_assignment_rejected` (explain endpoint) and UI dialog |
| 14 | What-if simulation | `optimization_jobs.apply_scenario` | `test_simulation_never_modifies_schedule` |
| 15 | Baseline comparison | `baseline.py` (greedy, round robin) + independent verifier | stored in every run; comparison table |

Randomized property-style tests (`test_randomized_instances_never_violate_hard_constraints[1-5]`) generate varied staffing levels, contract hours, day-only staff, leave and blocked dates, and assert the independent verifier finds **zero hard violations** in every CP-SAT result.

Mathematical formulation: [OPTIMIZATION.md](OPTIMIZATION.md).

**Actual results** (seeded Emergency department, 21 shifts, 49 slots, 13 employees):

| Strategy | Coverage | Fairness | Preference match | Labour cost (INR) | Hard violations | Time (s) |
|---|---:|---:|---:|---:|---:|---:|
| CP-SAT Balanced | 100% | 81.14 | 100% | 258,320 | 0 | 0.74 |
| CP-SAT Cost Efficiency | 100% | 68.19 | 95.9% | 217,040 | 0 | 0.50 |
| CP-SAT Well-being | 100% | 91.22 | 87.8% | 253,920 | 0 | 0.75 |
| Greedy first-fit | 100% | 77.79 | 55.1% | 269,680 | 0 | 0.03 |
| Round robin | 100% | 81.26 | 51.0% | 267,600 | 2 | 0.0001 |

All CP-SAT solves reached `OPTIMAL`. Balanced improves preference satisfaction by 45 points and cuts cost 4.2% versus greedy; Cost Efficiency cuts cost 19.5%; Well-being gives the highest fairness. Round robin's two violations are insufficient rest after night shifts.

**Completion:** Verified.

---

## CO5 - Implementation, Demonstration and Industry Evaluation (20 marks)

| # | Requirement | Status / evidence |
|---|---|---|
| 1 | Functional React frontend | 15 routed pages built with Vite; every page exercised in Chromium with zero console errors |
| 2 | Connected FastAPI backend | All pages call real endpoints; no mock data |
| 3 | MongoDB persistence | All state in MongoDB; tests assert persisted documents |
| 4 | Working distributed services | CO3 evidence |
| 5 | Functional optimizer | Generated, applied and published from the UI |
| 6 | Professional dashboard | Overview page (KPIs, charts, heatmap, timeline, alerts, activity, quick actions) |
| 7 | Interactive calendar | Shift Planner: day/week/month, filters, drag-and-drop validated by backend, dialogs, publish |
| 8 | Employee and manager portals | Role-aware navigation and pages; employee sees only own published shifts (`test_employee_sees_only_own_published_schedule`) |
| 9 | Leave and swap workflows | UI + `test_leave_approval_affects_scheduling`, `test_shift_swap_workflow_with_duplicate_approval_guard` |
| 10 | Emergency replacement demo | Driven in the browser end to end |
| 11 | Analytics and reports | Analytics page, CSV export, print-to-PDF |
| 12 | Secure authentication | JWT, bcrypt, RBAC, department scope |
| 13 | Responsive UI | Collapsible sidebar, mobile drawer, responsive grids |
| 14 | Automated tests | 40 passing |
| 15 | Docker-based setup | Dockerfiles + Compose: implemented, not executed |
| 16 | Comprehensive README | `README.md` |
| 17 | Realistic demo dataset | `scripts/seed.py`: 30 employees, 3 departments, roles, skills, availability patterns, leave, 4 weeks of schedules produced by CP-SAT |
| 18 | Repeatable expo demonstration | One-click reset in Settings or `python -m scripts.seed` |
| 19 | Industry use-case explanation | [INDUSTRY_EVALUATION.md](INDUSTRY_EVALUATION.md) (no validation claimed) |
| 20 | Limitations and future scope | README section 18 |

Five-minute demo script and ten-step expo flow: [DEMO_SCRIPT.md](DEMO_SCRIPT.md).

**Screenshots to capture:** listed in DEMO_SCRIPT.md.

**Completion:** Verified, except Docker execution.

---

## CO6 - Reserved for the official rubric

The official description and marks for CO6 have not been supplied. No requirements have been invented.

The architecture is prepared for extension: business logic lives in `app/services`, the optimizer is a separate stateless service with a versionable request contract (`app/optimization/types.py`), new routers mount in `app/entrypoints/main_api.py`, new collections are declared in `app/database/schema.py` (validators and indexes applied idempotently by `init_db`), and frontend pages are lazy-loaded routes in `src/App.jsx`. When the CO6 rubric is available, add a section here with the same structure as CO1-CO5.

**Completion:** Pending official requirements.
