# Implementation Status

## Completed and verified

| Phase | Scope | Evidence |
|---|---|---|
| 1 | Project setup, MongoDB connection, validators, indexes, JWT auth, roles | `pytest` auth/RBAC tests; CO1_RESULTS.md |
| 2 | Employees, departments, shifts, availability | CRUD tests; UI pages |
| 3 | CP-SAT optimizer, verifier, baselines, metrics, diagnosis | 20 optimizer tests incl. randomized zero-violation checks |
| 4 | Calendar, drag-and-drop with backend validation, publishing | Browser run: invalid drags rejected with reasons |
| 5 | Leave, swaps, emergency replacement | API tests (incl. concurrent approval race); browser run |
| 6 | Analytics, fairness, what-if simulation | Aggregation tests; simulation isolation test |
| 7 | Notifications (Redis + WebSocket), demo data, tests, docs, UI polish | 40 tests passing; correlation-ID trace across 4 processes; outage retry run |

## Not executed in the build environment

- `docker compose up` (no Docker daemon was available). Dockerfiles and Compose were written and the YAML validated; all services were instead run and verified as local processes.
- The Postman collection was generated from the OpenAPI schema but not executed inside Postman; the equivalent requests are covered by `tests/test_api.py`.
- `mongodump`/`mongorestore` commands are documented, not run.

## Known limitations

See README section 18.

## Next steps (if continuing)

1. Run `docker compose up --build` on a machine with Docker and record the result here.
2. Add CO6 once the official rubric is published (see COURSE_OUTCOME_MAPPING.md).
3. Optional: Redis pub/sub fan-out for multiple notification-service replicas.
