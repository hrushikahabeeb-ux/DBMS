# Industry Use-Case Evaluation

This section explains how SmartShift AI maps onto four industries. It is an analytical evaluation by the project team. **No external industry feedback, pilot or user testing has been obtained**, so no claim of industry validation is made.

## Why the design transfers

Nothing in the scheduler is hospital-specific. Departments, shift templates (start time, duration, required staff), required qualifications, skill-mix minimums, rest periods, weekly limits, consecutive-day limits, overtime threshold, weekend days and objective weights are all data in MongoDB, editable in the Departments and Settings pages. Changing industry means changing configuration, not code.

| Industry | Departments | Shift templates | Qualifications and skill mix | Key rules | Most valuable features |
|---|---|---|---|---|---|
| Hospitals (demo) | Emergency, ICU, General Ward | Morning/Evening/Night, 8 h | BLS for all; at least one ACLS on nights; Critical Care in ICU | 11 h rest, 6 consecutive days, nurse-to-patient minimums | Emergency replacement, night equity, explainability for audits |
| Restaurants | Kitchen, Floor, Bar | Breakfast, Lunch, Dinner, Close; 4-6 h | Food safety certificate; at least one supervisor per shift | Minor-worker hour limits, split shifts, weekend demand peaks | Cost preset, demand-increase simulation for events, swaps |
| Retail stores | Sales floor, Checkout, Stockroom | Open, Mid, Close | Key-holder, cash handling | Weekly hour caps for part-timers, fair weekend distribution | Weekend balance, preferences, leave planning in festive season |
| IT operations | NOC, L2 support, On-call | 24x7 rotations, 8-12 h | Platform expertise, at least one senior per rotation | Rest after night rotations, follow-the-sun handover | Skill mix, fairness of unpopular rotations, what-if for incidents |

## Expected benefits (to be measured in a pilot)

- **Time:** generating a weekly department schedule takes under a second of solver time versus hours of manual work.
- **Compliance:** hard constraints are enforced by construction and verified independently, which turns a manual audit into a report.
- **Fairness:** fairness is a published, reproducible number rather than a perception.
- **Resilience:** absences are covered with validated candidates in seconds.

## Suggested validation plan

1. Run in shadow mode for four weeks alongside the existing manual roster in one ward.
2. Measure violations found in the manual roster by the conflict engine, time spent scheduling, and swap/absence turnaround.
3. Collect structured feedback from the manager and at least ten staff members on fairness and preference satisfaction.
4. Only after this can industry validation be claimed.
