# Scheduling Optimization: Formulation and Evaluation

This document specifies the constraint model solved by the Scheduling Optimization Service (`backend/app/optimization/solver.py`), the metrics used to evaluate schedules (`metrics.py`), the baselines (`baseline.py`), and the measured results.

## 1. Sets and parameters

| Symbol | Meaning |
|---|---|
| $E$ | employees in the request (active staff eligible for the department, plus anyone already assigned) |
| $S$ | shifts of the schedule period (one per day per shift template) |
| $W$ | ISO weeks touched by the period |
| $D$ | local calendar dates of the period |
| $R_s$ | required staff for shift $s$ |
| $d_s$ | duration of shift $s$ in hours |
| $M_s$ | skill-mix requirements of $s$: pairs $(k, m_{s,k})$ meaning "at least $m_{s,k}$ assignees hold skill $k$" |
| $H_e$ | weekly contract limit of employee $e$ |
| $F_{e,w}$ | hours employee $e$ already works in week $w$ outside this schedule (other departments or periods) |
| $c_e$ | hourly wage of employee $e$ |
| $\rho$ | minimum rest between shifts (default 11 h) |
| $K$ | maximum consecutive working days (default 6) |
| $T$ | weekly overtime threshold (default 40 h) |
| $L$ | locked assignments that must be preserved |
| $P$ | previous (unlocked) assignments, used for stability |

**Static eligibility** $\text{elig}(e,s)$ is true when the employee is active, eligible for the department, holds every required qualification, is not on approved leave on the shift's date, has not blocked that date, has a recurring availability window covering the whole shift, does not conflict (overlap or rest) with a fixed external assignment, and $F_{e,w} + d_s \le H_e$. Decision variables exist only for eligible pairs, so ineligible assignments are impossible by construction.

## 2. Decision variables

- $x_{e,s} \in \{0,1\}$ for every eligible pair: employee $e$ works shift $s$.
- $u_s \in [0, R_s]$: unfilled slots of shift $s$ (fixed to 0 when understaffing is disallowed).
- $g_{s,k} \in [0, m_{s,k}]$: missing skill-mix members.
- $y_{e,t} \in \{0,1\}$: employee $e$ works on date $t$.
- $o_{e,w} \ge 0$: overtime half-hours of $e$ in week $w$.
- $\delta_e, \nu_e, \omega_e \ge 0$: workload, night and weekend deviation from fair share.

## 3. Hard constraints

1. **Coverage without overstaffing**: $\sum_e x_{e,s} + u_s = R_s \quad \forall s$
2. **Skill mix**: $\sum_{e:\,k \in \text{skills}(e)} x_{e,s} + g_{s,k} \ge m_{s,k} \quad \forall s, (k, m_{s,k}) \in M_s$
3. **No overlap and minimum rest**: for every pair of shifts $a, b$ that overlap or are separated by less than $\rho$ hours, $x_{e,a} + x_{e,b} \le 1 \quad \forall e$
4. **Weekly hour limit**: $\sum_{s \in w} d_s\, x_{e,s} \le H_e - F_{e,w} \quad \forall e, w$
5. **Maximum consecutive days**: with $y_{e,t} \ge x_{e,s}$ for shifts on date $t$ and $y_{e,t} \le \sum x_{e,s}$, every window of $K+1$ consecutive dates satisfies $\sum_{t} y_{e,t} + \text{(fixed worked days in window)} \le K$
6. **Locked assignments**: $x_{e,s} = 1 \quad \forall (e,s) \in L$ (an ineligible lock makes the model infeasible and is reported, never silently dropped)
7. **No duplicates**: implied by binary $x$; enforced in MongoDB by a partial unique index on `(shift_id, employee_id)` for active assignments.
8. **Unavailability, leave, qualifications, department eligibility, deactivated employees**: enforced by eligibility (variables do not exist).

When `allow_understaffing` is false, $u_s = g_{s,k} = 0$ and an impossible staffing level yields `INFEASIBLE` with a capacity diagnosis instead of a schedule.

## 4. Objective (minimize)

$$
\begin{aligned}
\min\;& W_u \Big(\sum_s u_s + \sum_{s,k} g_{s,k}\Big)
 + W_c \sum_{e,s} \tilde c_{e,s}\, x_{e,s}
 + W_p \sum_{e,s} 100\,(1-\pi_{e,s})\, x_{e,s}
 + W_o \cdot \tfrac{100}{16} \sum_{e,w} o_{e,w} \\
&+ W_f \sum_e \delta_e
 + W_n \sum_{e \in N} \nu_e
 + W_w \sum_{e} \omega_e
 + W_s \sum_{(e,s) \in P} 100\,(1 - x_{e,s})
\end{aligned}
$$

| Term | Definition | Normalization |
|---|---|---|
| Unfilled | slack on coverage and skill mix | $W_u = 10{,}000$ dominates every other term, so coverage is always maximized first |
| Cost | $\tilde c_{e,s} = 100 \cdot c_e d_s / (\text{median wage} \cdot 8)$ | an average 8-hour shift costs about 100 points |
| Preference | $\pi_{e,s}=1$ when the shift type is preferred (or no preference stated) and the day is not a preferred day off | 100 points per mismatch |
| Overtime | $o_{e,w} \ge \sum_{s\in w} 2 d_s x_{e,s} - 2(T - F_{e,w})$ | 100 points per 8 overtime hours |
| Workload fairness | $\delta_e \ge \lvert (F_e + \sum_s d_s x_{e,s}) / (H_e\lvert W\rvert) - \tau_e \rvert$ in percent | $\tau_e$ is the proportional fair share: $\min(\sigma H_e\lvert W\rvert,\; F_e + \text{eligible hours},\; H_e \lvert W \rvert)$ with $\sigma = (\text{required hours} + \sum F)/\sum H_e\lvert W \rvert$ |
| Night balance | $\nu_e \ge \lvert 40 n_e - 40 \bar n \rvert$, over night-eligible staff who did **not** request nights ($N$) | nights are the unpopular shift; people who prefer them are excluded |
| Weekend balance | same form over weekend shifts | |
| Stability | penalty for changing a previous unlocked assignment on regeneration | 100 points per change |

### Presets (configurable in Settings)

| Weight | Balanced | Cost Efficiency | Employee Well-being |
|---|---:|---:|---:|
| unfilled | 10000 | 10000 | 10000 |
| cost | 1 | 10 | 1 |
| preference | 4 | 1 | 5 |
| fairness | 5 | 1 | 12 |
| night_balance | 3 | 1 | 18 |
| weekend_balance | 3 | 1 | 12 |
| overtime | 4 | 10 | 6 |
| stability | 1 | 1 | 1 |

Solver: OR-Tools CP-SAT, 8 workers, fixed random seed (deterministic per input), time limit from rules (default 10 s). `OPTIMAL` means proven optimal for the weighted objective; `FEASIBLE` means best found within the limit.

## 5. Evaluation metrics (independent of the solver)

All metrics are recomputed from the final assignment list by `compute_metrics`, which also runs the independent verifier `verify()` (the same rule code used by manual validation, swaps and replacement).

- **Coverage** = $\sum_s \min(\text{assigned}_s, R_s) / \sum_s R_s$
- **Hard violations** = verifier findings excluding pure coverage findings (overlap, insufficient rest, weekly hours, qualification, leave, availability, department, duplicate, consecutive days)
- **Labor cost** = $\sum c_e d_s$ + overtime premium $(\text{multiplier}-1) c_e \cdot \text{overtime hours}$
- **Preference satisfaction** = share of assignments with $\pi_{e,s} = 1$
- **Fairness score (0-100)**

$$
\text{Fairness} = 100\,\big(0.4\,(1-G_\text{hours}) + 0.2\,(1-G_\text{night}) + 0.2\,(1-G_\text{weekend}) + 0.2\,P\big)
$$

where $G$ is the Gini coefficient. $G_\text{hours}$ uses load ratio = total weekly hours (including other departments) divided by contract hours across the employee pool. $G_\text{night}$ uses night counts of night-eligible staff who did not request nights. $P$ is preference satisfaction. Employees beyond 1.5 standard deviations of mean load are reported as workload outliers.

## 6. Baselines

- **Round robin** rotates through the department roster and takes the next employee who holds the skills and is nominally available. It ignores rest, weekly limits, leave and consecutive days. This is what many small teams do by hand.
- **Greedy first-fit** processes shifts chronologically and gives each slot to the valid employee with the lowest load so far, respecting every hard constraint, but without look-ahead.

## 7. Measured results

Seeded Emergency department, week of 26 Oct 2026: 21 shifts, 49 staff slots, 13 eligible employees (2 cross-trained), 1 approved leave affecting the following week. Captured from the `optimization_runs` collection after `python -m scripts.seed`:

| Strategy | Coverage | Fairness | Preference match | Labor cost (INR) | Overtime h | Hard violations | Time (s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| CP-SAT Balanced | 100.0% | 81.14 | 100.0% | 258,320 | 0 | 0 | 0.74 |
| CP-SAT Cost Efficiency | 100.0% | 68.19 | 95.9% | 217,040 | 0 | 0 | 0.50 |
| CP-SAT Employee Well-being | 100.0% | **91.22** | 87.8% | 253,920 | 0 | 0 | 0.75 |
| Baseline Greedy first-fit | 100.0% | 77.79 | 55.1% | 269,680 | 0 | 0 | 0.03 |
| Baseline Round robin | 100.0% | 81.26 | 51.0% | 267,600 | 0 | **2** | 0.0001 |

Interpretation:

- Every CP-SAT preset satisfies all hard constraints; round robin produces violations (insufficient rest) even when its headline fairness looks similar.
- Balanced mode raises preference satisfaction from 55% (greedy) to 100% while also reducing cost by 4.2%.
- Cost Efficiency mode lowers labor cost by 19.5% against greedy at full coverage.
- Well-being mode achieves the highest fairness (91.2) by spreading unpopular night shifts, trading about 12 percentage points of stated preferences. The presets expose a real, measurable trade-off rather than one universally best schedule.

Exact values vary slightly with the seed date because the dataset is generated relative to the current week; re-run `python -m scripts.seed` and open the AI Schedule Generator or `GET /api/analytics/optimization-comparison` to reproduce.

## 8. Emergency replacement ranking

Candidates must pass every hard check (`evaluate()`); valid candidates are ranked by a deterministic score (ties by employee code):

$$
\text{score} = 30\,\mathbb{1}[\text{preferred shift type}] + 15\,\mathbb{1}[\text{not a preferred day off}] + 25\,(1 - \text{weekly load after}) + 15\,\tfrac{\min(\text{nearest rest gap}, 48)}{48} + 15\,(1 - \text{normalized wage})
$$

The breakdown is returned with each candidate and shown in the UI. Approval re-validates inside a transaction and refuses duplicates.

## 9. Infeasibility handling

Before solving, `diagnose()` computes per-shift eligible counts, skill-mix shortfalls, invalid locks and total capacity versus required hours. If the model is infeasible the service returns `status: INFEASIBLE`, no assignments, the diagnosis and concrete suggestions. With understaffing allowed, the result is `PARTIAL` with the list of unfilled shifts and the same diagnosis. Tests `test_infeasible_when_understaffing_disallowed` and `test_invalid_lock_is_reported_not_fabricated` cover both paths.
