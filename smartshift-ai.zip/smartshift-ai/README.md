# SmartShift AI

**Intelligent Workforce Scheduling, Optimization and Employee Management Platform**

SmartShift AI generates staff schedules with a real constraint-optimization engine (Google OR-Tools CP-SAT), explains every assignment, recovers from sudden absences with ranked and validated replacements, and measures fairness transparently. It is demonstrated on a hospital (Emergency, ICU, General Ward) but every rule, shift template and requirement is configurable, so the same system serves restaurants, retail and IT operations.

---

## 1. Project overview

SmartShift AI is a distributed web application made of a React frontend and five backend processes (main API, optimization service, notification service, analytics service and a job worker) that share one MongoDB database and use Redis only as a transient job queue and event bus.

## 2. Problem statement

Shift scheduling in hospitals is usually done by hand in spreadsheets. Managers must juggle availability, qualifications, labour law (rest periods, weekly limits), fairness of nights and weekends, staff preferences, cost and constant last-minute absences. Manual schedules routinely contain hidden violations, distribute unpopular shifts unevenly and take hours to repair when someone calls in sick.

## 3. Objectives

1. Generate schedules that never violate hard constraints and that optimize fairness, preferences and cost.
2. Make every decision explainable from the actual constraint checks.
3. Recover from absences in seconds with ranked, validated replacements.
4. Measure fairness and cost with transparent, normalized metrics and compare against baseline algorithms.
5. Provide complete employee, manager and administrator workflows (availability, leave, swaps, publishing, notifications, audit).

## 4. Key features

| Area | What it does |
|---|---|
| CP-SAT scheduling engine | Hard constraints for availability, leave, qualifications, department eligibility, overlap, minimum rest, weekly hours, consecutive days, skill mix, locked assignments. Weighted objective for fairness, preferences, night/weekend balance, overtime, labour cost and stability. Three presets. |
| Honest infeasibility | Returns `INFEASIBLE` or `PARTIAL` with a capacity diagnosis and suggestions; never fabricates a schedule. |
| Baseline comparison | Every generation also runs greedy first-fit and round robin; an independent verifier recomputes all metrics. |
| Explainable scheduling | "Why was this employee assigned?" shows each hard check, preference outcome and the objective factors weighed. |
| Interactive calendar | FullCalendar day/week/month views, department and employee filters, colour-coded shifts, open-slot markers, drag-and-drop moves validated by the backend, manual and automatic assignment, publish/unpublish. |
| Conflict detection | Overlaps, insufficient rest, weekly limits, missing qualifications, unavailability, leave conflicts, duplicates, understaffing, each with severity, explanation and suggested resolution. |
| Emergency replacement | Mark absent, see ranked candidates with full validation and score breakdown, approve (re-validated in a transaction), both employees notified, shortage warning when nobody qualifies. |
| Leave and swaps | Leave approval marks affected shifts absent and opens replacement planning. Swap workflow: request, colleague accepts, manager approves; atomic exchange guarded against duplicate approvals. |
| What-if simulation | Unexpected absences, demand increase, extra skill requirements, workforce reduction, contract-hour changes; compares against the current schedule and never modifies it unless explicitly applied (then re-validated against real data). |
| Analytics | Coverage heatmap, utilization, hours and overtime, labour cost, night/weekend distribution, leave trends, shortages, fairness analysis, optimization comparison, CSV export, print-to-PDF. |
| Real-time notifications | Redis-backed event queue, persisted in MongoDB, delivered over WebSockets, upcoming-shift reminders. |
| Security | JWT, bcrypt, role-based and department-scoped authorization on the backend, input validation, audit log, correlation IDs. |

## 5. Technology stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, JavaScript, Tailwind CSS, shadcn/ui pattern on Radix UI primitives, Lucide icons, Framer Motion, Recharts, FullCalendar 6, Axios, React Router, Sonner |
| Backend | Python 3.12+, FastAPI, Pydantic v2, PyMongo Async API, Google OR-Tools CP-SAT, PyJWT, bcrypt, httpx, redis-py, WebSockets |
| Data | MongoDB 7/8 replica set (system of record), Redis (transient queue and event bus only) |
| Ops | Docker Compose, nginx (frontend container), pytest |

scikit-learn is intentionally not used: demand forecasting was not implemented, so no model was added for show.

## 6. System architecture

```mermaid
flowchart LR
    UI[React frontend<br/>Vite / nginx] -- REST /api --> API[Main API :8000<br/>auth, workforce, schedules,<br/>workflows, analytics gateway]
    UI -- WebSocket /notify/ws --> NS[Notification service :8002]
    API -- LPUSH job --> RQ[(Redis<br/>jobs + events)]
    W[Worker process] -- BLMOVE job --> RQ
    W -- HTTP + service token --> OPT[Optimization service :8001<br/>CP-SAT, baselines, verifier]
    API -- HTTP + service token --> AN[Analytics service :8003<br/>aggregation pipelines]
    API -- LPUSH event --> RQ
    NS -- BRPOP events --> RQ
    API --> DB[(MongoDB replica set)]
    W --> DB
    NS --> DB
    AN --> DB
```

| Service | Process | Responsibilities | Data ownership |
|---|---|---|---|
| Main API | `app.entrypoints.main_api` | Auth, employees, departments, schedules, shifts, assignments, availability, leave, swaps, emergency replacement, rules, audit, analytics gateway | Writes all workforce collections |
| Optimization service | `app.entrypoints.optimizer_service` | Stateless CP-SAT solve, baselines, constraint validation, metrics | None (pure compute) |
| Worker | `app.entrypoints.worker` | Consumes jobs, assembles inputs from MongoDB, calls the optimizer, stores results | `optimization_runs` |
| Notification service | `app.entrypoints.notification_service` | Consumes events, persists and pushes notifications, reminders | `notifications` |
| Analytics service | `app.entrypoints.analytics_service` | Read-only aggregation pipelines, CSV export, explain-plan comparison | Read-only |

Inter-service calls use an `X-Service-Token` header, timeouts, bounded retries with exponential backoff, and forward `X-Correlation-ID`; every service logs structured JSON with that ID. Unavailable services surface as `503` with a clear message, queued jobs are retried, and if Redis is down notifications are written directly to MongoDB.

## 7. MongoDB database design

Thirteen collections, each with a `$jsonSchema` validator (`validationLevel: strict`) and purpose-built indexes. All timestamps are UTC; scheduling logic uses the organization timezone stored in `scheduling_rules`.

| Collection | Key fields | Notable indexes and constraints |
|---|---|---|
| users | email, password_hash, role, employee_id, managed_department_ids | unique email; unique employee link (partial) |
| employees | employee_code, department_ids[], skills[], status, max_weekly_hours, hourly_wage, version | unique code, unique email, (department_ids, status), multikey skills, text index |
| departments | code, name, shift_configurations[], required_skills, manager_user_id | unique code, unique name |
| schedules | department_id, start_date, end_date, status, version | unique (department_id, start_date) |
| shifts | schedule_id, department_id, template_code, local_date, start, end, required_staff, assigned_count, skill_mix | (schedule_id, start), unique (schedule_id, local_date, template_code) |
| assignments | schedule_id, shift_id, employee_id, start, end, status, locked, source | **partial unique (shift_id, employee_id) where status = active**, (employee_id, start), (department_id, start, status) |
| availability | employee_id, recurring[], unavailable_dates[], preferences | unique employee_id |
| leave_requests | employee_id, dates, type, status, history[] | (employee_id, start_date), (status, start_date) |
| swap_requests | requester/target employee and assignment, status, is_open | **partial unique requester_assignment_id where is_open** |
| notifications | user_id, type, read, dedupe_key | (user_id, read, created_at), partial unique dedupe_key |
| scheduling_rules | scope, timezone, rest, limits, weights | unique scope |
| optimization_runs | kind, schedule_id, status, progress, result | (schedule_id, created_at), (status, created_at) |
| audit_logs | actor, action, entity, details, correlation_id | (created_at), (entity_type, entity_id) |

```mermaid
erDiagram
    DEPARTMENTS ||--o{ SCHEDULES : has
    SCHEDULES ||--o{ SHIFTS : contains
    SHIFTS ||--o{ ASSIGNMENTS : staffed_by
    EMPLOYEES ||--o{ ASSIGNMENTS : works
    EMPLOYEES }o--o{ DEPARTMENTS : eligible_for
    EMPLOYEES ||--|| AVAILABILITY : submits
    EMPLOYEES ||--o{ LEAVE_REQUESTS : requests
    EMPLOYEES ||--o{ SWAP_REQUESTS : initiates
    USERS ||--o| EMPLOYEES : linked_to
    USERS }o--o{ DEPARTMENTS : manages
    USERS ||--o{ NOTIFICATIONS : receives
    SCHEDULES ||--o{ OPTIMIZATION_RUNS : optimized_by
    USERS ||--o{ AUDIT_LOGS : performs
```

**Transactions.** Multi-document changes run in MongoDB transactions (`run_transaction` with `with_transaction`, snapshot read concern, majority write concern): manual assignment, moves, absences, replacement approval, applying an optimization run, leave approval, swap approval, schedule creation, employee creation. Concurrency safety comes from (1) bumping the employee's `version` first so concurrent edits for the same person write-conflict and are retried against committed state, (2) a conditional `$inc` on `shifts.assigned_count` that only succeeds below `required_staff`, and (3) conditional status transitions (`pending -> approved`) for leave and swaps. **Transactions require a replica set or MongoDB Atlas**; a standalone `mongod` will reject them.

## 8. Scheduling algorithm

The optimizer builds one CP-SAT model per preset with binary variables only for statically eligible employee-shift pairs, adds the hard constraints, and minimizes a weighted sum of normalized penalties. The full mathematical formulation, preset weights, fairness formula, baselines and measured results are in [docs/OPTIMIZATION.md](docs/OPTIMIZATION.md).

```mermaid
flowchart TD
    A[Manager selects department, period, requirements, presets] --> B[POST /schedules/id/generate]
    B --> C[optimization_runs: queued]
    C --> D[Redis job queue]
    D --> E[Worker loads shifts, employees, availability,<br/>approved leave, fixed assignments, rules]
    E --> F[Optimization service]
    F --> G[Eligibility + pre-solve diagnosis]
    G --> H[CP-SAT per preset]
    G --> I[Greedy and round-robin baselines]
    H --> J[Independent verifier + metrics]
    I --> J
    J --> K[Results stored; manager notified]
    K --> L{Manager reviews and compares}
    L -->|Apply| M[Transaction: re-validate, replace unlocked assignments]
    M --> N[Publish: employees notified]
```

## 9. Optimization constraints (summary)

Hard: availability windows and blocked dates, approved leave, active status, department eligibility, required qualifications, skill mix, no overlap, minimum rest (11 h default), weekly hour limit including other departments, maximum consecutive days (6 default), staffing requirement (never overstaffed), locked assignments, no duplicates.
Soft: fair workload share, preferred shift types and days off, night and weekend balance among staff who did not request them, overtime, labour cost, minimal changes on regeneration.

## 10. Installation

Prerequisites: Python 3.12+, Node.js 20+, MongoDB 7+ running as a replica set, Redis 7+. Or just Docker.

### Option A: Docker Compose (recommended)

```bash
cp .env.example .env              # then set JWT_SECRET and SERVICE_TOKEN
docker compose up --build -d
docker compose run --rm api python -m scripts.seed
# open http://localhost:8080
```

### Option B: local processes

```bash
# 1. MongoDB replica set (once)
mongod --replSet rs0 --dbpath ./data --bind_ip 127.0.0.1 --fork --logpath ./mongod.log
mongosh --eval "rs.initiate({_id:'rs0',members:[{_id:0,host:'127.0.0.1:27017'}]})"
redis-server --daemonize yes

# 2. Backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cp ../.env.example .env
python -m scripts.seed            # creates collections, validators, indexes and demo data

# 3. Frontend
cd ../frontend && npm install

# 4. Start everything
cd .. && ./run_local.sh           # API, optimizer, notifications, analytics, worker, Vite on :5173
```

## 11. Environment variables

See [.env.example](.env.example). The important ones:

| Variable | Purpose |
|---|---|
| `MONGODB_URI`, `MONGODB_DB` | MongoDB connection (replica set or Atlas) |
| `REDIS_URL` | Job queue and event bus |
| `JWT_SECRET`, `JWT_EXPIRE_MINUTES` | User authentication |
| `SERVICE_TOKEN` | Shared secret for inter-service calls |
| `OPTIMIZER_URL`, `NOTIFICATION_URL`, `ANALYTICS_URL` | Service discovery |
| `SERVICE_TIMEOUT_SECONDS`, `OPTIMIZER_TIMEOUT_SECONDS`, `SERVICE_MAX_RETRIES` | Timeouts and bounded retries |
| `ORG_TIMEZONE`, `SOLVER_TIME_LIMIT_SECONDS` | Defaults for new rule documents |

Secrets live only in backend environment files; the frontend never sees MongoDB credentials or JWT secrets.

## 12. MongoDB setup, backup and restore

- **Local:** start `mongod` with `--replSet rs0` and run `rs.initiate()` once (Docker Compose does this automatically through its healthcheck).
- **Atlas:** create an M0+ cluster, add a database user and your IP, and set `MONGODB_URI=mongodb+srv://...`. Atlas clusters are replica sets, so transactions work.
- **Initialize only:** `python -m scripts.seed --init-only` creates collections, validators, indexes and default rules without demo data.
- **Backup:** `mongodump --uri "$MONGODB_URI" --db smartshift --gzip --archive=smartshift-$(date +%F).gz`
- **Restore:** `mongorestore --uri "$MONGODB_URI" --gzip --archive=smartshift-YYYY-MM-DD.gz --drop`
- **Docker:** `docker compose exec mongo mongodump --db smartshift --archive --gzip > backup.gz` and `docker compose exec -T mongo mongorestore --archive --gzip --drop < backup.gz`

## 13. Backend startup commands

```bash
cd backend
uvicorn app.entrypoints.main_api:app --port 8000             # Swagger: http://localhost:8000/docs
uvicorn app.entrypoints.optimizer_service:app --port 8001    # http://localhost:8001/docs
uvicorn app.entrypoints.notification_service:app --port 8002
uvicorn app.entrypoints.analytics_service:app --port 8003
python -m app.entrypoints.worker
```

## 14. Frontend startup commands

```bash
cd frontend
npm run dev        # http://localhost:5173, proxies /api -> :8000 and /notify -> :8002
npm run build && npm run preview
```

## 15. Demo credentials

| Role | Email | Password |
|---|---|---|
| Super Admin | admin@smartshift.ai | Admin@123 |
| Emergency manager | er.manager@smartshift.ai | Manager@123 |
| ICU manager | icu.manager@smartshift.ai | Manager@123 |
| Ward manager | ward.manager@smartshift.ai | Manager@123 |
| Employee (any of 30) | ananya.sharma@smartshift.ai | Employee@123 |

Employee emails follow `firstname.lastname@smartshift.ai`. These credentials are for the demo dataset only.

## 16. Expo demonstration guide

The ten-step expo workflow and a five-minute live script are in [docs/DEMO_SCRIPT.md](docs/DEMO_SCRIPT.md). Reset the data at any time from **Settings > Expo demo mode** (super admin) or with `python -m scripts.seed`.

```mermaid
sequenceDiagram
    actor M as Manager
    participant API as Main API
    participant DB as MongoDB
    participant Q as Redis
    participant N as Notification service
    actor E as Employees
    M->>API: Mark assignment absent
    API->>DB: Transaction: status=absent, release slot
    API-->>M: Ranked candidates (validated + scored)
    M->>API: Approve candidate
    API->>DB: Transaction: guard duplicate, re-validate, create assignment, link old
    API->>Q: Events: emergency_replacement, shift.modified
    Q->>N: Consume
    N->>DB: Persist notifications
    N-->>E: WebSocket push
```

```mermaid
flowchart LR
    R[Request + JWT] --> D{Role}
    D -->|super_admin| A[All departments and admin endpoints]
    D -->|manager| B{Department in managed_department_ids?}
    B -->|yes| OK[Allowed]
    B -->|no| F[403 Forbidden]
    D -->|employee| C[Own profile, own published shifts,<br/>own leave, swaps, availability]
```

## 17. Testing

```bash
cd backend
pytest -q                          # 40 tests, about one minute; needs MongoDB replica set and Redis
python -m scripts.co1_demo         # regenerates docs/CO1_RESULTS.md from live queries
```

Tests use a separate `smartshift_test` database (dropped afterwards), Redis logical DB 15, and mount the optimizer and analytics services in-process through HTTP transports. Coverage includes: authentication, role and department permissions, employee and department CRUD, MongoDB schema rejection, schedule generation, apply and publish, overlapping and rest detection, availability, weekly limits, skills, locked assignments, infeasible and partial schedules, randomized instances proving zero hard-constraint violations, concurrent assignment requests (capacity and double booking), drag-and-drop moves, emergency replacement with duplicate-approval guard, leave approval effects, swap workflow with three concurrent approvals (exactly one succeeds), simulation isolation, analytics pipelines and explain plans. A Postman collection generated from the OpenAPI schema is in [docs/postman](docs/postman).

## 18. Limitations and future enhancements

Limitations (stated honestly):

- The Docker Compose setup was written and syntax-checked but could not be executed in the development environment used to build this project (no Docker daemon available). Every service was run and tested as local processes against MongoDB 8.0 (replica set) and Redis.
- The notification service keeps WebSocket connections in process memory; multiple notification replicas would need Redis pub/sub fan-out.
- Demand forecasting is not implemented; staffing requirements are configured by managers.
- Shift templates are per department per day; split shifts and on-call pools are not modelled.
- No external industry validation has been obtained; see [docs/INDUSTRY_EVALUATION.md](docs/INDUSTRY_EVALUATION.md).

Future enhancements: demand forecasting from historical census data, multi-site organizations, mobile app with push notifications, payroll export, labour-law rule packs per country, self-scheduling bidding, and solver warm-starts for very large rosters.

## Course outcome evidence

See [docs/COURSE_OUTCOME_MAPPING.md](docs/COURSE_OUTCOME_MAPPING.md) for CO1 to CO6 with files, endpoints, MongoDB operations, tests, demo steps and verified results.
