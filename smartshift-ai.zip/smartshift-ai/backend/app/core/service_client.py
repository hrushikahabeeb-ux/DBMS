"""Authenticated inter-service HTTP client with timeouts and bounded retries."""
import asyncio
import logging
from typing import Any

import httpx

from app.core.config import get_settings
from app.core.errors import AppError, ServiceUnavailableError
from app.core.logging import CORRELATION_HEADER, get_correlation_id, log_event
from app.core.security import SERVICE_TOKEN_HEADER

logger = logging.getLogger(__name__)

# Tests may register in-process ASGI transports keyed by base URL.
_transports: dict[str, httpx.AsyncBaseTransport] = {}


def register_transport(base_url: str, transport: httpx.AsyncBaseTransport) -> None:
    _transports[base_url.rstrip("/")] = transport


def clear_transports() -> None:
    _transports.clear()


class ServiceClient:
    def __init__(self, name: str, base_url: str, timeout: float | None = None, max_retries: int | None = None):
        settings = get_settings()
        self.name = name
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout or settings.service_timeout_seconds
        self.max_retries = max_retries if max_retries is not None else settings.service_max_retries

    def _headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        headers = {
            SERVICE_TOKEN_HEADER: get_settings().service_token,
            CORRELATION_HEADER: get_correlation_id(),
        }
        if extra:
            headers.update(extra)
        return headers

    async def request(self, method: str, path: str, *, json: Any = None, params: dict | None = None,
                      headers: dict[str, str] | None = None) -> Any:
        transport = _transports.get(self.base_url)
        last_error: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            try:
                async with httpx.AsyncClient(base_url=self.base_url, timeout=self.timeout, transport=transport) as client:
                    response = await client.request(method, path, json=json, params=params, headers=self._headers(headers))
                if response.status_code >= 500:
                    raise httpx.HTTPStatusError("server error", request=response.request, response=response)
                if response.status_code >= 400:
                    body = response.json() if response.headers.get("content-type", "").startswith("application/json") else {}
                    err = body.get("error", {}) if isinstance(body, dict) else {}
                    exc = AppError(err.get("message", f"{self.name} rejected the request"), err.get("details"), err.get("code"))
                    exc.status_code = response.status_code
                    raise exc
                return response.json()
            except AppError:
                raise
            except (httpx.TransportError, httpx.HTTPStatusError) as exc:
                last_error = exc
                log_event(logger, "service call failed", service=self.name, path=path, attempt=attempt, error=str(exc))
                if attempt < self.max_retries:
                    await asyncio.sleep(min(0.25 * 2 ** (attempt - 1), 2.0))
        raise ServiceUnavailableError(
            f"The {self.name} service is unavailable. Please retry shortly.",
            {"service": self.name, "error": str(last_error)},
        )

    async def get(self, path: str, **kw):
        return await self.request("GET", path, **kw)

    async def post(self, path: str, **kw):
        return await self.request("POST", path, **kw)


def optimizer_client() -> ServiceClient:
    s = get_settings()
    return ServiceClient("optimizer", s.optimizer_url, timeout=s.optimizer_timeout_seconds)


def analytics_client() -> ServiceClient:
    return ServiceClient("analytics", get_settings().analytics_url)


def notification_client() -> ServiceClient:
    return ServiceClient("notification", get_settings().notification_url, max_retries=1)
