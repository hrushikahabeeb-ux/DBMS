"""Domain exceptions and centralized FastAPI exception handlers."""
import logging
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pymongo.errors import ConnectionFailure, DuplicateKeyError, PyMongoError, ServerSelectionTimeoutError

from app.core.logging import get_correlation_id

logger = logging.getLogger(__name__)


class AppError(Exception):
    status_code = 400
    code = "bad_request"

    def __init__(self, message: str, details: Any | None = None, code: str | None = None):
        super().__init__(message)
        self.message = message
        self.details = details
        if code:
            self.code = code


class NotFoundError(AppError):
    status_code = 404
    code = "not_found"


class ConflictError(AppError):
    status_code = 409
    code = "conflict"


class ForbiddenError(AppError):
    status_code = 403
    code = "forbidden"


class UnauthorizedError(AppError):
    status_code = 401
    code = "unauthorized"


class ValidationFailed(AppError):
    status_code = 422
    code = "validation_failed"


class ServiceUnavailableError(AppError):
    status_code = 503
    code = "service_unavailable"


def _body(code: str, message: str, details: Any = None) -> dict:
    from app.database.mongo import serialize

    return {"error": {"code": code, "message": message, "details": serialize(details),
                      "correlation_id": get_correlation_id()}}


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def app_error_handler(_: Request, exc: AppError):
        return JSONResponse(status_code=exc.status_code, content=_body(exc.code, exc.message, exc.details))

    @app.exception_handler(RequestValidationError)
    async def validation_handler(_: Request, exc: RequestValidationError):
        errors = [
            {"field": ".".join(str(p) for p in e.get("loc", []) if p != "body"), "message": e.get("msg")}
            for e in exc.errors()
        ]
        return JSONResponse(status_code=422, content=_body("validation_failed", "Request validation failed", errors))

    @app.exception_handler(DuplicateKeyError)
    async def duplicate_handler(_: Request, exc: DuplicateKeyError):
        key = (exc.details or {}).get("keyValue") or {}
        message = "A record with this unique value already exists"
        if "requester_assignment_id" in key:
            message = "An open swap request already exists for this shift"
        elif "employee_id" in key and "shift_id" in key:
            message = "This employee is already assigned to this shift"
        return JSONResponse(status_code=409, content=_body("duplicate", message, {"fields": sorted(key)}))

    @app.exception_handler(ServerSelectionTimeoutError)
    @app.exception_handler(ConnectionFailure)
    async def db_down_handler(_: Request, exc: Exception):
        logger.error("database unavailable: %s", exc)
        return JSONResponse(status_code=503, content=_body("database_unavailable", "The database is currently unreachable. Please retry shortly."))

    @app.exception_handler(PyMongoError)
    async def db_error_handler(_: Request, exc: PyMongoError):
        logger.exception("database error")
        return JSONResponse(status_code=500, content=_body("database_error", "A database error occurred"))

    @app.exception_handler(Exception)
    async def unhandled(_: Request, exc: Exception):
        logger.exception("unhandled error")
        return JSONResponse(status_code=500, content=_body("internal_error", "An unexpected error occurred"))
