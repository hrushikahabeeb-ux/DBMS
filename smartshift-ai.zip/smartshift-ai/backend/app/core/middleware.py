"""Correlation-ID and request logging middleware."""
import logging
import time

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from app.core.logging import CORRELATION_HEADER, correlation_id_var, log_event, new_correlation_id

logger = logging.getLogger("http")


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        cid = request.headers.get(CORRELATION_HEADER) or new_correlation_id()
        token = correlation_id_var.set(cid)
        started = time.perf_counter()
        try:
            response = await call_next(request)
        finally:
            elapsed_ms = round((time.perf_counter() - started) * 1000, 1)
        response.headers[CORRELATION_HEADER] = cid
        if request.url.path not in ("/health", "/api/health"):
            log_event(
                logger,
                "request",
                method=request.method,
                path=request.url.path,
                status=response.status_code,
                duration_ms=elapsed_ms,
            )
        correlation_id_var.reset(token)
        return response
