"""Environment-based configuration shared by every SmartShift AI service."""
from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    environment: str = Field(default="development")
    service_name: str = Field(default="smartshift-api")

    # MongoDB (a replica set is required for multi-document transactions)
    mongodb_uri: str = Field(default="mongodb://127.0.0.1:27017/?replicaSet=rs0")
    mongodb_db: str = Field(default="smartshift")
    mongodb_timeout_ms: int = Field(default=5000)

    # Redis is used only for the transient job queue and event bus
    redis_url: str = Field(default="redis://127.0.0.1:6379/0")

    # Security
    jwt_secret: str = Field(default="change-me-in-production-please-32-bytes-min")
    jwt_algorithm: str = Field(default="HS256")
    jwt_expire_minutes: int = Field(default=480)
    service_token: str = Field(default="change-me-internal-service-token")
    cors_origins: str = Field(default="http://localhost:5173,http://127.0.0.1:5173")

    # Inter-service URLs
    optimizer_url: str = Field(default="http://127.0.0.1:8001")
    notification_url: str = Field(default="http://127.0.0.1:8002")
    analytics_url: str = Field(default="http://127.0.0.1:8003")
    service_timeout_seconds: float = Field(default=10.0)
    optimizer_timeout_seconds: float = Field(default=90.0)
    service_max_retries: int = Field(default=3)

    # Organization defaults
    org_name: str = Field(default="City General Hospital")
    org_timezone: str = Field(default="Asia/Kolkata")
    solver_time_limit_seconds: float = Field(default=10.0)
    solver_workers: int = Field(default=8)

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
