"""Pydantic request and response models for the main API."""
from datetime import date
from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator

from app.models.enums import EmployeeStatus, LeaveType, Preset, Role

T = TypeVar("T")
HHMM = r"^([01]\d|2[0-3]):[0-5]\d$"


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    page_size: int
    pages: int


# ---------------------------------------------------------------- auth
class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1)


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: str = Field(min_length=2, max_length=120)

    @field_validator("password")
    @classmethod
    def strong(cls, v: str) -> str:
        if not any(c.isdigit() for c in v) or not any(c.isalpha() for c in v):
            raise ValueError("Password must contain letters and digits")
        return v


class UserOut(BaseModel):
    id: str
    email: str
    full_name: str
    role: Role
    employee_id: str | None = None
    managed_department_ids: list[str] = []
    is_active: bool = True


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    full_name: str = Field(min_length=2)
    role: Role
    managed_department_ids: list[str] = []
    employee_id: str | None = None


class UserUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=2)
    role: Role | None = None
    managed_department_ids: list[str] | None = None
    is_active: bool | None = None
    password: str | None = Field(default=None, min_length=8)


# ---------------------------------------------------------------- employees
class EmployeeBase(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    primary_department_id: str
    department_ids: list[str] = Field(default_factory=list)
    job_role: str = Field(min_length=2, max_length=80)
    skills: list[str] = Field(default_factory=list)
    max_weekly_hours: float = Field(default=40, ge=4, le=80)
    preferred_shifts: list[str] = Field(default_factory=list)
    hourly_wage: float = Field(ge=0, le=100000)
    joining_date: date
    phone: str | None = Field(default=None, max_length=20)

    @field_validator("skills", "preferred_shifts")
    @classmethod
    def dedupe(cls, v: list[str]) -> list[str]:
        return sorted({s.strip() for s in v if s.strip()})


class EmployeeCreate(EmployeeBase):
    employee_code: str = Field(pattern=r"^[A-Z]{2,4}-\d{3,5}$")
    create_login: bool = True
    initial_password: str | None = Field(default=None, min_length=8)


class EmployeeUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=2, max_length=120)
    email: EmailStr | None = None
    primary_department_id: str | None = None
    department_ids: list[str] | None = None
    job_role: str | None = None
    skills: list[str] | None = None
    max_weekly_hours: float | None = Field(default=None, ge=4, le=80)
    preferred_shifts: list[str] | None = None
    hourly_wage: float | None = Field(default=None, ge=0)
    joining_date: date | None = None
    status: EmployeeStatus | None = None
    phone: str | None = None


class EmployeeOut(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str
    employee_code: str
    full_name: str
    email: str
    primary_department_id: str
    department_ids: list[str]
    job_role: str
    skills: list[str]
    status: EmployeeStatus
    max_weekly_hours: float
    preferred_shifts: list[str] = []
    hourly_wage: float
    joining_date: str
    user_id: str | None = None


# ---------------------------------------------------------------- departments
class SkillMixIn(BaseModel):
    skill: str
    min: int = Field(ge=1, le=20)


class ShiftConfig(BaseModel):
    code: str = Field(pattern=r"^[a-z][a-z0-9_]{1,20}$")
    name: str = Field(min_length=2, max_length=40)
    start_time: str = Field(pattern=HHMM)
    duration_hours: float = Field(ge=1, le=16)
    required_staff: int = Field(ge=0, le=50)
    required_skills: list[str] = []
    skill_mix: list[SkillMixIn] = []
    color: str | None = None


class OperatingHours(BaseModel):
    start: str = Field(default="00:00", pattern=HHMM)
    end: str = Field(default="23:59", pattern=HHMM)
    days: list[int] = Field(default_factory=lambda: list(range(7)))


class DepartmentBase(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    description: str = ""
    manager_user_id: str | None = None
    operating_hours: OperatingHours = OperatingHours()
    required_skills: list[str] = []
    shift_configurations: list[ShiftConfig] = Field(min_length=1)
    color: str | None = None

    @model_validator(mode="after")
    def unique_codes(self):
        codes = [c.code for c in self.shift_configurations]
        if len(codes) != len(set(codes)):
            raise ValueError("Shift configuration codes must be unique")
        return self


class DepartmentCreate(DepartmentBase):
    code: str = Field(pattern=r"^[A-Z]{2,6}$")


class DepartmentUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2)
    description: str | None = None
    manager_user_id: str | None = None
    operating_hours: OperatingHours | None = None
    required_skills: list[str] | None = None
    shift_configurations: list[ShiftConfig] | None = None
    is_active: bool | None = None
    color: str | None = None


# ---------------------------------------------------------------- scheduling
class ScheduleCreate(BaseModel):
    department_id: str
    start_date: date
    days: int = Field(default=7, ge=1, le=31)
    requirement_overrides: dict[str, int] = {}


class RequirementUpdate(BaseModel):
    requirement_overrides: dict[str, int]


class GenerateRequest(BaseModel):
    presets: list[Preset] = Field(default_factory=lambda: [Preset.BALANCED], min_length=1)


class ScenarioIn(BaseModel):
    absent_employee_ids: list[str] = []
    absent_count: int = Field(default=0, ge=0, le=50)
    demand_increase_pct: int = Field(default=0, ge=0, le=300)
    workforce_reduction_pct: int = Field(default=0, ge=0, le=90)
    extra_skill: SkillMixIn | None = None
    max_weekly_hours: float | None = Field(default=None, ge=4, le=80)
    preset: Preset = Preset.BALANCED


class ApplyRunRequest(BaseModel):
    variant: str = "balanced"


class AssignmentCreate(BaseModel):
    shift_id: str
    employee_id: str
    locked: bool = False


class AssignmentValidate(BaseModel):
    shift_id: str
    employee_id: str
    exclude_assignment_id: str | None = None


class AssignmentMove(BaseModel):
    target_shift_id: str


class AssignmentPatch(BaseModel):
    locked: bool


class AbsenceRequest(BaseModel):
    reason: str = Field(min_length=3, max_length=300)


class ReplacementRequest(BaseModel):
    employee_id: str


# ---------------------------------------------------------------- availability / leave / swaps
class AvailabilityWindow(BaseModel):
    weekday: int = Field(ge=0, le=6)
    start: str = Field(pattern=HHMM)
    end: str = Field(pattern=HHMM)


class AvailabilityIn(BaseModel):
    recurring: list[AvailabilityWindow] = []
    unavailable_dates: list[date] = []
    preferred_shifts: list[str] = []
    preferred_days_off: list[int] = []
    notes: str | None = Field(default=None, max_length=500)

    @field_validator("preferred_days_off")
    @classmethod
    def days(cls, v: list[int]) -> list[int]:
        if any(d < 0 or d > 6 for d in v):
            raise ValueError("Days must be between 0 (Monday) and 6 (Sunday)")
        return sorted(set(v))


class LeaveCreate(BaseModel):
    leave_type: LeaveType
    start_date: date
    end_date: date
    reason: str = Field(min_length=3, max_length=500)


class Decision(BaseModel):
    approve: bool
    note: str | None = Field(default=None, max_length=500)


class SwapCreate(BaseModel):
    assignment_id: str
    target_employee_id: str
    target_assignment_id: str | None = None
    message: str | None = Field(default=None, max_length=300)


class SwapResponse(BaseModel):
    accept: bool


class RulesUpdate(BaseModel):
    min_rest_hours: float | None = Field(default=None, ge=0, le=48)
    max_consecutive_days: int | None = Field(default=None, ge=1, le=14)
    overtime_threshold_hours: float | None = Field(default=None, ge=0, le=80)
    overtime_multiplier: float | None = Field(default=None, ge=1, le=3)
    allow_understaffing: bool | None = None
    solver_time_limit_seconds: float | None = Field(default=None, ge=1, le=120)
    weights: dict[str, dict[str, int]] | None = None
    timezone: str | None = None
    organization_name: str | None = None

    @field_validator("weights")
    @classmethod
    def check_weights(cls, v):
        if v is None:
            return v
        allowed = {"unfilled", "cost", "preference", "fairness", "night_balance", "weekend_balance", "overtime", "stability"}
        for preset, w in v.items():
            if preset not in {"balanced", "cost", "wellbeing"}:
                raise ValueError(f"Unknown preset {preset}")
            for k, val in w.items():
                if k not in allowed or not 0 <= val <= 100000:
                    raise ValueError(f"Invalid weight {k}={val}")
        return v


class Message(BaseModel):
    message: str
    data: dict[str, Any] | None = None


SortDir = Literal["asc", "desc"]
