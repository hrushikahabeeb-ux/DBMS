"""Builds optimizer/validator inputs from MongoDB documents."""
from __future__ import annotations

from datetime import date, timedelta

from bson import ObjectId
from pymongo.asynchronous.client_session import AsyncClientSession

from app.database.mongo import Collections as C
from app.database.mongo import get_db
from app.optimization.presets import DEFAULT_WEIGHTS
from app.optimization.types import EmployeeIn, FixedInterval, Rules, ShiftIn, SkillMix, Weights, Window
from app.utils.timeutils import parse_hhmm, to_local, week_key


async def get_rules_doc(session: AsyncClientSession | None = None) -> dict:
    doc = await get_db()[C.SCHEDULING_RULES].find_one({"scope": "organization"}, session=session)
    if doc is None:
        from app.database.init_db import default_rules
        doc = default_rules()
    return doc


def rules_model(doc: dict) -> Rules:
    return Rules(
        min_rest_hours=doc.get("min_rest_hours", 11),
        max_consecutive_days=doc.get("max_consecutive_days", 6),
        overtime_threshold_hours=doc.get("overtime_threshold_hours", 40),
        overtime_multiplier=doc.get("overtime_multiplier", 1.5),
        allow_understaffing=doc.get("allow_understaffing", True),
        time_limit_seconds=doc.get("solver_time_limit_seconds", 10),
    )


def weights_for(doc: dict, presets: list[str]) -> dict[str, Weights]:
    configured = {**DEFAULT_WEIGHTS, **(doc.get("weights") or {})}
    return {p: Weights(**configured.get(p, DEFAULT_WEIGHTS["balanced"])) for p in presets}


def shift_in(doc: dict, tz: str) -> ShiftIn:
    local_start = to_local(doc["start"], tz)
    local_date = date.fromisoformat(doc["local_date"])
    start_min = parse_hhmm(local_start.strftime("%H:%M"))
    dur_min = int(round(doc["duration_hours"] * 60))
    return ShiftIn(
        id=str(doc["_id"]), department_id=str(doc["department_id"]), template_code=doc["template_code"],
        name=doc.get("name", doc["template_code"].title()), local_date=doc["local_date"], weekday=local_date.weekday(),
        week_key=week_key(local_date), start=doc["start"], end=doc["end"], local_start_min=start_min,
        local_end_min=start_min + dur_min, duration_hours=doc["duration_hours"], required_staff=doc["required_staff"],
        required_skills=doc.get("required_skills", []), skill_mix=[SkillMix(**m) for m in doc.get("skill_mix", [])],
        is_night=doc.get("is_night", False), is_weekend=doc.get("is_weekend", False),
    )


def fixed_from_assignment(a: dict, tz: str) -> FixedInterval:
    ls = to_local(a["start"], tz)
    le = to_local(a["end"], tz)
    ld = ls.date()
    return FixedInterval(shift_id=str(a["shift_id"]), department_id=str(a["department_id"]), start=a["start"],
                         end=a["end"], duration_hours=a["duration_hours"], local_date=ld.isoformat(),
                         week_key=week_key(ld), label=f"the {ls:%H:%M}-{le:%H:%M} shift on {ld.isoformat()}")


def windows_from(avail: dict | None) -> list[Window]:
    if not avail:
        return []
    out = []
    for r in avail.get("recurring", []):
        s, e = parse_hhmm(r["start"]), parse_hhmm(r["end"])
        if e <= s:
            e += 1440
        out.append(Window(weekday=r["weekday"], start_min=s, end_min=e))
    return out


async def leave_dates_by_employee(employee_ids: list[ObjectId], start: date, end: date,
                                  session: AsyncClientSession | None = None) -> dict[ObjectId, set[str]]:
    out: dict[ObjectId, set[str]] = {e: set() for e in employee_ids}
    cursor = get_db()[C.LEAVE_REQUESTS].find(
        {"employee_id": {"$in": employee_ids}, "status": "approved",
         "start_date": {"$lte": end.isoformat()}, "end_date": {"$gte": start.isoformat()}}, session=session)
    async for lv in cursor:
        d = max(date.fromisoformat(lv["start_date"]), start)
        last = min(date.fromisoformat(lv["end_date"]), end)
        while d <= last:
            out[lv["employee_id"]].add(d.isoformat())
            d += timedelta(days=1)
    return out


async def employees_in(employee_docs: list[dict], tz: str, start: date, end: date,
                       exclude_schedule_id: ObjectId | None = None,
                       exclude_assignment_ids: list[ObjectId] | None = None,
                       session: AsyncClientSession | None = None) -> list[EmployeeIn]:
    """Convert employees; ``fixed`` holds active assignments outside the excluded schedule/assignments."""
    db = get_db()
    ids = [e["_id"] for e in employee_docs]
    avail = {a["employee_id"]: a async for a in db[C.AVAILABILITY].find({"employee_id": {"$in": ids}}, session=session)}
    leave = await leave_dates_by_employee(ids, start - timedelta(days=1), end + timedelta(days=1), session=session)
    q: dict = {"employee_id": {"$in": ids}, "status": "active",
               "start": {"$lt": _dt_bound(end + timedelta(days=9))},
               "end": {"$gt": _dt_bound(start - timedelta(days=9))}}
    if exclude_schedule_id is not None:
        q["schedule_id"] = {"$ne": exclude_schedule_id}
    if exclude_assignment_ids:
        q["_id"] = {"$nin": exclude_assignment_ids}
    fixed: dict[ObjectId, list[FixedInterval]] = {i: [] for i in ids}
    async for a in db[C.ASSIGNMENTS].find(q, session=session):
        fixed[a["employee_id"]].append(fixed_from_assignment(a, tz))
    out = []
    for e in employee_docs:
        av = avail.get(e["_id"])
        out.append(EmployeeIn(
            id=str(e["_id"]), code=e["employee_code"], name=e["full_name"],
            department_ids=[str(d) for d in e.get("department_ids", [])], skills=e.get("skills", []),
            active=e.get("status") == "active", max_weekly_hours=e.get("max_weekly_hours", 40),
            hourly_wage=e.get("hourly_wage", 0),
            preferred_shifts=(av or {}).get("preferred_shifts") or e.get("preferred_shifts", []),
            preferred_days_off=(av or {}).get("preferred_days_off", []),
            windows=windows_from(av), unavailable_dates=(av or {}).get("unavailable_dates", []),
            leave_dates=sorted(leave.get(e["_id"], set())), fixed=fixed.get(e["_id"], []),
        ))
    return out


def _dt_bound(d: date):
    from datetime import datetime, timezone
    return datetime(d.year, d.month, d.day, tzinfo=timezone.utc)


async def schedule_context(schedule: dict, session: AsyncClientSession | None = None) -> dict:
    """Everything needed to optimize or verify one schedule."""
    db = get_db()
    rules_doc = await get_rules_doc(session)
    tz = rules_doc["timezone"]
    shifts = [s async for s in db[C.SHIFTS].find({"schedule_id": schedule["_id"]}, session=session).sort("start", 1)]
    assignments = [a async for a in db[C.ASSIGNMENTS].find({"schedule_id": schedule["_id"], "status": "active"},
                                                            session=session)]
    assigned_ids = list({a["employee_id"] for a in assignments})
    emp_docs = [e async for e in db[C.EMPLOYEES].find(
        {"$or": [{"department_ids": schedule["department_id"], "status": "active"}, {"_id": {"$in": assigned_ids}}]},
        session=session).sort("employee_code", 1)]
    start, end = date.fromisoformat(schedule["start_date"]), date.fromisoformat(schedule["end_date"])
    employees = await employees_in(emp_docs, tz, start, end, exclude_schedule_id=schedule["_id"], session=session)
    return {
        "rules_doc": rules_doc, "rules": rules_model(rules_doc), "tz": tz,
        "shift_docs": shifts, "shifts": [shift_in(s, tz) for s in shifts],
        "employee_docs": emp_docs, "employees": employees, "assignments": assignments,
    }


async def employee_context(employee_id: ObjectId, around: dict, exclude_assignment_ids: list[ObjectId] | None = None,
                           session: AsyncClientSession | None = None) -> tuple[EmployeeIn | None, dict]:
    """Single employee with all active assignments near ``around`` (a shift doc) as fixed intervals."""
    db = get_db()
    emp = await db[C.EMPLOYEES].find_one({"_id": employee_id}, session=session)
    rules_doc = await get_rules_doc(session)
    if not emp:
        return None, rules_doc
    d = date.fromisoformat(around["local_date"])
    [emp_in] = await employees_in([emp], rules_doc["timezone"], d, d, exclude_assignment_ids=exclude_assignment_ids,
                                  session=session)
    return emp_in, rules_doc
