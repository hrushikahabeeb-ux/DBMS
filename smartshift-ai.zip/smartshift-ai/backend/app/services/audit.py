"""Audit logging of every state-changing action."""
from typing import Any

from bson import ObjectId
from pymongo.asynchronous.client_session import AsyncClientSession

from app.core.logging import get_correlation_id
from app.database.mongo import Collections as C
from app.database.mongo import get_db
from app.utils.timeutils import utcnow


async def audit(actor, action: str, entity_type: str, entity_id: ObjectId | str | None = None,
                details: dict[str, Any] | None = None, session: AsyncClientSession | None = None) -> None:
    doc = {
        "action": action,
        "entity_type": entity_type,
        "entity_id": str(entity_id) if entity_id is not None else None,
        "details": details or {},
        "correlation_id": get_correlation_id(),
        "created_at": utcnow(),
        "actor_user_id": None,
        "actor_email": "system",
        "actor_role": "system",
    }
    if actor is not None:
        doc.update(actor.audit_actor())
    await get_db()[C.AUDIT_LOGS].insert_one(doc, session=session)
