"""Assignment lifecycle with backend validation and transaction safety.

Concurrency strategy
* Every mutation runs in a MongoDB transaction.
* The employee document's ``version`` is incremented first. Two concurrent
  transactions touching the same employee therefore write-conflict; MongoDB aborts
  one, ``with_transaction`` retries it, and the retry re-validates against the
  committed state (so double-booking is impossible).
* Shift capacity uses a conditional ``$inc`` (``assigned_count < required_staff``)
  so a shift can never be overfilled, even under concurrent requests.
"""
from __future__ import annotations

import statistics
from datetime import date

from bson import ObjectId
from pymongo.asynchronous.client_session import AsyncClientSession

from app.core.errors import ConflictError, NotFoundError
from app.database.mongo import Collections as C
from app.database.mongo import get_db, run_transaction, serialize
from app.models.enums import AssignmentSource, AssignmentStatus
from app.optimization.constraints import Interval, evaluate, preference_matched, verify
from app.services import events
from app.services.audit import audit
from app.services.scheduling_data import employee_context, rules_model, schedule_context, shift_in
from app.utils.timeutils import utcnow


async def _load_shift(shift_id: ObjectId, session=None) -> tuple[dict, dict]:
    db = get_db()
    shift = await db[C.SHIFTS].find_one({"_id": shift_id}, session=session)
    if not shift:
        raise NotFoundError("Shift not found")
    schedule = await db[C.SCHEDULES].find_one({"_id": shift["schedule_id"]}, session=session)
    if not schedule:
        raise NotFoundError("Schedule not found")
    return shift, schedule


async def validate_pair(employee_id: ObjectId, shift: dict, exclude: list[ObjectId] | None = None,
                        session: AsyncClientSession | None = None) -> dict:
    emp_in, rules_doc = await employee_context(employee_id, shift, exclude_assignment_ids=exclude, session=session)
    if emp_in is None:
        raise NotFoundError("Employee not found")
    s_in = shift_in(shift, rules_doc["timezone"])
    others = [Interval.from_fixed(f) for f in emp_in.fixed]
    result = evaluate(emp_in, s_in, others, rules_model(rules_doc))
    full = shift.get("assigned_count", 0) >= shift["required_staff"]
    result["capacity"] = {"assigned": shift.get("assigned_count", 0), "required": shift["required_staff"], "full": full}
    result["employee"] = {"id": emp_in.id, "name": emp_in.name, "code": emp_in.code}
    return result


async def _bump_employee(employee_id: ObjectId, session) -> None:
    res = await get_db()[C.EMPLOYEES].update_one({"_id": employee_id}, {"$inc": {"version": 1}}, session=session)
    if res.matched_count == 0:
        raise NotFoundError("Employee not found")


async def _reserve_slot(shift_id: ObjectId, session) -> None:
    db = get_db()
    res = await db[C.SHIFTS].update_one(
        {"_id": shift_id, "$expr": {"$lt": ["$assigned_count", "$required_staff"]}},
        {"$inc": {"assigned_count": 1}}, session=session)
    if res.modified_count == 0:
        raise ConflictError("This shift is already fully staffed", {"type": "capacity"})


async def _release_slot(shift_id: ObjectId, session) -> None:
    await get_db()[C.SHIFTS].update_one({"_id": shift_id, "assigned_count": {"$gt": 0}},
                                        {"$inc": {"assigned_count": -1}}, session=session)


async def create_in_session(session, actor, shift_id: ObjectId, employee_id: ObjectId, source: AssignmentSource,
                            locked: bool = False, extra: dict | None = None, exclude: list[ObjectId] | None = None) -> dict:
    db = get_db()
    shift, schedule = await _load_shift(shift_id, session)
    await _bump_employee(employee_id, session)
    check = await validate_pair(employee_id, shift, exclude=exclude, session=session)
    if not check["valid"]:
        raise ConflictError("Assignment violates scheduling constraints", {"type": "constraints", **check})
    await _reserve_slot(shift_id, session)
    now = utcnow()
    doc = {
        "schedule_id": schedule["_id"], "shift_id": shift_id, "employee_id": employee_id,
        "department_id": shift["department_id"], "start": shift["start"], "end": shift["end"],
        "duration_hours": shift["duration_hours"], "status": AssignmentStatus.ACTIVE.value, "locked": locked,
        "source": source.value, "created_by": actor.id if actor else None, "created_at": now, "updated_at": now,
        **(extra or {}),
    }
    res = await db[C.ASSIGNMENTS].insert_one(doc, session=session)
    doc["_id"] = res.inserted_id
    await audit(actor, "assignment.create", "assignment", res.inserted_id,
                {"shift_id": str(shift_id), "employee_id": str(employee_id), "source": source.value}, session=session)
    return {"assignment": doc, "schedule": schedule, "shift": shift}


async def create_assignment(actor, shift_id: ObjectId, employee_id: ObjectId, locked: bool = False) -> dict:
    async def txn(session):
        return await create_in_session(session, actor, shift_id, employee_id, AssignmentSource.MANUAL, locked)

    out = await run_transaction(txn)
    if out["schedule"]["status"] == "published":
        await _notify_assignment(out["assignment"], out["shift"], "shift.assigned", "New shift assigned")
    return out["assignment"]


async def move_assignment(actor, assignment_id: ObjectId, target_shift_id: ObjectId) -> dict:
    async def txn(session):
        db = get_db()
        a = await db[C.ASSIGNMENTS].find_one({"_id": assignment_id, "status": "active"}, session=session)
        if not a:
            raise NotFoundError("Active assignment not found")
        if a["shift_id"] == target_shift_id:
            return {"assignment": a, "schedule": None, "shift": None}
        target, schedule = await _load_shift(target_shift_id, session)
        if target["department_id"] != a["department_id"]:
            raise ConflictError("Assignments can only be moved within the same department")
        actor.require_department(target["department_id"])
        await _bump_employee(a["employee_id"], session)
        check = await validate_pair(a["employee_id"], target, exclude=[assignment_id], session=session)
        if not check["valid"]:
            raise ConflictError("Move violates scheduling constraints", {"type": "constraints", **check})
        await _reserve_slot(target_shift_id, session)
        await _release_slot(a["shift_id"], session)
        update = {"shift_id": target_shift_id, "schedule_id": schedule["_id"], "start": target["start"],
                  "end": target["end"], "duration_hours": target["duration_hours"],
                  "source": AssignmentSource.MANUAL.value, "updated_at": utcnow()}
        await db[C.ASSIGNMENTS].update_one({"_id": assignment_id}, {"$set": update}, session=session)
        await audit(actor, "assignment.move", "assignment", assignment_id,
                    {"from_shift": str(a["shift_id"]), "to_shift": str(target_shift_id)}, session=session)
        return {"assignment": {**a, **update}, "schedule": schedule, "shift": target}

    out = await run_transaction(txn)
    if out["schedule"] and out["schedule"]["status"] == "published":
        await _notify_assignment(out["assignment"], out["shift"], "shift.modified", "Shift changed")
    return out["assignment"]


async def cancel_assignment(actor, assignment_id: ObjectId) -> None:
    async def txn(session):
        db = get_db()
        a = await db[C.ASSIGNMENTS].find_one_and_update(
            {"_id": assignment_id, "status": "active"},
            {"$set": {"status": AssignmentStatus.CANCELLED.value, "updated_at": utcnow()}}, session=session)
        if not a:
            raise NotFoundError("Active assignment not found")
        actor.require_department(a["department_id"])
        await _release_slot(a["shift_id"], session)
        await audit(actor, "assignment.cancel", "assignment", assignment_id, {}, session=session)
        return a

    a = await run_transaction(txn)
    shift = await get_db()[C.SHIFTS].find_one({"_id": a["shift_id"]})
    sched = await get_db()[C.SCHEDULES].find_one({"_id": a["schedule_id"]})
    if sched and sched["status"] == "published":
        await _notify_assignment(a, shift, "shift.modified", "Shift removed")


async def _notify_assignment(a: dict, shift: dict, ntype: str, title: str) -> None:
    users = await events.user_ids_for_employees([a["employee_id"]])
    await events.publish_notification(
        users, ntype, title, f"{shift.get('name', shift['template_code']).title()} shift on {shift['local_date']}",
        {"assignment_id": str(a["_id"]), "shift_id": str(shift["_id"])})


# ---------------------------------------------------------------- conflicts
async def schedule_conflicts(schedule: dict) -> list[dict]:
    ctx = await schedule_context(schedule)
    pairs = [(str(a["shift_id"]), str(a["employee_id"])) for a in ctx["assignments"]]
    violations = verify(ctx["shifts"], ctx["employees"], pairs, ctx["rules"])
    names = {e.id: e.name for e in ctx["employees"]}
    shifts = {s.id: s for s in ctx["shifts"]}
    by_pair = {(str(a["shift_id"]), str(a["employee_id"])): str(a["_id"]) for a in ctx["assignments"]}
    out = []
    for v in violations:
        d = v.to_dict()
        d["employee_name"] = names.get(v.employee_id)
        s = shifts.get(v.shift_id) if v.shift_id else None
        d["shift_label"] = f"{s.name} {s.local_date}" if s else None
        d["assignment_id"] = by_pair.get((v.shift_id, v.employee_id)) if v.employee_id else None
        out.append(d)
    order = {"high": 0, "medium": 1, "low": 2}
    out.sort(key=lambda d: (order.get(d["severity"], 3), d.get("shift_label") or ""))
    return out


# ---------------------------------------------------------------- explanations
async def explain_assignment(assignment_id: ObjectId) -> dict:
    db = get_db()
    a = await db[C.ASSIGNMENTS].find_one({"_id": assignment_id})
    if not a:
        raise NotFoundError("Assignment not found")
    shift = await db[C.SHIFTS].find_one({"_id": a["shift_id"]})
    emp_in, rules_doc = await employee_context(a["employee_id"], shift, exclude_assignment_ids=[assignment_id])
    s_in = shift_in(shift, rules_doc["timezone"])
    rules = rules_model(rules_doc)
    result = evaluate(emp_in, s_in, [Interval.from_fixed(f) for f in emp_in.fixed], rules)

    dept_emps = [e async for e in db[C.EMPLOYEES].find({"department_ids": a["department_id"], "status": "active"})]
    wages = [e["hourly_wage"] for e in dept_emps] or [emp_in.hourly_wage]
    median_wage = statistics.median(wages)
    week_hours = sum(f.duration_hours for f in emp_in.fixed if f.week_key == s_in.week_key) + s_in.duration_hours
    run = await db[C.OPTIMIZATION_RUNS].find_one({"_id": a["run_id"]}) if a.get("run_id") else None

    passed = [c["message"] for c in result["checks"] if c["passed"]]
    summary = (f"{emp_in.name} was eligible for this shift: " + "; ".join(m[0].lower() + m[1:] for m in passed[:5]) + ".")
    if not result["valid"]:
        summary = (f"Warning: this assignment currently fails {len(result['failed'])} check(s): "
                   + "; ".join(c["message"] for c in result["failed"]) + ".")
    factors = [
        {"term": "preference", "value": preference_matched(emp_in, s_in),
         "detail": "Matches stated preferences (no preference penalty)" if preference_matched(emp_in, s_in)
         else "Does not match stated preferences (incurs a preference penalty)"},
        {"term": "cost", "value": emp_in.hourly_wage,
         "detail": f"Hourly wage {emp_in.hourly_wage:g} vs department median {median_wage:g}"},
        {"term": "workload", "value": round(week_hours, 2),
         "detail": f"{week_hours:g}h of {emp_in.max_weekly_hours:g}h contract in week {s_in.week_key} "
                   f"({round(100 * week_hours / emp_in.max_weekly_hours)}% load)"},
    ]
    return {
        "assignment": serialize(a),
        "employee": {"id": emp_in.id, "name": emp_in.name, "code": emp_in.code, "skills": emp_in.skills},
        "shift": serialize(shift),
        "source": a["source"],
        "valid": result["valid"],
        "summary": summary,
        "checks": result["checks"],
        "preferences": result["preferences"],
        "objective_factors": factors,
        "run": {"id": str(run["_id"]), "preset": a.get("preset"), "solver_status":
                (run.get("result") or {}).get("variants", {}).get(a.get("preset") or "", {}).get("solver_status")}
        if run else None,
        "note": "Explanations are derived from the same constraint checks and objective terms the optimizer uses. "
                "Objective factors show what the solver weighed; the final choice reflects the whole schedule, "
                "not a single factor.",
    }


# ---------------------------------------------------------------- replacement
def _rank(candidate: dict, wage_min: float, wage_max: float) -> dict:
    emp = candidate["emp"]
    s = candidate["shift"]
    load_after = candidate["week_hours_after"] / emp.max_weekly_hours if emp.max_weekly_hours else 1
    pref_shift = not emp.preferred_shifts or s.template_code in emp.preferred_shifts
    not_off = s.weekday not in emp.preferred_days_off
    gap = candidate["nearest_gap_hours"]
    rest_norm = 1.0 if gap is None else min(gap, 48) / 48
    wage_norm = 0.0 if wage_max == wage_min else (emp.hourly_wage - wage_min) / (wage_max - wage_min)
    parts = {
        "preferred_shift_type": 30 * int(pref_shift),
        "not_preferred_day_off": 15 * int(not_off),
        "remaining_capacity": round(25 * max(0.0, 1 - load_after), 2),
        "rest_margin": round(15 * rest_norm, 2),
        "cost_efficiency": round(15 * (1 - wage_norm), 2),
    }
    return {"score": round(sum(parts.values()), 2), "breakdown": parts}


async def replacement_candidates(assignment: dict) -> dict:
    db = get_db()
    shift = await db[C.SHIFTS].find_one({"_id": assignment["shift_id"]})
    rules_doc_emp = [e async for e in db[C.EMPLOYEES].find({"department_ids": assignment["department_id"],
                                                             "status": "active",
                                                             "_id": {"$ne": assignment["employee_id"]}})]
    from app.services.scheduling_data import employees_in, get_rules_doc
    rules_doc = await get_rules_doc()
    d = date.fromisoformat(shift["local_date"])
    emps = await employees_in(rules_doc_emp, rules_doc["timezone"], d, d)
    rules = rules_model(rules_doc)
    s_in = shift_in(shift, rules_doc["timezone"])
    valid, rejected = [], []
    for emp in emps:
        others = [Interval.from_fixed(f) for f in emp.fixed]
        res = evaluate(emp, s_in, others, rules)
        if not res["valid"]:
            rejected.append({"employee_id": emp.id, "name": emp.name, "code": emp.code,
                             "reasons": [c["message"] for c in res["failed"]]})
            continue
        gaps = []
        for o in others:
            first, second = (s_in, o) if s_in.start <= o.start else (o, s_in)
            gaps.append((second.start - first.end).total_seconds() / 3600)
        week_after = sum(o.duration_hours for o in others if o.week_key == s_in.week_key) + s_in.duration_hours
        valid.append({"emp": emp, "shift": s_in, "checks": res["checks"], "preferences": res["preferences"],
                      "week_hours_after": week_after, "nearest_gap_hours": min((g for g in gaps if g >= 0), default=None)})
    wages = [c["emp"].hourly_wage for c in valid] or [0]
    ranked = []
    for c in valid:
        r = _rank(c, min(wages), max(wages))
        emp = c["emp"]
        reasons = [ch["message"] for ch in c["checks"] if ch["passed"]][:6]
        ranked.append({"employee_id": emp.id, "name": emp.name, "code": emp.code, "skills": emp.skills,
                       "hourly_wage": emp.hourly_wage, "week_hours_after": c["week_hours_after"],
                       "max_weekly_hours": emp.max_weekly_hours, "nearest_gap_hours": c["nearest_gap_hours"],
                       "score": r["score"], "breakdown": r["breakdown"], "checks": c["checks"],
                       "preferences": c["preferences"], "reasons": reasons})
    ranked.sort(key=lambda c: (-c["score"], c["code"]))
    for i, c in enumerate(ranked, 1):
        c["rank"] = i
    return {
        "shift": serialize(shift),
        "candidates": ranked,
        "rejected": sorted(rejected, key=lambda r: r["code"]),
        "shortage": not ranked,
        "ranking_formula": "score = 30*preferred_shift_type + 15*not_preferred_day_off + 25*(1 - weekly_load_after) "
                           "+ 15*min(nearest_rest_gap,48h)/48h + 15*(1 - normalized_wage); ties broken by employee code",
    }


async def mark_absent(actor, assignment_id: ObjectId, reason: str) -> dict:
    async def txn(session):
        db = get_db()
        a = await db[C.ASSIGNMENTS].find_one({"_id": assignment_id, "status": "active"}, session=session)
        if not a:
            raise NotFoundError("Active assignment not found")
        actor.require_department(a["department_id"])
        await db[C.ASSIGNMENTS].update_one(
            {"_id": assignment_id},
            {"$set": {"status": AssignmentStatus.ABSENT.value, "absence_reason": reason, "absent_at": utcnow(),
                      "absent_marked_by": actor.id, "replaced_by_assignment_id": None, "updated_at": utcnow()}},
            session=session)
        await _release_slot(a["shift_id"], session)
        await audit(actor, "assignment.absent", "assignment", assignment_id, {"reason": reason}, session=session)
        return a

    a = await run_transaction(txn)
    users = await events.user_ids_for_employees([a["employee_id"]])
    await events.publish_notification(users, "shift.absence", "Marked absent",
                                      f"You were marked absent: {reason}", {"assignment_id": str(assignment_id)})
    a["status"] = "absent"
    return await replacement_candidates(a)


async def approve_replacement(actor, assignment_id: ObjectId, employee_id: ObjectId) -> dict:
    async def txn(session):
        db = get_db()
        old = await db[C.ASSIGNMENTS].find_one_and_update(
            {"_id": assignment_id, "status": AssignmentStatus.ABSENT.value, "replaced_by_assignment_id": None},
            {"$set": {"status": AssignmentStatus.REPLACED.value, "updated_at": utcnow()}}, session=session)
        if not old:
            raise ConflictError("This absence has already been resolved or does not exist")
        actor.require_department(old["department_id"])
        out = await create_in_session(session, actor, old["shift_id"], employee_id, AssignmentSource.REPLACEMENT,
                                      locked=True, extra={"replaces_assignment_id": assignment_id})
        await db[C.ASSIGNMENTS].update_one({"_id": assignment_id},
                                           {"$set": {"replaced_by_assignment_id": out["assignment"]["_id"]}},
                                           session=session)
        await audit(actor, "assignment.replace", "assignment", assignment_id,
                    {"replacement_employee_id": str(employee_id)}, session=session)
        return {"old": old, **out}

    out = await run_transaction(txn)
    shift = out["shift"]
    new_users = await events.user_ids_for_employees([employee_id])
    old_users = await events.user_ids_for_employees([out["old"]["employee_id"]])
    label = f"{shift.get('name', shift['template_code'])} shift on {shift['local_date']}"
    await events.publish_notification(new_users, "shift.emergency_replacement", "Emergency shift assigned",
                                      f"You have been assigned as an emergency replacement for the {label}.",
                                      {"assignment_id": str(out["assignment"]["_id"])})
    await events.publish_notification(old_users, "shift.modified", "Shift covered",
                                      f"Your {label} has been covered by a colleague.", {})
    return out["assignment"]


async def open_vacancies(scope: list[ObjectId] | None) -> list[dict]:
    db = get_db()
    q: dict = {"status": "absent", "replaced_by_assignment_id": None, "end": {"$gte": utcnow()}}
    if scope is not None:
        q["department_id"] = {"$in": scope}
    pipeline = [
        {"$match": q}, {"$sort": {"start": 1}}, {"$limit": 100},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id", "as": "employee",
                     "pipeline": [{"$project": {"full_name": 1, "employee_code": 1}}]}},
        {"$lookup": {"from": C.SHIFTS, "localField": "shift_id", "foreignField": "_id", "as": "shift"}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "department",
                     "pipeline": [{"$project": {"name": 1, "code": 1}}]}},
        {"$unwind": "$employee"}, {"$unwind": "$shift"}, {"$unwind": "$department"},
    ]
    return [serialize(d) async for d in await db[C.ASSIGNMENTS].aggregate(pipeline)]
