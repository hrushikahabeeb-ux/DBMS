"""Leave and shift-swap workflows."""
from __future__ import annotations

from datetime import date

from bson import ObjectId

from app.core.errors import ConflictError, ForbiddenError, NotFoundError, ValidationFailed
from app.database.mongo import Collections as C
from app.database.mongo import get_db, run_transaction
from app.models.enums import AssignmentSource, LeaveStatus, SwapStatus
from app.services import events
from app.services.assignment_service import _bump_employee, _release_slot, validate_pair
from app.services.audit import audit
from app.utils.timeutils import utcnow


# ------------------------------------------------------------------ leave
async def request_leave(actor, employee: dict, leave_type: str, start: date, end: date, reason: str) -> dict:
    if end < start:
        raise ValidationFailed("Leave end date must be on or after the start date")
    db = get_db()
    overlap = await db[C.LEAVE_REQUESTS].find_one({
        "employee_id": employee["_id"], "status": {"$in": ["pending", "approved"]},
        "start_date": {"$lte": end.isoformat()}, "end_date": {"$gte": start.isoformat()}})
    if overlap:
        raise ConflictError("You already have a pending or approved leave request overlapping these dates")
    now = utcnow()
    doc = {"employee_id": employee["_id"], "department_id": employee["primary_department_id"], "leave_type": leave_type,
           "start_date": start.isoformat(), "end_date": end.isoformat(), "reason": reason,
           "status": LeaveStatus.PENDING.value, "history": [{"status": "pending", "by": actor.id, "at": now}],
           "created_at": now, "updated_at": now}
    res = await db[C.LEAVE_REQUESTS].insert_one(doc)
    doc["_id"] = res.inserted_id
    await audit(actor, "leave.request", "leave_request", res.inserted_id, {"type": leave_type})
    managers = await events.manager_user_ids(employee["primary_department_id"])
    await events.publish_notification(managers, "leave.requested", "Leave request",
                                      f"{employee['full_name']} requested {leave_type} leave {doc['start_date']} to "
                                      f"{doc['end_date']}", {"leave_id": str(res.inserted_id)})
    return doc


async def leave_conflicts(leave: dict, session=None) -> list[dict]:
    db = get_db()
    shift_ids = await db[C.SHIFTS].distinct(
        "_id", {"local_date": {"$gte": leave["start_date"], "$lte": leave["end_date"]}}, session=session)
    return [a async for a in db[C.ASSIGNMENTS].find(
        {"employee_id": leave["employee_id"], "status": "active", "shift_id": {"$in": shift_ids}}, session=session)]


async def decide_leave(actor, leave_id: ObjectId, approve: bool, note: str | None) -> dict:
    db = get_db()

    async def txn(session):
        leave = await db[C.LEAVE_REQUESTS].find_one({"_id": leave_id}, session=session)
        if not leave:
            raise NotFoundError("Leave request not found")
        actor.require_department(leave["department_id"])
        new_status = "approved" if approve else "rejected"
        now = utcnow()
        res = await db[C.LEAVE_REQUESTS].update_one(
            {"_id": leave_id, "status": "pending"},
            {"$set": {"status": new_status, "decided_by": actor.id, "decided_at": now, "decision_note": note,
                      "updated_at": now},
             "$push": {"history": {"status": new_status, "by": actor.id, "at": now, "note": note}}}, session=session)
        if res.modified_count == 0:
            raise ConflictError("This leave request has already been decided")
        affected = []
        if approve:
            await _bump_employee(leave["employee_id"], session)
            for a in await leave_conflicts(leave, session):
                await db[C.ASSIGNMENTS].update_one(
                    {"_id": a["_id"]},
                    {"$set": {"status": "absent", "absence_reason": f"Approved {leave['leave_type']} leave",
                              "absent_at": now, "replaced_by_assignment_id": None, "leave_id": leave_id,
                              "updated_at": now}}, session=session)
                await _release_slot(a["shift_id"], session)
                affected.append(a)
            if affected:
                await db[C.LEAVE_REQUESTS].update_one({"_id": leave_id},
                                                      {"$set": {"affected_assignment_ids": [a["_id"] for a in affected]}},
                                                      session=session)
        await audit(actor, f"leave.{new_status}", "leave_request", leave_id,
                    {"affected_assignments": len(affected)}, session=session)
        return leave, affected, new_status

    leave, affected, status = await run_transaction(txn)
    users = await events.user_ids_for_employees([leave["employee_id"]])
    await events.publish_notification(users, f"leave.{status}", f"Leave {status}",
                                      f"Your leave {leave['start_date']} to {leave['end_date']} was {status}.",
                                      {"leave_id": str(leave_id)})
    if affected:
        managers = await events.manager_user_ids(leave["department_id"])
        await events.publish_notification(managers, "replacement.needed", "Replacement needed",
                                          f"Approved leave left {len(affected)} published shift(s) uncovered. "
                                          f"Open Emergency Replacement to assign cover.",
                                          {"leave_id": str(leave_id)})
    return {"status": status, "affected_assignments": [str(a["_id"]) for a in affected],
            "replacement_required": bool(affected)}


# ------------------------------------------------------------------ swaps
async def _validate_exchange(req_assign: dict, target_emp_id: ObjectId, target_assign: dict | None, session=None) -> dict:
    db = get_db()
    shift_a = await db[C.SHIFTS].find_one({"_id": req_assign["shift_id"]}, session=session)
    excl_target = [target_assign["_id"]] if target_assign else []
    target_takes = await validate_pair(target_emp_id, shift_a, exclude=excl_target, session=session)
    out = {"target_takes_requester_shift": target_takes, "valid": target_takes["valid"]}
    if target_assign:
        shift_b = await db[C.SHIFTS].find_one({"_id": target_assign["shift_id"]}, session=session)
        requester_takes = await validate_pair(req_assign["employee_id"], shift_b, exclude=[req_assign["_id"]],
                                              session=session)
        out["requester_takes_target_shift"] = requester_takes
        out["valid"] = out["valid"] and requester_takes["valid"]
    return out


def _summary(validation: dict) -> list[str]:
    msgs = []
    for key in ("target_takes_requester_shift", "requester_takes_target_shift"):
        if key in validation:
            msgs += [c["message"] for c in validation[key]["failed"]]
    return msgs


async def create_swap(actor, requester: dict, assignment_id: ObjectId, target_employee_id: ObjectId,
                      target_assignment_id: ObjectId | None, message: str | None) -> dict:
    db = get_db()
    a = await db[C.ASSIGNMENTS].find_one({"_id": assignment_id, "status": "active"})
    if not a or a["employee_id"] != requester["_id"]:
        raise ForbiddenError("You can only request swaps for your own active shifts")
    if a["start"] <= utcnow():
        raise ValidationFailed("Shifts that have already started cannot be swapped")
    if target_employee_id == requester["_id"]:
        raise ValidationFailed("Choose a colleague to swap with")
    target = await db[C.EMPLOYEES].find_one({"_id": target_employee_id, "status": "active"})
    if not target:
        raise NotFoundError("Colleague not found")
    b = None
    if target_assignment_id:
        b = await db[C.ASSIGNMENTS].find_one({"_id": target_assignment_id, "status": "active"})
        if not b or b["employee_id"] != target_employee_id:
            raise ValidationFailed("The selected shift does not belong to that colleague")
        if b["department_id"] != a["department_id"]:
            raise ValidationFailed("Swaps must be within the same department")
    validation = await _validate_exchange(a, target_employee_id, b)
    if not validation["valid"]:
        raise ConflictError("This swap would violate scheduling constraints", {"reasons": _summary(validation)})
    now = utcnow()
    doc = {"requester_employee_id": requester["_id"], "requester_assignment_id": assignment_id,
           "target_employee_id": target_employee_id, "target_assignment_id": target_assignment_id,
           "department_id": a["department_id"], "kind": "swap" if b else "cover", "message": message,
           "status": SwapStatus.PENDING_PEER.value, "is_open": True,
           "history": [{"status": "pending_peer", "by": actor.id, "at": now}], "created_at": now, "updated_at": now}
    res = await db[C.SWAP_REQUESTS].insert_one(doc)
    doc["_id"] = res.inserted_id
    await audit(actor, "swap.request", "swap_request", res.inserted_id, {"kind": doc["kind"]})
    users = await events.user_ids_for_employees([target_employee_id])
    await events.publish_notification(users, "swap.requested", "Shift swap request",
                                      f"{requester['full_name']} asked you to {'swap shifts' if b else 'cover a shift'}.",
                                      {"swap_id": str(res.inserted_id)})
    return doc


async def respond_swap(actor, employee: dict, swap_id: ObjectId, accept: bool) -> dict:
    db = get_db()
    swap = await db[C.SWAP_REQUESTS].find_one({"_id": swap_id})
    if not swap or swap["target_employee_id"] != employee["_id"]:
        raise NotFoundError("Swap request not found")
    if accept:
        a = await db[C.ASSIGNMENTS].find_one({"_id": swap["requester_assignment_id"], "status": "active"})
        b = (await db[C.ASSIGNMENTS].find_one({"_id": swap["target_assignment_id"], "status": "active"})
             if swap.get("target_assignment_id") else None)
        if not a or (swap.get("target_assignment_id") and not b):
            raise ConflictError("One of the shifts has changed; this swap can no longer proceed")
        validation = await _validate_exchange(a, employee["_id"], b)
        if not validation["valid"]:
            raise ConflictError("This swap would violate scheduling constraints", {"reasons": _summary(validation)})
    new_status = "peer_accepted" if accept else "declined"
    now = utcnow()
    res = await db[C.SWAP_REQUESTS].update_one(
        {"_id": swap_id, "status": "pending_peer"},
        {"$set": {"status": new_status, "is_open": accept, "updated_at": now},
         "$push": {"history": {"status": new_status, "by": actor.id, "at": now}}})
    if res.modified_count == 0:
        raise ConflictError("This swap request is no longer awaiting your response")
    await audit(actor, f"swap.{new_status}", "swap_request", swap_id, {})
    req_users = await events.user_ids_for_employees([swap["requester_employee_id"]])
    await events.publish_notification(req_users, f"swap.{new_status}", "Swap update",
                                      f"{employee['full_name']} {'accepted' if accept else 'declined'} your swap request.",
                                      {"swap_id": str(swap_id)})
    if accept:
        managers = await events.manager_user_ids(swap["department_id"])
        await events.publish_notification(managers, "swap.awaiting_approval", "Swap awaiting approval",
                                          "A shift swap has been accepted and needs manager approval.",
                                          {"swap_id": str(swap_id)})
    return {"status": new_status}


async def decide_swap(actor, swap_id: ObjectId, approve: bool, note: str | None) -> dict:
    db = get_db()

    async def txn(session):
        swap = await db[C.SWAP_REQUESTS].find_one({"_id": swap_id}, session=session)
        if not swap:
            raise NotFoundError("Swap request not found")
        actor.require_department(swap["department_id"])
        new_status = "approved" if approve else "rejected"
        now = utcnow()
        # Conditional transition guards against duplicate or concurrent approvals.
        res = await db[C.SWAP_REQUESTS].update_one(
            {"_id": swap_id, "status": "peer_accepted"},
            {"$set": {"status": new_status, "is_open": False, "decided_by": actor.id, "decided_at": now,
                      "decision_note": note, "updated_at": now},
             "$push": {"history": {"status": new_status, "by": actor.id, "at": now, "note": note}}}, session=session)
        if res.modified_count == 0:
            raise ConflictError("This swap is not awaiting manager approval")
        if approve:
            await _bump_employee(swap["requester_employee_id"], session)
            await _bump_employee(swap["target_employee_id"], session)
            a = await db[C.ASSIGNMENTS].find_one({"_id": swap["requester_assignment_id"], "status": "active",
                                                  "employee_id": swap["requester_employee_id"]}, session=session)
            b = None
            if swap.get("target_assignment_id"):
                b = await db[C.ASSIGNMENTS].find_one({"_id": swap["target_assignment_id"], "status": "active",
                                                      "employee_id": swap["target_employee_id"]}, session=session)
            if not a or (swap.get("target_assignment_id") and not b):
                raise ConflictError("One of the shifts changed after the request; the swap cannot be applied")
            validation = await _validate_exchange(a, swap["target_employee_id"], b, session=session)
            if not validation["valid"]:
                raise ConflictError("The swap now violates scheduling constraints", {"reasons": _summary(validation)})
            await db[C.ASSIGNMENTS].update_one(
                {"_id": a["_id"]}, {"$set": {"employee_id": swap["target_employee_id"], "source": AssignmentSource.SWAP.value,
                                             "swap_id": swap_id, "updated_at": now}}, session=session)
            if b:
                await db[C.ASSIGNMENTS].update_one(
                    {"_id": b["_id"]}, {"$set": {"employee_id": swap["requester_employee_id"],
                                                 "source": AssignmentSource.SWAP.value, "swap_id": swap_id,
                                                 "updated_at": now}}, session=session)
        await audit(actor, f"swap.{new_status}", "swap_request", swap_id, {}, session=session)
        return swap, new_status

    swap, status = await run_transaction(txn)
    users = await events.user_ids_for_employees([swap["requester_employee_id"], swap["target_employee_id"]])
    await events.publish_notification(users, f"swap.{status}", f"Swap {status}",
                                      f"Your shift swap request was {status} by a manager.", {"swap_id": str(swap_id)})
    return {"status": status}


async def cancel_swap(actor, employee: dict, swap_id: ObjectId) -> dict:
    db = get_db()
    now = utcnow()
    res = await db[C.SWAP_REQUESTS].update_one(
        {"_id": swap_id, "requester_employee_id": employee["_id"], "is_open": True},
        {"$set": {"status": "cancelled", "is_open": False, "updated_at": now},
         "$push": {"history": {"status": "cancelled", "by": actor.id, "at": now}}})
    if res.modified_count == 0:
        raise ConflictError("Only your open swap requests can be cancelled")
    await audit(actor, "swap.cancel", "swap_request", swap_id, {})
    return {"status": "cancelled"}
