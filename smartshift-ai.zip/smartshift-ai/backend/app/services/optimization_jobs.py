"""Optimization job processing (runs in the worker process).

The worker owns the read side of scheduling data: it assembles optimizer inputs
from MongoDB, calls the stateless optimizer service over authenticated HTTP and
persists results in ``optimization_runs``.
"""
from __future__ import annotations

import logging
import math

from bson import ObjectId

from app.core.errors import ServiceUnavailableError
from app.core.service_client import optimizer_client
from app.database.mongo import Collections as C
from app.database.mongo import get_db
from app.optimization.metrics import compute_metrics
from app.optimization.types import OptimizeRequest, Pair, SkillMix
from app.services import events
from app.services.scheduling_data import schedule_context, weights_for
from app.utils.timeutils import utcnow

logger = logging.getLogger(__name__)
MAX_JOB_ATTEMPTS = 3


def apply_scenario(req: OptimizeRequest, scenario: dict, assignments: list[dict]) -> dict:
    """Mutates a *copy* of the inputs. Returns a description of the hypothetical changes."""
    changes: dict = {"removed_employees": [], "requirement_changes": {}}
    removed = set(scenario.get("absent_employee_ids") or [])
    count = int(scenario.get("absent_count") or 0)
    if count:
        load: dict[str, int] = {}
        for a in assignments:
            load[str(a["employee_id"])] = load.get(str(a["employee_id"]), 0) + 1
        ranked = sorted([e for e in req.employees if e.active and e.id not in removed],
                        key=lambda e: (-load.get(e.id, 0), e.code))
        removed |= {e.id for e in ranked[:count]}
    pct = int(scenario.get("workforce_reduction_pct") or 0)
    if pct:
        remaining = sorted([e for e in req.employees if e.id not in removed], key=lambda e: e.code, reverse=True)
        removed |= {e.id for e in remaining[: math.floor(len(remaining) * pct / 100)]}
    if removed:
        changes["removed_employees"] = [{"id": e.id, "name": e.name} for e in req.employees if e.id in removed]
        req.employees = [e for e in req.employees if e.id not in removed]
        req.locked = [p for p in req.locked if p.employee_id not in removed]
        req.previous = [p for p in req.previous if p.employee_id not in removed]
    demand = int(scenario.get("demand_increase_pct") or 0)
    if demand:
        for s in req.shifts:
            new = math.ceil(s.required_staff * (1 + demand / 100))
            if new != s.required_staff:
                changes["requirement_changes"][s.id] = new
                s.required_staff = new
    extra = scenario.get("extra_skill")
    if extra and extra.get("skill"):
        for s in req.shifts:
            existing = [m for m in s.skill_mix if m.skill == extra["skill"]]
            if existing:
                existing[0].min = max(existing[0].min, int(extra.get("min", 1)))
            else:
                s.skill_mix.append(SkillMix(skill=extra["skill"], min=int(extra.get("min", 1))))
        changes["extra_skill"] = extra
    if scenario.get("max_weekly_hours"):
        for e in req.employees:
            e.max_weekly_hours = float(scenario["max_weekly_hours"])
        changes["max_weekly_hours"] = scenario["max_weekly_hours"]
    return changes


async def build_request(schedule: dict, presets: list[str]) -> tuple[OptimizeRequest, dict]:
    ctx = await schedule_context(schedule)
    locked = [Pair(shift_id=str(a["shift_id"]), employee_id=str(a["employee_id"]))
              for a in ctx["assignments"] if a.get("locked")]
    previous = [Pair(shift_id=str(a["shift_id"]), employee_id=str(a["employee_id"]))
                for a in ctx["assignments"] if not a.get("locked")]
    req = OptimizeRequest(department_id=str(schedule["department_id"]), shifts=ctx["shifts"],
                          employees=ctx["employees"], locked=locked, previous=previous, rules=ctx["rules"],
                          presets=weights_for(ctx["rules_doc"], presets), include_baselines=True)
    return req, ctx


async def process_run(run_id: ObjectId) -> dict:
    db = get_db()
    run = await db[C.OPTIMIZATION_RUNS].find_one_and_update(
        {"_id": run_id, "status": {"$in": ["queued", "running"]}},
        {"$set": {"status": "running", "started_at": utcnow(), "progress": 10}, "$inc": {"attempts": 1}},
        return_document=True)
    if not run:
        return {"skipped": True}
    try:
        schedule = await db[C.SCHEDULES].find_one({"_id": run["schedule_id"]})
        req, ctx = await build_request(schedule, run.get("presets") or ["balanced"])
        await db[C.OPTIMIZATION_RUNS].update_one({"_id": run_id}, {"$set": {"progress": 25,
                                                                           "schedule_version": schedule.get("version")}})
        current_pairs = [(str(a["shift_id"]), str(a["employee_id"])) for a in ctx["assignments"]]
        current_metrics = compute_metrics(req.shifts, req.employees, current_pairs, req.rules) if current_pairs else None
        scenario_changes = None
        if run["kind"] == "simulate":
            scenario_changes = apply_scenario(req, run.get("scenario") or {}, ctx["assignments"])
            req.include_baselines = False
        await db[C.OPTIMIZATION_RUNS].update_one({"_id": run_id}, {"$set": {"progress": 40,
                                                                           "input_size": {"shifts": len(req.shifts),
                                                                                          "employees": len(req.employees)}}})
        result = await optimizer_client().post("/optimize", json=req.model_dump(mode="json"))
        result["current"] = current_metrics
        if scenario_changes is not None:
            result["scenario_changes"] = scenario_changes
        update = {"status": "completed", "progress": 100, "finished_at": utcnow(), "result": result}
        if scenario_changes is not None:
            update["scenario.requirement_changes"] = scenario_changes["requirement_changes"]
        await db[C.OPTIMIZATION_RUNS].update_one({"_id": run_id}, {"$set": update})
        await db[C.SCHEDULES].update_one({"_id": run["schedule_id"]}, {"$set": {"last_run_id": run_id}})
        await events.publish_notification([run["requested_by"]], "optimization.completed", "Optimization finished",
                                          "Your schedule optimization has completed. Review the results.",
                                          {"run_id": str(run_id), "schedule_id": str(run["schedule_id"])})
        return {"completed": True}
    except ServiceUnavailableError as exc:
        if run.get("attempts", 1) < MAX_JOB_ATTEMPTS:
            logger.warning("optimizer unavailable, job will be retried")
            await db[C.OPTIMIZATION_RUNS].update_one(
                {"_id": run_id}, {"$set": {"status": "queued", "progress": 5, "error": f"Retrying: {exc.message}"}})
            return {"retry": True}
        await db[C.OPTIMIZATION_RUNS].update_one(
            {"_id": run_id}, {"$set": {"status": "failed", "finished_at": utcnow(), "error": exc.message}})
        await events.publish_notification([run["requested_by"]], "optimization.failed", "Optimization failed",
                                          exc.message, {"run_id": str(run_id)})
        return {"failed": True, "error": exc.message}
    except Exception as exc:  # noqa: BLE001
        logger.exception("optimization run failed")
        await db[C.OPTIMIZATION_RUNS].update_one(
            {"_id": run_id}, {"$set": {"status": "failed", "finished_at": utcnow(), "error": str(getattr(exc, "message", exc))}})
        await events.publish_notification([run["requested_by"]], "optimization.failed", "Optimization failed",
                                          str(getattr(exc, "message", exc)), {"run_id": str(run_id)})
        return {"failed": True, "error": str(exc)}
