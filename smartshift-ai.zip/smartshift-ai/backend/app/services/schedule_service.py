"""Schedule periods, shift materialization, optimizer runs, applying and publishing."""
from __future__ import annotations

from datetime import date, timedelta

from bson import ObjectId

from app.core.errors import ConflictError, NotFoundError, ValidationFailed
from app.database.mongo import Collections as C
from app.database.mongo import get_db, run_transaction
from app.models.enums import AssignmentSource, AssignmentStatus, RunKind, RunStatus, ScheduleStatus
from app.optimization.constraints import verify
from app.services import events
from app.services.audit import audit
from app.services.scheduling_data import get_rules_doc, schedule_context
from app.utils.timeutils import date_range, shift_times, utcnow


def build_shift_docs(schedule_id: ObjectId, dept: dict, start: date, days: int, tz: str, weekend_days: list[int],
                     night_codes: list[str], overrides: dict[str, int] | None = None) -> list[dict]:
    docs = []
    now = utcnow()
    for d in date_range(start, days):
        for cfg in dept["shift_configurations"]:
            t = shift_times(d, cfg["start_time"], cfg["duration_hours"], tz)
            required = (overrides or {}).get(cfg["code"], cfg["required_staff"])
            docs.append({
                "schedule_id": schedule_id, "department_id": dept["_id"], "template_code": cfg["code"],
                "name": cfg["name"], "local_date": t["local_date"], "start": t["start"], "end": t["end"],
                "duration_hours": cfg["duration_hours"], "required_staff": int(required),
                "required_skills": sorted(set(cfg.get("required_skills", [])) | set(dept.get("required_skills", []))),
                "skill_mix": cfg.get("skill_mix", []), "is_night": cfg["code"] in night_codes,
                "is_weekend": d.weekday() in weekend_days, "assigned_count": 0, "color": cfg.get("color"),
                "created_at": now,
            })
    return docs


async def create_schedule(actor, department_id: ObjectId, start: date, days: int,
                          overrides: dict[str, int] | None = None) -> dict:
    db = get_db()
    dept = await db[C.DEPARTMENTS].find_one({"_id": department_id, "is_active": True})
    if not dept:
        raise NotFoundError("Department not found")
    if not dept.get("shift_configurations"):
        raise ValidationFailed("Department has no shift configurations")
    rules = await get_rules_doc()
    end = start + timedelta(days=days - 1)
    overlap = await db[C.SCHEDULES].find_one({
        "department_id": department_id, "status": {"$ne": "archived"},
        "start_date": {"$lte": end.isoformat()}, "end_date": {"$gte": start.isoformat()}})
    if overlap:
        raise ConflictError("A schedule already covers part of this period for the department",
                            {"schedule_id": str(overlap["_id"])})

    async def txn(session):
        now = utcnow()
        sched = {"department_id": department_id, "start_date": start.isoformat(), "end_date": end.isoformat(),
                 "days": days, "status": ScheduleStatus.DRAFT.value, "version": 1, "created_by": actor.id if actor else None,
                 "created_at": now, "updated_at": now, "requirement_overrides": overrides or {}}
        res = await db[C.SCHEDULES].insert_one(sched, session=session)
        sched["_id"] = res.inserted_id
        shifts = build_shift_docs(res.inserted_id, dept, start, days, rules["timezone"], rules["weekend_days"],
                                  rules["night_shift_codes"], overrides)
        await db[C.SHIFTS].insert_many(shifts, session=session)
        await audit(actor, "schedule.create", "schedule", res.inserted_id,
                    {"department": dept["name"], "start": start.isoformat(), "days": days}, session=session)
        return sched

    return await run_transaction(txn)


async def update_requirements(actor, schedule: dict, overrides: dict[str, int]) -> int:
    db = get_db()
    changed = 0
    for code, req in overrides.items():
        if req < 0:
            raise ValidationFailed("Staffing requirement cannot be negative")
        conflicts = await db[C.SHIFTS].count_documents({"schedule_id": schedule["_id"], "template_code": code,
                                                        "assigned_count": {"$gt": req}})
        if conflicts:
            raise ConflictError(f"{conflicts} '{code}' shift(s) already have more staff than {req}. Remove assignments first.")
        res = await db[C.SHIFTS].update_many({"schedule_id": schedule["_id"], "template_code": code},
                                             {"$set": {"required_staff": int(req)}})
        changed += res.modified_count
    await db[C.SCHEDULES].update_one({"_id": schedule["_id"]},
                                     {"$set": {f"requirement_overrides.{k}": v for k, v in overrides.items()}
                                      | {"updated_at": utcnow()}})
    await audit(actor, "schedule.requirements", "schedule", schedule["_id"], {"overrides": overrides})
    return changed


async def enqueue_run(actor, schedule: dict, kind: RunKind, presets: list[str], scenario: dict | None = None) -> dict:
    db = get_db()
    active = await db[C.OPTIMIZATION_RUNS].find_one({"schedule_id": schedule["_id"],
                                                     "status": {"$in": ["queued", "running"]}})
    if active:
        raise ConflictError("An optimization job is already running for this schedule", {"run_id": str(active["_id"])})
    run = {"kind": kind.value, "schedule_id": schedule["_id"], "department_id": schedule["department_id"],
           "presets": presets, "scenario": scenario, "status": RunStatus.QUEUED.value, "progress": 0,
           "requested_by": actor.id, "created_at": utcnow(), "attempts": 0, "applied": False}
    res = await db[C.OPTIMIZATION_RUNS].insert_one(run)
    run["_id"] = res.inserted_id
    try:
        await events.enqueue_job({"run_id": str(res.inserted_id)})
    except Exception as exc:  # noqa: BLE001
        await db[C.OPTIMIZATION_RUNS].update_one({"_id": res.inserted_id},
                                                 {"$set": {"status": "failed", "error": "Job queue unavailable"}})
        from app.core.errors import ServiceUnavailableError
        raise ServiceUnavailableError("The job queue (Redis) is unavailable; the optimization was not started.") from exc
    await audit(actor, f"optimization.{kind.value}", "schedule", schedule["_id"], {"run_id": str(res.inserted_id),
                                                                                    "presets": presets})
    return run


async def apply_run(actor, run_id: ObjectId, variant: str) -> dict:
    db = get_db()
    run = await db[C.OPTIMIZATION_RUNS].find_one({"_id": run_id})
    if not run:
        raise NotFoundError("Optimization run not found")
    if run["status"] != "completed":
        raise ConflictError("Only completed runs can be applied")
    actor.require_department(run["department_id"])
    result = (run.get("result") or {}).get("variants", {}).get(variant)
    if not result or result["status"] == "INFEASIBLE":
        raise ValidationFailed("This variant has no feasible schedule to apply")
    schedule = await db[C.SCHEDULES].find_one({"_id": run["schedule_id"]})
    if schedule["status"] == "archived":
        raise ConflictError("Archived schedules cannot be changed")
    if schedule.get("version") != run.get("schedule_version"):
        raise ConflictError("The schedule changed after this optimization ran. Please regenerate.",
                            {"run_version": run.get("schedule_version"), "current_version": schedule.get("version")})
    pairs = [(p["shift_id"], p["employee_id"]) for p in result["assignments"]]
    scenario_overrides = (run.get("scenario") or {}).get("requirement_changes") or {}

    async def txn(session):
        if scenario_overrides:
            for sid, req in scenario_overrides.items():
                await db[C.SHIFTS].update_one({"_id": ObjectId(sid)}, {"$set": {"required_staff": int(req)}},
                                              session=session)
        # Re-validate against live data: simulations may use hypothetical inputs.
        ctx = await schedule_context(schedule, session=session)
        locked = {(str(a["shift_id"]), str(a["employee_id"])) for a in ctx["assignments"] if a.get("locked")}
        known = {e.id for e in ctx["employees"] if e.active}
        unknown = sorted({e for _, e in pairs if e not in known})
        if unknown:
            raise ConflictError("The proposed schedule references employees who are no longer eligible",
                                {"employee_ids": unknown})
        violations = [v for v in verify(ctx["shifts"], ctx["employees"], pairs, ctx["rules"])
                      if v.type not in ("understaffed", "skill_mix")]
        if violations:
            raise ConflictError("The proposed schedule violates current constraints and cannot be applied",
                                {"violations": [v.to_dict() for v in violations[:20]]})
        now = utcnow()
        await db[C.ASSIGNMENTS].update_many(
            {"schedule_id": schedule["_id"], "status": "active", "locked": False},
            {"$set": {"status": AssignmentStatus.CANCELLED.value, "updated_at": now, "cancel_reason": "regenerated"}},
            session=session)
        shifts = {str(s["_id"]): s for s in ctx["shift_docs"]}
        docs = []
        for sid, eid in pairs:
            if (sid, eid) in locked:
                continue
            s = shifts[sid]
            docs.append({"schedule_id": schedule["_id"], "shift_id": s["_id"], "employee_id": ObjectId(eid),
                         "department_id": s["department_id"], "start": s["start"], "end": s["end"],
                         "duration_hours": s["duration_hours"], "status": "active", "locked": False,
                         "source": AssignmentSource.OPTIMIZER.value, "run_id": run_id, "preset": variant,
                         "created_by": actor.id, "created_at": now, "updated_at": now})
        if docs:
            await db[C.ASSIGNMENTS].insert_many(docs, session=session)
        counts: dict[str, int] = {}
        for sid, _ in pairs:
            counts[sid] = counts.get(sid, 0) + 1
        for sid, s in shifts.items():
            await db[C.SHIFTS].update_one({"_id": s["_id"]}, {"$set": {"assigned_count": counts.get(sid, 0)}},
                                          session=session)
        await db[C.EMPLOYEES].update_many({"_id": {"$in": list({ObjectId(e) for _, e in pairs})}},
                                          {"$inc": {"version": 1}}, session=session)
        await db[C.SCHEDULES].update_one({"_id": schedule["_id"]},
                                         {"$inc": {"version": 1},
                                          "$set": {"last_run_id": run_id, "applied_preset": variant, "updated_at": now}},
                                         session=session)
        await db[C.OPTIMIZATION_RUNS].update_one({"_id": run_id}, {"$set": {"applied": True, "applied_variant": variant,
                                                                            "applied_at": now}}, session=session)
        await audit(actor, "optimization.apply", "schedule", schedule["_id"],
                    {"run_id": str(run_id), "variant": variant, "assignments": len(docs)}, session=session)
        return len(docs)

    inserted = await run_transaction(txn)
    if schedule["status"] == "published":
        await _notify_schedule(schedule, "schedule.modified", "Schedule updated")
    return {"applied": True, "assignments_created": inserted, "variant": variant}


async def publish(actor, schedule_id: ObjectId) -> dict:
    db = get_db()
    schedule = await db[C.SCHEDULES].find_one_and_update(
        {"_id": schedule_id, "status": "draft"},
        {"$set": {"status": "published", "published_at": utcnow(), "published_by": actor.id, "updated_at": utcnow()},
         "$inc": {"version": 1}}, return_document=True)
    if not schedule:
        raise ConflictError("Only draft schedules can be published")
    await audit(actor, "schedule.publish", "schedule", schedule_id, {})
    await _notify_schedule(schedule, "schedule.published", "Schedule published")
    return schedule


async def unpublish(actor, schedule_id: ObjectId) -> dict:
    db = get_db()
    schedule = await db[C.SCHEDULES].find_one_and_update(
        {"_id": schedule_id, "status": "published"},
        {"$set": {"status": "draft", "updated_at": utcnow()}, "$inc": {"version": 1}}, return_document=True)
    if not schedule:
        raise ConflictError("Only published schedules can be moved back to draft")
    await audit(actor, "schedule.unpublish", "schedule", schedule_id, {})
    return schedule


async def _notify_schedule(schedule: dict, ntype: str, title: str) -> None:
    db = get_db()
    dept = await db[C.DEPARTMENTS].find_one({"_id": schedule["department_id"]}, {"name": 1})
    emp_ids = await db[C.ASSIGNMENTS].distinct("employee_id", {"schedule_id": schedule["_id"], "status": "active"})
    users = await events.user_ids_for_employees(emp_ids)
    await events.publish_notification(
        users, ntype, title,
        f"{dept['name']} schedule {schedule['start_date']} to {schedule['end_date']} is now available.",
        {"schedule_id": str(schedule["_id"])})


async def delete_schedule(actor, schedule_id: ObjectId) -> None:
    db = get_db()
    schedule = await db[C.SCHEDULES].find_one({"_id": schedule_id})
    if not schedule:
        raise NotFoundError("Schedule not found")
    actor.require_department(schedule["department_id"])
    if schedule["status"] == "published":
        raise ConflictError("Published schedules cannot be deleted; unpublish first")

    async def txn(session):
        await db[C.ASSIGNMENTS].delete_many({"schedule_id": schedule_id}, session=session)
        await db[C.SHIFTS].delete_many({"schedule_id": schedule_id}, session=session)
        await db[C.SCHEDULES].delete_one({"_id": schedule_id}, session=session)
        await audit(actor, "schedule.delete", "schedule", schedule_id, {}, session=session)

    await run_transaction(txn)
