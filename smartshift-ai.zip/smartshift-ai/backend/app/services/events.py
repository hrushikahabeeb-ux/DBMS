"""Event bus (Redis list) used to hand work to the notification service and the
scheduling worker. MongoDB stays the system of record; Redis carries only
transient messages. If Redis is down, notifications are written directly to
MongoDB so no user-facing message is lost (graceful degradation)."""
import json
import logging
from typing import Any

import redis.asyncio as aioredis
from bson import ObjectId

from app.core.config import get_settings
from app.core.logging import get_correlation_id, log_event
from app.database.mongo import Collections as C
from app.database.mongo import get_db
from app.utils.timeutils import utcnow

logger = logging.getLogger(__name__)

EVENTS_QUEUE = "smartshift:events"
JOBS_QUEUE = "smartshift:jobs"
JOBS_PROCESSING = "smartshift:jobs:processing"
WS_CHANNEL = "smartshift:ws"

_redis: aioredis.Redis | None = None


def get_redis() -> aioredis.Redis:
    global _redis
    if _redis is None:
        _redis = aioredis.from_url(get_settings().redis_url, decode_responses=True, socket_connect_timeout=2,
                                   socket_timeout=5)
    return _redis


async def close_redis() -> None:
    global _redis
    if _redis is not None:
        await _redis.aclose()
        _redis = None


async def redis_ok() -> bool:
    try:
        return bool(await get_redis().ping())
    except Exception:  # noqa: BLE001
        return False


async def publish_notification(user_ids: list[ObjectId | str | None], ntype: str, title: str, message: str,
                               data: dict[str, Any] | None = None, dedupe_key: str | None = None) -> None:
    recipients = [str(u) for u in user_ids if u]
    if not recipients:
        return
    event = {"kind": "notification", "type": ntype, "title": title, "message": message, "data": data or {},
             "user_ids": recipients, "dedupe_key": dedupe_key, "correlation_id": get_correlation_id(),
             "emitted_at": utcnow().isoformat()}
    try:
        await get_redis().lpush(EVENTS_QUEUE, json.dumps(event, default=str))
    except Exception as exc:  # noqa: BLE001
        log_event(logger, "redis unavailable, writing notifications directly", error=str(exc))
        now = utcnow()
        docs = [{"user_id": ObjectId(u), "type": ntype, "title": title, "message": message, "data": data or {},
                 "read": False, "created_at": now} for u in recipients]
        await get_db()[C.NOTIFICATIONS].insert_many(docs)


async def user_ids_for_employees(employee_ids: list[ObjectId]) -> list[ObjectId]:
    cursor = get_db()[C.EMPLOYEES].find({"_id": {"$in": employee_ids}, "user_id": {"$ne": None}}, {"user_id": 1})
    return [d["user_id"] async for d in cursor]


async def manager_user_ids(department_id: ObjectId) -> list[ObjectId]:
    cursor = get_db()[C.USERS].find(
        {"is_active": True, "$or": [{"role": "super_admin"}, {"role": "manager", "managed_department_ids": department_id}]},
        {"_id": 1})
    return [d["_id"] async for d in cursor]


async def enqueue_job(job: dict) -> None:
    job = {**job, "correlation_id": get_correlation_id()}
    await get_redis().lpush(JOBS_QUEUE, json.dumps(job, default=str))
