"""In-process registry of WebSocket connections keyed by user id."""
import asyncio
import json
import logging
from collections import defaultdict

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class ConnectionManager:
    def __init__(self) -> None:
        self._conns: dict[str, set[WebSocket]] = defaultdict(set)
        self._lock = asyncio.Lock()

    async def connect(self, user_id: str, ws: WebSocket) -> None:
        await ws.accept()
        async with self._lock:
            self._conns[user_id].add(ws)

    async def disconnect(self, user_id: str, ws: WebSocket) -> None:
        async with self._lock:
            self._conns[user_id].discard(ws)
            if not self._conns[user_id]:
                self._conns.pop(user_id, None)

    async def send(self, user_id: str, payload: dict) -> int:
        sent = 0
        for ws in list(self._conns.get(user_id, ())):
            try:
                await ws.send_text(json.dumps(payload, default=str))
                sent += 1
            except Exception:  # noqa: BLE001
                await self.disconnect(user_id, ws)
        return sent

    @property
    def connection_count(self) -> int:
        return sum(len(v) for v in self._conns.values())


manager = ConnectionManager()
