"""ObjectId parsing and pagination helpers."""
from typing import Any

from bson import ObjectId
from bson.errors import InvalidId

from app.core.errors import ValidationFailed


def oid(value: Any, field: str = "id") -> ObjectId:
    if isinstance(value, ObjectId):
        return value
    try:
        return ObjectId(str(value))
    except (InvalidId, TypeError) as exc:
        raise ValidationFailed(f"Invalid {field}", {"field": field, "value": str(value)}) from exc


def oid_or_none(value: Any, field: str = "id") -> ObjectId | None:
    if value in (None, "", "null"):
        return None
    return oid(value, field)


def page_meta(total: int, page: int, page_size: int) -> dict:
    return {"total": total, "page": page, "page_size": page_size, "pages": (total + page_size - 1) // page_size if page_size else 1}


def parse_sort(sort: str | None, allowed: set[str], default: str) -> list[tuple[str, int]]:
    value = sort or default
    direction = -1 if value.startswith("-") else 1
    field = value.lstrip("-")
    if field not in allowed:
        raise ValidationFailed(f"Cannot sort by '{field}'", {"allowed": sorted(allowed)})
    return [(field, direction), ("_id", 1)]
