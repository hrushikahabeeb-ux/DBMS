"""Timezone helpers. Persisted timestamps are UTC; scheduling logic reasons in the
organization's local timezone (dates, weekdays, availability windows)."""
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def parse_hhmm(value: str) -> int:
    h, m = value.split(":")
    return int(h) * 60 + int(m)


def fmt_hhmm(minutes: int) -> str:
    minutes %= 1440
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def week_key(d: date) -> str:
    iso = d.isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


def local_to_utc(d: date, minutes: int, tz: str) -> datetime:
    zone = ZoneInfo(tz)
    local = datetime.combine(d, time(0, 0), tzinfo=zone) + timedelta(minutes=minutes)
    return local.astimezone(timezone.utc)


def to_local(dt: datetime, tz: str) -> datetime:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(ZoneInfo(tz))


def local_today(tz: str) -> date:
    return datetime.now(ZoneInfo(tz)).date()


def date_range(start: date, days: int) -> list[date]:
    return [start + timedelta(days=i) for i in range(days)]


def shift_times(d: date, start_hhmm: str, duration_hours: float, tz: str) -> dict:
    start_min = parse_hhmm(start_hhmm)
    end_min = start_min + int(round(duration_hours * 60))
    return {
        "local_date": d.isoformat(),
        "weekday": d.weekday(),
        "week_key": week_key(d),
        "start": local_to_utc(d, start_min, tz),
        "end": local_to_utc(d, end_min, tz),
        "local_start_min": start_min,
        "local_end_min": end_min,
    }
