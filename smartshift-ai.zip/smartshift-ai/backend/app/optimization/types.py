"""Data contract of the scheduling optimization service.

These models are deliberately independent of MongoDB so the optimizer can run as
a stateless service: the main API (or worker) assembles the inputs and posts them.
"""
from datetime import datetime

from pydantic import BaseModel, Field


class Window(BaseModel):
    weekday: int = Field(ge=0, le=6)
    start_min: int = Field(ge=0, le=1440)
    end_min: int = Field(ge=0, le=2880)


class SkillMix(BaseModel):
    skill: str
    min: int = Field(ge=1)


class ShiftIn(BaseModel):
    id: str
    department_id: str
    template_code: str
    name: str = ""
    local_date: str
    weekday: int = Field(ge=0, le=6)
    week_key: str
    start: datetime
    end: datetime
    local_start_min: int
    local_end_min: int
    duration_hours: float = Field(gt=0)
    required_staff: int = Field(ge=0)
    required_skills: list[str] = []
    skill_mix: list[SkillMix] = []
    is_night: bool = False
    is_weekend: bool = False


class FixedInterval(BaseModel):
    """An assignment outside the schedule being optimized (other departments/periods)."""
    shift_id: str | None = None
    department_id: str | None = None
    start: datetime
    end: datetime
    duration_hours: float
    local_date: str
    week_key: str
    label: str = ""


class EmployeeIn(BaseModel):
    id: str
    code: str
    name: str
    department_ids: list[str]
    skills: list[str] = []
    active: bool = True
    max_weekly_hours: float = 40
    hourly_wage: float = 0
    preferred_shifts: list[str] = []
    preferred_days_off: list[int] = []
    windows: list[Window] = []
    unavailable_dates: list[str] = []
    leave_dates: list[str] = []
    fixed: list[FixedInterval] = []


class Pair(BaseModel):
    shift_id: str
    employee_id: str


class Rules(BaseModel):
    min_rest_hours: float = 11
    max_consecutive_days: int = 6
    overtime_threshold_hours: float = 40
    overtime_multiplier: float = 1.5
    allow_understaffing: bool = True
    time_limit_seconds: float = 10
    workers: int = 8


class Weights(BaseModel):
    unfilled: int = 10000
    cost: int = 1
    preference: int = 3
    fairness: int = 4
    night_balance: int = 3
    weekend_balance: int = 3
    overtime: int = 3
    stability: int = 1


class OptimizeRequest(BaseModel):
    department_id: str
    shifts: list[ShiftIn]
    employees: list[EmployeeIn]
    locked: list[Pair] = []
    previous: list[Pair] = []
    rules: Rules = Rules()
    presets: dict[str, Weights] = {"balanced": Weights()}
    include_baselines: bool = True
    seed: int = 7


class ValidateRequest(BaseModel):
    shifts: list[ShiftIn]
    employees: list[EmployeeIn]
    assignments: list[Pair]
    rules: Rules = Rules()
