"""CP-SAT shift scheduling model.

Decision variables
    x[e,s] in {0,1}   employee e works shift s (created only for statically eligible pairs)
    u[s]   in [0,R_s] unfilled slots of shift s (fixed to 0 when understaffing is disallowed)
    m[s,k] >= 0       missing skill-mix members of skill k on shift s

Hard constraints
    sum_e x[e,s] + u[s] = R_s                                   coverage (never overstaffed)
    sum_{e has k} x[e,s] + m[s,k] >= min_k                     skill mix
    x[e,a] + x[e,b] <= 1   if a,b overlap or gap < rest         overlap + minimum rest
    sum_{s in week w} d_s x[e,s] <= H_e - fixed_e,w             weekly hour limit
    sum_{d in window} y[e,d] <= K                               max consecutive days (y = worked day)
    x[e,s] = 1 for locked pairs                                 preserved assignments

Objective (minimize)   W_u * (sum u + sum m)
                     + W_c * sum c_es x[e,s]                    labor cost, normalized
                     + W_p * sum 100 * (1 - pref_es) x[e,s]     preference violations
                     + W_o * sum ot[e,w]                        overtime half-hours
                     + W_f * sum |L_e - T_e|                    load deviation from fair share (pct)
                     + W_n * sum |10 n_e - 10 T^n|              night balance
                     + W_w * sum |10 w_e - 10 T^w|              weekend balance
                     + W_s * sum 100 * (1 - x[e,s]) for previous (e,s)   stability
"""
from __future__ import annotations

import statistics
import time
from collections import defaultdict
from datetime import date, timedelta

from ortools.sat.python import cp_model

from app.optimization.constraints import Interval, conflicts, preference_matched, static_checks, statically_eligible
from app.optimization.metrics import compute_metrics
from app.optimization.types import EmployeeIn, OptimizeRequest, Rules, ShiftIn, Weights

STATUS = {
    cp_model.OPTIMAL: "OPTIMAL",
    cp_model.FEASIBLE: "FEASIBLE",
    cp_model.INFEASIBLE: "INFEASIBLE",
    cp_model.MODEL_INVALID: "MODEL_INVALID",
    cp_model.UNKNOWN: "UNKNOWN",
}


def half_hours(h: float) -> int:
    return int(round(h * 2))


def eligibility(req: OptimizeRequest) -> dict[tuple[str, str], bool]:
    """Static eligibility plus conflicts with fixed (external) assignments."""
    rules = req.rules
    out: dict[tuple[str, str], bool] = {}
    for e in req.employees:
        fixed = [Interval.from_fixed(f) for f in e.fixed]
        fixed_week = defaultdict(float)
        for f in e.fixed:
            fixed_week[f.week_key] += f.duration_hours
        for s in req.shifts:
            ok = statically_eligible(e, s)
            if ok:
                iv = Interval.from_shift(s)
                ok = not any(conflicts(iv, f, rules.min_rest_hours)[0] for f in fixed)
                ok = ok and fixed_week[s.week_key] + s.duration_hours <= e.max_weekly_hours + 1e-6
            out[(e.id, s.id)] = ok
    return out


def diagnose(req: OptimizeRequest, elig: dict[tuple[str, str], bool]) -> dict:
    """Pre-solve capacity analysis explaining likely shortages."""
    issues = []
    emp_by_id = {e.id: e for e in req.employees}
    for s in req.shifts:
        eligible = [e for e in req.employees if elig[(e.id, s.id)]]
        if len(eligible) < s.required_staff:
            reasons = defaultdict(int)
            for e in req.employees:
                if s.department_id not in e.department_ids:
                    continue
                for c in static_checks(e, s):
                    if not c.passed:
                        reasons[c.code] += 1
                        break
                else:
                    reasons["existing_assignment_or_hours"] += 1
            issues.append({
                "type": "insufficient_eligible_staff",
                "shift_id": s.id, "local_date": s.local_date, "template_code": s.template_code,
                "required": s.required_staff, "eligible": len(eligible),
                "blocking_reasons": dict(reasons),
                "message": f"{s.name or s.template_code} on {s.local_date} needs {s.required_staff} staff but only "
                           f"{len(eligible)} are eligible.",
            })
        for mix in s.skill_mix:
            qualified = [e for e in eligible if mix.skill in e.skills]
            if len(qualified) < mix.min:
                issues.append({
                    "type": "insufficient_skill_mix", "shift_id": s.id, "local_date": s.local_date,
                    "template_code": s.template_code, "skill": mix.skill, "required": mix.min,
                    "eligible": len(qualified),
                    "message": f"{s.name or s.template_code} on {s.local_date} needs {mix.min} staff with {mix.skill}; "
                               f"{len(qualified)} eligible.",
                })
    for p in req.locked:
        if p.employee_id in emp_by_id and not elig.get((p.employee_id, p.shift_id), False):
            issues.append({"type": "invalid_locked_assignment", "shift_id": p.shift_id, "employee_id": p.employee_id,
                           "message": f"Locked assignment for {emp_by_id[p.employee_id].name} violates a hard constraint."})

    total_hours = sum(s.required_staff * s.duration_hours for s in req.shifts)
    capacity = 0.0
    weeks = {s.week_key for s in req.shifts}
    for e in req.employees:
        eligible_hours = sum(s.duration_hours for s in req.shifts if elig[(e.id, s.id)])
        limit = e.max_weekly_hours * len(weeks) - sum(f.duration_hours for f in e.fixed if f.week_key in weeks)
        capacity += max(0.0, min(eligible_hours, limit))
    suggestions = []
    if issues:
        suggestions = [
            "Add cross-trained employees to this department's eligible staff.",
            "Reduce minimum staffing for the affected shifts or allow understaffing.",
            "Review approved leave and unavailability on the affected dates.",
            "Raise weekly hour limits for employees who agree to extra hours.",
        ]
    if capacity < total_hours:
        suggestions.insert(0, f"Workforce capacity ({capacity:g}h) is below required hours ({total_hours:g}h).")
    return {"issues": issues, "required_hours": total_hours, "available_capacity_hours": round(capacity, 1),
            "suggestions": suggestions}


def solve(req: OptimizeRequest, weights: Weights, elig: dict[tuple[str, str], bool] | None = None) -> dict:
    t0 = time.perf_counter()
    rules: Rules = req.rules
    elig = elig or eligibility(req)
    shifts, emps = req.shifts, req.employees
    shift_by_id = {s.id: s for s in shifts}
    model = cp_model.CpModel()

    x: dict[tuple[str, str], cp_model.IntVar] = {}
    for e in emps:
        for s in shifts:
            if elig[(e.id, s.id)]:
                x[(e.id, s.id)] = model.NewBoolVar(f"x_{e.code}_{s.id[-6:]}")

    warnings: list[str] = []
    locked = {(p.employee_id, p.shift_id) for p in req.locked}
    for key in locked:
        if key in x:
            model.Add(x[key] == 1)
        else:
            return _infeasible(req, t0, elig, "A locked assignment violates a hard constraint and cannot be preserved.")

    penalty_terms = []
    unfilled_vars = []
    for s in shifts:
        vars_s = [x[(e.id, s.id)] for e in emps if (e.id, s.id) in x]
        if rules.allow_understaffing:
            u = model.NewIntVar(0, s.required_staff, f"u_{s.id[-6:]}")
            unfilled_vars.append(u)
            model.Add(sum(vars_s) + u == s.required_staff)
        else:
            model.Add(sum(vars_s) == s.required_staff)
        for mix in s.skill_mix:
            qualified = [x[(e.id, s.id)] for e in emps if (e.id, s.id) in x and mix.skill in e.skills]
            if rules.allow_understaffing:
                m = model.NewIntVar(0, mix.min, f"m_{s.id[-6:]}_{mix.skill[:4]}")
                unfilled_vars.append(m)
                model.Add(sum(qualified) + m >= mix.min)
            else:
                model.Add(sum(qualified) >= mix.min)
    penalty_terms.append(weights.unfilled * sum(unfilled_vars) if unfilled_vars else 0)

    ordered = sorted(shifts, key=lambda s: s.start)
    conflict_pairs = []
    for i, a in enumerate(ordered):
        ia = Interval.from_shift(a)
        for b in ordered[i + 1:]:
            if (b.start - a.end).total_seconds() / 3600 >= rules.min_rest_hours:
                break
            if conflicts(ia, Interval.from_shift(b), rules.min_rest_hours)[0]:
                conflict_pairs.append((a.id, b.id))
    for e in emps:
        for a, b in conflict_pairs:
            if (e.id, a) in x and (e.id, b) in x:
                model.AddBoolOr([x[(e.id, a)].Not(), x[(e.id, b)].Not()])

    weeks = sorted({s.week_key for s in shifts})
    median_wage = statistics.median([e.hourly_wage for e in emps if e.hourly_wage > 0] or [1])
    ot_vars = []
    for e in emps:
        mine = [s for s in shifts if (e.id, s.id) in x]
        if not mine:
            continue
        for wk in weeks:
            in_week = [s for s in mine if s.week_key == wk]
            if not in_week:
                continue
            fixed_h = sum(f.duration_hours for f in e.fixed if f.week_key == wk)
            expr = sum(half_hours(s.duration_hours) * x[(e.id, s.id)] for s in in_week)
            model.Add(expr <= half_hours(e.max_weekly_hours - fixed_h))
            threshold = half_hours(rules.overtime_threshold_hours - fixed_h)
            ub = half_hours(sum(s.duration_hours for s in in_week))
            ot = model.NewIntVar(0, max(0, ub), f"ot_{e.code}_{wk}")
            model.Add(ot >= expr - threshold)
            ot_vars.append((ot, e))
        # Consecutive working days, including days already worked in fixed assignments.
        k = rules.max_consecutive_days
        dates = sorted({s.local_date for s in shifts})
        if dates:
            worked = {}
            for d in dates:
                ds = [x[(e.id, s.id)] for s in mine if s.local_date == d]
                if ds:
                    y = model.NewBoolVar(f"y_{e.code}_{d}")
                    for v in ds:
                        model.Add(y >= v)
                    model.Add(y <= sum(ds))
                    worked[d] = y
            fixed_days = {f.local_date for f in e.fixed}
            first = date.fromisoformat(dates[0]) - timedelta(days=k)
            last = date.fromisoformat(dates[-1])
            cur = first
            while cur <= last:
                window = [(cur + timedelta(days=i)).isoformat() for i in range(k + 1)]
                terms = [worked[d] for d in window if d in worked]
                const = sum(1 for d in window if d in fixed_days and d not in worked)
                if terms and len(terms) + const > k:
                    model.Add(sum(terms) + const <= k)
                cur += timedelta(days=1)

    ot_coef = max(1, round(weights.overtime * 100 / 16))
    penalty_terms.append(sum(ot_coef * ot for ot, _ in ot_vars) if ot_vars else 0)

    cost_terms, pref_terms = [], []
    emp_by_id = {e.id: e for e in emps}
    for (eid, sid), var in x.items():
        e = emp_by_id[eid]
        s = shift_by_id[sid]
        norm = round(100 * e.hourly_wage * s.duration_hours / (median_wage * 8)) if median_wage else 0
        cost_terms.append(norm * var)
        if not preference_matched(e, s):
            pref_terms.append(100 * var)
    penalty_terms.append(weights.cost * sum(cost_terms) if cost_terms else 0)
    penalty_terms.append(weights.preference * sum(pref_terms) if pref_terms else 0)

    # Fairness: deviation of each employee's weekly load (existing + new hours, % of contract)
    # from a proportional fair-share target.
    pool = [e for e in emps if any((e.id, s.id) in x for s in shifts)]
    total_req_h = sum(s.required_staff * s.duration_hours for s in shifts)
    fixed_h = {e.id: sum(f.duration_hours for f in e.fixed if f.week_key in weeks) for e in pool}
    limit_h = {e.id: max(1.0, e.max_weekly_hours * len(weeks)) for e in pool}
    elig_h = {e.id: sum(s.duration_hours for s in shifts if (e.id, s.id) in x) for e in pool}
    total_limit = sum(limit_h.values()) or 1.0
    share = min(1.0, (total_req_h + sum(fixed_h.values())) / total_limit)
    dev_terms = []
    for e in pool:
        lim = limit_h[e.id]
        target_h = min(share * lim, fixed_h[e.id] + elig_h[e.id], lim)
        target_pct = round(100 * target_h / lim)
        fixed_pct = round(100 * fixed_h[e.id] / lim)
        load = sum(round(100 * s.duration_hours / lim) * x[(e.id, s.id)] for s in shifts if (e.id, s.id) in x)
        d = model.NewIntVar(0, 300, f"dev_{e.code}")
        model.Add(d >= fixed_pct + load - target_pct)
        model.Add(d >= target_pct - fixed_pct - load)
        dev_terms.append(d)
    penalty_terms.append(weights.fairness * sum(dev_terms) if dev_terms else 0)

    for flag, w, label in (("is_night", weights.night_balance, "n"), ("is_weekend", weights.weekend_balance, "w")):
        flagged = [s for s in shifts if getattr(s, flag)]
        if not flagged or w == 0:
            continue
        group = [e for e in pool if any((e.id, s.id) in x for s in flagged)]
        if flag == "is_night":
            # Nights are only a burden for people who did not ask for them.
            group = [e for e in group if "night" not in e.preferred_shifts]
        if not group:
            continue
        slots = sum(s.required_staff for s in flagged)
        target10 = round(40 * slots / len(group))
        terms = []
        for e in group:
            cnt = sum(x[(e.id, s.id)] for s in flagged if (e.id, s.id) in x)
            d = model.NewIntVar(0, 40 * len(flagged) + target10, f"d{label}_{e.code}")
            model.Add(d >= 40 * cnt - target10)
            model.Add(d >= target10 - 40 * cnt)
            terms.append(d)
        penalty_terms.append(w * sum(terms))

    stab = []
    for p in req.previous:
        key = (p.employee_id, p.shift_id)
        if key in x and key not in locked:
            stab.append(100 * (1 - x[key]))
    penalty_terms.append(weights.stability * sum(stab) if stab else 0)

    model.Minimize(sum(penalty_terms))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = rules.time_limit_seconds
    solver.parameters.num_search_workers = rules.workers
    solver.parameters.random_seed = req.seed
    build_s = time.perf_counter() - t0
    status = solver.Solve(model)
    elapsed = time.perf_counter() - t0
    status_name = STATUS.get(status, "UNKNOWN")

    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        res = _infeasible(req, t0, elig, "The hard constraints cannot all be satisfied with the current workforce.")
        res["solver_status"] = status_name
        return res

    pairs = [(sid, eid) for (eid, sid), v in x.items() if solver.Value(v) == 1]
    metrics = compute_metrics(shifts, emps, pairs, rules)
    if metrics["unfilled_count"]:
        warnings.append(f"{metrics['unfilled_count']} staffing slot(s) could not be filled without breaking a hard "
                        f"constraint. See unfilled shifts and diagnosis.")
    if metrics["overtime_hours"]:
        warnings.append(f"{metrics['overtime_hours']:g} overtime hour(s) across {metrics['overtime_employees']} employee(s).")
    return {
        "status": "PARTIAL" if metrics["unfilled_count"] else "SUCCESS",
        "solver_status": status_name,
        "objective": solver.ObjectiveValue(),
        "best_bound": solver.BestObjectiveBound(),
        "solve_seconds": round(elapsed, 3),
        "model_build_seconds": round(build_s, 3),
        "variables": len(x),
        "conflict_pairs": len(conflict_pairs),
        "assignments": [{"shift_id": s, "employee_id": e} for s, e in pairs],
        "metrics": metrics,
        "warnings": warnings,
        "diagnosis": diagnose(req, elig) if metrics["unfilled_count"] else None,
    }


def _infeasible(req: OptimizeRequest, t0: float, elig, reason: str) -> dict:
    return {
        "status": "INFEASIBLE",
        "solver_status": "INFEASIBLE",
        "objective": None,
        "solve_seconds": round(time.perf_counter() - t0, 3),
        "assignments": [],
        "metrics": None,
        "warnings": [reason],
        "diagnosis": diagnose(req, elig),
    }


def optimize(req: OptimizeRequest) -> dict:
    from app.optimization.baseline import greedy, round_robin

    elig = eligibility(req)
    variants = {name: solve(req, w, elig) for name, w in req.presets.items()}
    result = {"variants": variants, "baselines": {}, "diagnosis": diagnose(req, elig)}
    if req.include_baselines:
        for name, fn in (("greedy", greedy), ("round_robin", round_robin)):
            pairs, secs = fn(req.shifts, req.employees, req.rules)
            result["baselines"][name] = {
                "status": "HEURISTIC",
                "solve_seconds": round(secs, 4),
                "assignments": [{"shift_id": s, "employee_id": e} for s, e in pairs],
                "metrics": compute_metrics(req.shifts, req.employees, pairs, req.rules),
            }
    return result
