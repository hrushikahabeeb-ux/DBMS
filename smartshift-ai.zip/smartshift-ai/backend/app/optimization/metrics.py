"""Transparent, normalized schedule quality metrics.

Fairness score (0-100) = 100 * (0.4*H + 0.2*N + 0.2*W + 0.2*P) where
  H = 1 - Gini(load ratio = total weekly hours incl. other departments / contract hours) over the pool
  N = 1 - Gini(night shift counts) over night-eligible employees who did not request nights
      (nights are the unpopular shift; people who prefer nights are excluded)
  W = 1 - Gini(weekend shift counts) over weekend-eligible employees
  P = share of assignments that match the employee's stated preferences
The pool is every active employee statically eligible for at least one shift.
"""
from __future__ import annotations

import statistics

from app.optimization.constraints import Interval, preference_matched, statically_eligible, verify
from app.optimization.types import EmployeeIn, Rules, ShiftIn

FAIRNESS_WEIGHTS = {"hours_equity": 0.4, "night_equity": 0.2, "weekend_equity": 0.2, "preference_satisfaction": 0.2}
COVERAGE_TYPES = {"understaffed", "overstaffed", "skill_mix"}


def gini(values: list[float]) -> float:
    vals = [max(0.0, v) for v in values]
    n = len(vals)
    if n == 0:
        return 0.0
    mean = sum(vals) / n
    if mean == 0:
        return 0.0
    total = sum(abs(a - b) for a in vals for b in vals)
    return total / (2 * n * n * mean)


def compute_metrics(shifts: list[ShiftIn], employees: list[EmployeeIn], pairs: list[tuple[str, str]], rules: Rules) -> dict:
    shift_by_id = {s.id: s for s in shifts}
    emp_by_id = {e.id: e for e in employees}
    pairs = [(s, e) for s, e in pairs if s in shift_by_id and e in emp_by_id]

    required = sum(s.required_staff for s in shifts)
    per_shift: dict[str, int] = {}
    for sid, _ in set(pairs):
        per_shift[sid] = per_shift.get(sid, 0) + 1
    filled = sum(min(per_shift.get(s.id, 0), s.required_staff) for s in shifts)
    unfilled = [
        {"shift_id": s.id, "local_date": s.local_date, "template_code": s.template_code, "name": s.name,
         "required": s.required_staff, "assigned": per_shift.get(s.id, 0),
         "missing": s.required_staff - per_shift.get(s.id, 0)}
        for s in shifts if per_shift.get(s.id, 0) < s.required_staff
    ]

    pool = [e for e in employees if e.active and any(statically_eligible(e, s) for s in shifts)]
    night_pool = [e for e in pool if any(s.is_night and statically_eligible(e, s) for s in shifts)
                  and "night" not in e.preferred_shifts]
    weekend_pool = [e for e in pool if any(s.is_weekend and statically_eligible(e, s) for s in shifts)]

    hours: dict[str, float] = {e.id: 0.0 for e in employees}
    nights: dict[str, int] = {e.id: 0 for e in employees}
    weekends: dict[str, int] = {e.id: 0 for e in employees}
    week_hours: dict[tuple[str, str], float] = {}
    for e in employees:
        for f in e.fixed:
            week_hours[(e.id, f.week_key)] = week_hours.get((e.id, f.week_key), 0) + f.duration_hours
    matched = 0
    base_cost = 0.0
    for sid, eid in pairs:
        s, e = shift_by_id[sid], emp_by_id[eid]
        hours[eid] += s.duration_hours
        nights[eid] += int(s.is_night)
        weekends[eid] += int(s.is_weekend)
        week_hours[(eid, s.week_key)] = week_hours.get((eid, s.week_key), 0) + s.duration_hours
        base_cost += s.duration_hours * e.hourly_wage
        matched += int(preference_matched(e, s))

    sched_weeks = {s.week_key for s in shifts}
    overtime_hours = 0.0
    overtime_cost = 0.0
    overtime_employees = set()
    for (eid, wk), hrs in week_hours.items():
        if wk not in sched_weeks:
            continue
        ot = max(0.0, hrs - rules.overtime_threshold_hours)
        # Only overtime caused by hours inside this schedule is attributable to it.
        own = sum(shift_by_id[sid].duration_hours for sid, e2 in pairs if e2 == eid and shift_by_id[sid].week_key == wk)
        ot = min(ot, own)
        if ot > 0:
            overtime_employees.add(eid)
            overtime_hours += ot
            overtime_cost += ot * emp_by_id[eid].hourly_wage * (rules.overtime_multiplier - 1)

    n_weeks = len(sched_weeks) or 1
    fixed_in_weeks = {e.id: sum(f.duration_hours for f in e.fixed if f.week_key in sched_weeks) for e in employees}
    load = {e.id: (hours[e.id] + fixed_in_weeks[e.id]) / (e.max_weekly_hours * n_weeks) if e.max_weekly_hours else 0
            for e in pool}
    h_eq = 1 - gini([load[e.id] for e in pool])
    n_eq = 1 - gini([nights[e.id] for e in night_pool]) if night_pool else 1.0
    w_eq = 1 - gini([weekends[e.id] for e in weekend_pool]) if weekend_pool else 1.0
    pref = matched / len(pairs) if pairs else 1.0
    components = {"hours_equity": h_eq, "night_equity": n_eq, "weekend_equity": w_eq, "preference_satisfaction": pref}
    fairness = 100 * sum(FAIRNESS_WEIGHTS[k] * v for k, v in components.items())

    loads = [load[e.id] for e in pool]
    outliers = []
    if len(loads) >= 3:
        mean = statistics.fmean(loads)
        sd = statistics.pstdev(loads)
        for e in pool:
            if sd > 0 and abs(load[e.id] - mean) > 1.5 * sd:
                outliers.append({"employee_id": e.id, "name": e.name, "hours": hours[e.id],
                                 "load_ratio": round(load[e.id], 3),
                                 "direction": "high" if load[e.id] > mean else "low"})

    violations = verify(shifts, employees, pairs, rules)
    hard = [v for v in violations if v.type not in COVERAGE_TYPES]

    return {
        "required_slots": required,
        "filled_slots": filled,
        "coverage_pct": round(100 * filled / required, 2) if required else 100.0,
        "unfilled_count": sum(u["missing"] for u in unfilled),
        "unfilled_shifts": unfilled,
        "assignments": len(pairs),
        "fairness_score": round(fairness, 2),
        "fairness_components": {k: round(v, 4) for k, v in components.items()},
        "fairness_weights": FAIRNESS_WEIGHTS,
        "preference_satisfaction_pct": round(pref * 100, 2),
        "labor_cost": round(base_cost + overtime_cost, 2),
        "base_labor_cost": round(base_cost, 2),
        "overtime_cost": round(overtime_cost, 2),
        "overtime_hours": round(overtime_hours, 2),
        "overtime_employees": len(overtime_employees),
        "constraint_violations": len(hard),
        "violations": [v.to_dict() for v in hard[:50]],
        "pool_size": len(pool),
        "employee_hours": [
            {"employee_id": e.id, "name": e.name, "hours": hours[e.id], "other_hours": fixed_in_weeks[e.id],
             "load_pct": round(100 * load[e.id], 1), "nights": nights[e.id],
             "weekends": weekends[e.id], "max_weekly_hours": e.max_weekly_hours}
            for e in pool
        ],
        "outliers": outliers,
        "night_distribution": {e.name: nights[e.id] for e in pool if nights[e.id] or e in night_pool},
        "weekend_distribution": {e.name: weekends[e.id] for e in weekend_pool},
    }


def _period_days(shifts: list[ShiftIn]) -> int:
    return len({s.local_date for s in shifts}) or 1


def intervals_for(emp: EmployeeIn) -> list[Interval]:
    return [Interval.from_fixed(f) for f in emp.fixed]
