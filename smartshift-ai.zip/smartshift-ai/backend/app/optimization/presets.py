"""Optimization presets. Each weight multiplies a normalized penalty term
(see docs/OPTIMIZATION.md for the full formulation)."""

DEFAULT_WEIGHTS: dict[str, dict[str, int]] = {
    "balanced": {"unfilled": 10000, "cost": 1, "preference": 4, "fairness": 5, "night_balance": 3,
                 "weekend_balance": 3, "overtime": 4, "stability": 1},
    "cost": {"unfilled": 10000, "cost": 10, "preference": 1, "fairness": 1, "night_balance": 1,
             "weekend_balance": 1, "overtime": 10, "stability": 1},
    "wellbeing": {"unfilled": 10000, "cost": 1, "preference": 5, "fairness": 12, "night_balance": 18,
                  "weekend_balance": 12, "overtime": 6, "stability": 1},
}

PRESET_LABELS = {
    "balanced": "Balanced Mode",
    "cost": "Cost Efficiency Mode",
    "wellbeing": "Employee Well-being Mode",
}
