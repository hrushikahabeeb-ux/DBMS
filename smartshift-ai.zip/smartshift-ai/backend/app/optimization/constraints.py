"""Hard-constraint rules shared by the optimizer, the verifier, manual validation,
emergency replacement and shift swaps. Keeping one implementation guarantees that
every component agrees on what "valid" means.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta

from app.optimization.types import EmployeeIn, FixedInterval, Rules, ShiftIn


@dataclass
class Check:
    code: str
    passed: bool
    message: str
    severity: str = "high"  # high = hard constraint, info = soft/preference

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Interval:
    start: datetime
    end: datetime
    duration_hours: float
    local_date: str
    week_key: str
    shift_id: str | None = None
    department_id: str | None = None
    label: str = ""

    @classmethod
    def from_shift(cls, s: ShiftIn) -> "Interval":
        return cls(s.start, s.end, s.duration_hours, s.local_date, s.week_key, s.id, s.department_id,
                   f"the {s.name or s.template_code} shift on {s.local_date}")

    @classmethod
    def from_fixed(cls, f: FixedInterval) -> "Interval":
        return cls(f.start, f.end, f.duration_hours, f.local_date, f.week_key, f.shift_id, f.department_id,
                   f.label or f"shift on {f.local_date}")


@dataclass
class Violation:
    type: str
    severity: str
    message: str
    suggestion: str
    employee_id: str | None = None
    shift_id: str | None = None
    related_shift_id: str | None = None
    data: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


def window_covers(employee: EmployeeIn, shift: ShiftIn) -> bool:
    if not employee.windows:
        return False
    for w in employee.windows:
        if w.weekday != shift.weekday:
            continue
        start, end = w.start_min, w.end_min
        if end <= start:
            end += 1440
        if start <= shift.local_start_min and shift.local_end_min <= end:
            return True
    return False


def static_checks(employee: EmployeeIn, shift: ShiftIn) -> list[Check]:
    """Checks that depend only on the employee and the shift."""
    checks: list[Check] = [
        Check("active", employee.active, "Employee is active" if employee.active else "Employee is deactivated"),
        Check(
            "department",
            shift.department_id in employee.department_ids,
            "Eligible for this department" if shift.department_id in employee.department_ids
            else "Not eligible to work in this department",
        ),
    ]
    missing = [s for s in shift.required_skills if s not in employee.skills]
    checks.append(Check(
        "skills", not missing,
        f"Holds required qualifications: {', '.join(shift.required_skills)}" if not missing and shift.required_skills
        else ("No specific qualification required" if not missing else f"Missing qualifications: {', '.join(missing)}"),
    ))
    on_leave = shift.local_date in employee.leave_dates
    checks.append(Check("leave", not on_leave, "No approved leave on this date" if not on_leave else "On approved leave"))
    blocked = shift.local_date in employee.unavailable_dates
    covered = window_covers(employee, shift)
    available = covered and not blocked
    if blocked:
        msg = f"Marked unavailable on {shift.local_date}"
    elif not covered:
        msg = "Shift falls outside submitted availability"
    else:
        msg = "Available during the full shift"
    checks.append(Check("availability", available, msg))
    return checks


def statically_eligible(employee: EmployeeIn, shift: ShiftIn) -> bool:
    return all(c.passed for c in static_checks(employee, shift))


def conflicts(a: Interval, b: Interval, min_rest_hours: float) -> tuple[bool, str]:
    """Return whether two intervals conflict through overlap or insufficient rest."""
    if a.start < b.end and b.start < a.end:
        return True, "overlap"
    first, second = (a, b) if a.start <= b.start else (b, a)
    gap_h = (second.start - first.end).total_seconds() / 3600
    if gap_h < min_rest_hours:
        return True, f"rest:{gap_h:.1f}"
    return False, ""


def _dates_window(d: str, k: int) -> list[str]:
    base = date.fromisoformat(d)
    return [(base + timedelta(days=i)).isoformat() for i in range(-k, k + 1)]


def max_consecutive(dates: set[str]) -> int:
    if not dates:
        return 0
    ordered = sorted(date.fromisoformat(d) for d in dates)
    best = run = 1
    for prev, cur in zip(ordered, ordered[1:]):
        run = run + 1 if (cur - prev).days == 1 else 1
        best = max(best, run)
    return best


def dynamic_checks(employee: EmployeeIn, shift: ShiftIn, others: list[Interval], rules: Rules) -> list[Check]:
    """Checks that depend on the employee's other assignments (excluding ``shift``)."""
    target = Interval.from_shift(shift)
    checks: list[Check] = []
    overlap = [o for o in others if conflicts(target, o, 0)[0] and o.shift_id != shift.id]
    duplicate = any(o.shift_id == shift.id for o in others)
    checks.append(Check("duplicate", not duplicate,
                        "Not already assigned to this shift" if not duplicate else "Already assigned to this shift"))
    checks.append(Check("overlap", not overlap,
                        "No overlapping shifts" if not overlap else f"Overlaps {overlap[0].label}"))
    rest_bad = []
    for o in others:
        if o.shift_id == shift.id or o in overlap:
            continue
        bad, why = conflicts(target, o, rules.min_rest_hours)
        if bad and why.startswith("rest"):
            rest_bad.append((o, float(why.split(":")[1])))
    if rest_bad:
        o, gap = min(rest_bad, key=lambda t: t[1])
        checks.append(Check("rest", False, f"Only {gap:.1f}h rest next to {o.label} (minimum {rules.min_rest_hours:g}h)"))
    else:
        gaps = []
        for o in others:
            if o.shift_id == shift.id:
                continue
            first, second = (target, o) if target.start <= o.start else (o, target)
            gaps.append((second.start - first.end).total_seconds() / 3600)
        nearest = min((g for g in gaps if g >= 0), default=None)
        checks.append(Check("rest", True, f"Minimum rest satisfied (nearest gap {nearest:.1f}h)" if nearest is not None
                            else "Minimum rest satisfied (no adjacent shifts)"))
    week_hours = sum(o.duration_hours for o in others if o.week_key == shift.week_key and o.shift_id != shift.id)
    after = week_hours + shift.duration_hours
    within = after <= employee.max_weekly_hours + 1e-6
    checks.append(Check("hours", within,
                        f"Weekly hours after assignment: {after:g}h of {employee.max_weekly_hours:g}h limit" if within
                        else f"Would reach {after:g}h, above the {employee.max_weekly_hours:g}h weekly limit"))
    worked = {o.local_date for o in others if o.shift_id != shift.id} | {shift.local_date}
    nearby = {d for d in worked if d in set(_dates_window(shift.local_date, rules.max_consecutive_days))}
    run = _run_through(nearby, shift.local_date)
    ok = run <= rules.max_consecutive_days
    checks.append(Check("consecutive", ok,
                        f"{run} consecutive working day(s) (limit {rules.max_consecutive_days})" if ok
                        else f"Would create {run} consecutive working days (limit {rules.max_consecutive_days})"))
    return checks


def _run_through(dates: set[str], anchor: str) -> int:
    d = date.fromisoformat(anchor)
    run = 1
    cur = d - timedelta(days=1)
    while cur.isoformat() in dates:
        run += 1
        cur -= timedelta(days=1)
    cur = d + timedelta(days=1)
    while cur.isoformat() in dates:
        run += 1
        cur += timedelta(days=1)
    return run


def preference_checks(employee: EmployeeIn, shift: ShiftIn) -> list[Check]:
    pref_ok = not employee.preferred_shifts or shift.template_code in employee.preferred_shifts
    day_ok = shift.weekday not in employee.preferred_days_off
    return [
        Check("preferred_shift", pref_ok,
              "Matches preferred shift type" if pref_ok and employee.preferred_shifts
              else ("No shift-type preference submitted" if pref_ok else
                    f"Prefers {', '.join(employee.preferred_shifts)} shifts"), "info"),
        Check("preferred_day_off", day_ok,
              "Not a preferred day off" if day_ok else "Falls on a preferred day off", "info"),
    ]


def preference_matched(employee: EmployeeIn, shift: ShiftIn) -> bool:
    return all(c.passed for c in preference_checks(employee, shift))


def evaluate(employee: EmployeeIn, shift: ShiftIn, others: list[Interval], rules: Rules) -> dict:
    hard = static_checks(employee, shift) + dynamic_checks(employee, shift, others, rules)
    soft = preference_checks(employee, shift)
    return {
        "valid": all(c.passed for c in hard),
        "checks": [c.to_dict() for c in hard],
        "preferences": [c.to_dict() for c in soft],
        "failed": [c.to_dict() for c in hard if not c.passed],
    }


SUGGESTIONS = {
    "active": "Reactivate the employee or choose another staff member.",
    "department": "Add this department to the employee's eligible departments or pick an eligible employee.",
    "skills": "Assign a qualified employee or update the employee's qualifications.",
    "leave": "Choose another employee; the leave request has already been approved.",
    "availability": "Ask the employee to update availability or choose someone available.",
    "duplicate": "Remove the duplicate assignment.",
    "overlap": "Remove one of the overlapping assignments.",
    "rest": "Move one of the shifts so the minimum rest period is respected.",
    "hours": "Assign a colleague with remaining weekly capacity or raise the contract limit.",
    "consecutive": "Give the employee a day off within this stretch.",
}


def verify(shifts: list[ShiftIn], employees: list[EmployeeIn], pairs: list[tuple[str, str]], rules: Rules) -> list[Violation]:
    """Independent verifier: reports every hard-constraint violation in an assignment set."""
    shift_by_id = {s.id: s for s in shifts}
    emp_by_id = {e.id: e for e in employees}
    violations: list[Violation] = []
    seen: set[tuple[str, str]] = set()
    by_emp: dict[str, list[ShiftIn]] = {}
    for sid, eid in pairs:
        if (sid, eid) in seen:
            violations.append(Violation("duplicate", "high", "Employee assigned to the same shift twice",
                                        SUGGESTIONS["duplicate"], eid, sid))
            continue
        seen.add((sid, eid))
        if sid in shift_by_id and eid in emp_by_id:
            by_emp.setdefault(eid, []).append(shift_by_id[sid])

    for eid, emp_shifts in by_emp.items():
        emp = emp_by_id[eid]
        fixed = [Interval.from_fixed(f) for f in emp.fixed]
        for s in emp_shifts:
            for c in static_checks(emp, s):
                if not c.passed:
                    violations.append(Violation(c.code if c.code != "availability" else "unavailable", "high",
                                                f"{emp.name}: {c.message} ({s.name or s.template_code} {s.local_date})",
                                                SUGGESTIONS[c.code], eid, s.id))
        ordered = sorted(emp_shifts, key=lambda s: s.start)
        intervals = [Interval.from_shift(s) for s in ordered]
        all_iv = sorted(intervals + fixed, key=lambda i: i.start)
        for i, a in enumerate(all_iv):
            for b in all_iv[i + 1:]:
                if b.start >= a.end + _hours(rules.min_rest_hours):
                    break
                if a.shift_id in shift_by_id or b.shift_id in shift_by_id:
                    bad, why = conflicts(a, b, rules.min_rest_hours)
                    if bad:
                        kind = "overlap" if why == "overlap" else "insufficient_rest"
                        msg = (f"{emp.name}: {a.label} overlaps {b.label}" if kind == "overlap"
                               else f"{emp.name}: only {why.split(':')[1]}h rest between {a.label} and {b.label}")
                        violations.append(Violation(kind, "high", msg, SUGGESTIONS["overlap" if kind == "overlap" else "rest"],
                                                    eid, a.shift_id if a.shift_id in shift_by_id else b.shift_id,
                                                    b.shift_id if a.shift_id in shift_by_id else a.shift_id))
        weeks: dict[str, float] = {}
        for iv in all_iv:
            weeks[iv.week_key] = weeks.get(iv.week_key, 0) + iv.duration_hours
        sched_weeks = {s.week_key for s in emp_shifts}
        for wk, hrs in weeks.items():
            if wk in sched_weeks and hrs > emp.max_weekly_hours + 1e-6:
                violations.append(Violation("weekly_hours", "high",
                                            f"{emp.name}: {hrs:g}h scheduled in week {wk} (limit {emp.max_weekly_hours:g}h)",
                                            SUGGESTIONS["hours"], eid, None, data={"week": wk, "hours": hrs}))
        days = {iv.local_date for iv in all_iv}
        run = max_consecutive(days)
        if run > rules.max_consecutive_days:
            violations.append(Violation("consecutive_days", "medium",
                                        f"{emp.name}: {run} consecutive working days (limit {rules.max_consecutive_days})",
                                        SUGGESTIONS["consecutive"], eid))

    counts: dict[str, int] = {}
    for sid, _ in seen:
        counts[sid] = counts.get(sid, 0) + 1
    for s in shifts:
        assigned = counts.get(s.id, 0)
        if assigned < s.required_staff:
            violations.append(Violation("understaffed", "high" if assigned == 0 else "medium",
                                        f"{s.name or s.template_code} on {s.local_date}: {assigned}/{s.required_staff} staff",
                                        "Run the optimizer or assign an eligible employee manually.", None, s.id,
                                        data={"assigned": assigned, "required": s.required_staff}))
        if assigned > s.required_staff:
            violations.append(Violation("overstaffed", "low",
                                        f"{s.name or s.template_code} on {s.local_date}: {assigned}/{s.required_staff} staff",
                                        "Remove the extra assignment.", None, s.id))
        for mix in s.skill_mix:
            have = sum(1 for sid, eid in seen if sid == s.id and eid in emp_by_id and mix.skill in emp_by_id[eid].skills)
            if have < mix.min:
                violations.append(Violation("skill_mix", "medium",
                                            f"{s.name or s.template_code} on {s.local_date}: {have}/{mix.min} staff with {mix.skill}",
                                            f"Assign an employee qualified in {mix.skill}.", None, s.id))
    return violations


def _hours(h: float) -> timedelta:
    return timedelta(hours=h)
