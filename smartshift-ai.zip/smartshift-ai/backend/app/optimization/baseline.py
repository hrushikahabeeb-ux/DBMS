"""Baseline scheduling algorithms used to measure the value of CP-SAT.

* ``round_robin`` - the naive approach many small teams use: rotate through the
  department roster and pick the next person who holds the skills and is nominally
  available. It ignores rest periods, weekly limits and consecutive days.
* ``greedy`` - a constraint-aware first-fit heuristic: shifts in chronological
  order, each slot given to the valid employee with the fewest hours so far.
  It never violates hard constraints but has no look-ahead.
"""
from __future__ import annotations

import time

from app.optimization.constraints import Interval, dynamic_checks, statically_eligible, window_covers
from app.optimization.types import EmployeeIn, Rules, ShiftIn


def round_robin(shifts: list[ShiftIn], employees: list[EmployeeIn], rules: Rules) -> tuple[list[tuple[str, str]], float]:
    t0 = time.perf_counter()
    roster = sorted([e for e in employees if e.active], key=lambda e: e.code)
    pairs: list[tuple[str, str]] = []
    pointer = 0
    for s in sorted(shifts, key=lambda s: s.start):
        chosen: set[str] = set()
        tries = 0
        while len(chosen) < s.required_staff and tries < len(roster):
            e = roster[pointer % len(roster)] if roster else None
            pointer += 1
            tries += 1
            if e is None:
                break
            if (s.department_id in e.department_ids and all(k in e.skills for k in s.required_skills)
                    and window_covers(e, s) and e.id not in chosen):
                chosen.add(e.id)
                pairs.append((s.id, e.id))
    return pairs, time.perf_counter() - t0


def greedy(shifts: list[ShiftIn], employees: list[EmployeeIn], rules: Rules) -> tuple[list[tuple[str, str]], float]:
    t0 = time.perf_counter()
    assigned: dict[str, list[Interval]] = {e.id: [Interval.from_fixed(f) for f in e.fixed] for e in employees}
    hours = {e.id: 0.0 for e in employees}
    pairs: list[tuple[str, str]] = []
    for s in sorted(shifts, key=lambda s: (s.start, -len(s.required_skills))):
        candidates = []
        for e in employees:
            if not statically_eligible(e, s):
                continue
            if all(c.passed for c in dynamic_checks(e, s, assigned[e.id], rules)):
                candidates.append(e)
        candidates.sort(key=lambda e: (hours[e.id] / max(e.max_weekly_hours, 1), e.code))
        picked: list[EmployeeIn] = []
        for mix in s.skill_mix:
            have = sum(1 for p in picked if mix.skill in p.skills)
            for c in candidates:
                if have >= mix.min or len(picked) >= s.required_staff:
                    break
                if c not in picked and mix.skill in c.skills:
                    picked.append(c)
                    have += 1
        for c in candidates:
            if len(picked) >= s.required_staff:
                break
            if c not in picked:
                picked.append(c)
        for e in picked:
            pairs.append((s.id, e.id))
            assigned[e.id].append(Interval.from_shift(s))
            hours[e.id] += s.duration_hours
    return pairs, time.perf_counter() - t0
