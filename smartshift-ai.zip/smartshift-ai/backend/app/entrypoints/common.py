"""Shared FastAPI application factory for all services."""
from collections.abc import AsyncIterator, Callable
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.core.errors import register_exception_handlers
from app.core.logging import configure_logging
from app.core.middleware import CorrelationIdMiddleware
from app.database.mongo import Mongo


def create_service(name: str, title: str, description: str, use_mongo: bool = True,
                   on_startup: Callable | None = None, on_shutdown: Callable | None = None) -> FastAPI:
    settings = get_settings()
    configure_logging(name)

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        if use_mongo:
            Mongo.connect()
        if on_startup:
            await on_startup()
        yield
        if on_shutdown:
            await on_shutdown()
        if use_mongo:
            await Mongo.close()

    app = FastAPI(title=title, description=description, version="1.0.0", lifespan=lifespan,
                  docs_url="/docs", openapi_url="/openapi.json")
    app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origin_list, allow_credentials=True,
                       allow_methods=["*"], allow_headers=["*"], expose_headers=["X-Correlation-ID"])
    app.add_middleware(CorrelationIdMiddleware)
    register_exception_handlers(app)
    return app
