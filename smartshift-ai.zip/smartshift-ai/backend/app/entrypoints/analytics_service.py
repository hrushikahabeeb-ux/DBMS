"""Analytics Service (port 8003).

Read-only reporting over MongoDB aggregation pipelines. Called by the main API
gateway with a service token and the caller's department scope.
"""
import csv
import io
from datetime import date, datetime, timedelta, timezone

from bson import ObjectId
from fastapi import APIRouter, Depends, Header, Query

from app.api.deps import require_service
from app.core.errors import NotFoundError, ValidationFailed
from app.database.mongo import Collections as C
from app.database.mongo import get_db, serialize
from app.entrypoints.common import create_service
from app.optimization.metrics import compute_metrics
from app.services.scheduling_data import get_rules_doc, schedule_context
from app.utils.ids import oid
from app.utils.timeutils import local_today, utcnow

app = create_service("smartshift-analytics", "SmartShift AI - Analytics Service",
                     "Workforce analytics using MongoDB aggregation pipelines.")
router = APIRouter(prefix="/analytics", dependencies=[Depends(require_service)], tags=["Analytics"])


def scope_from(header: str | None, department_id: str | None) -> list[ObjectId] | None:
    allowed = None if header in (None, "*") else [ObjectId(x) for x in header.split(",") if x]
    if department_id:
        d = oid(department_id)
        if allowed is not None and d not in allowed:
            raise ValidationFailed("Department outside your scope")
        return [d]
    return allowed


def dept_match(scope: list[ObjectId] | None, field: str = "department_id") -> dict:
    return {} if scope is None else {field: {"$in": scope}}


def utc_bounds(start: date, end: date) -> tuple[datetime, datetime]:
    return (datetime(start.year, start.month, start.day, tzinfo=timezone.utc) - timedelta(hours=6),
            datetime(end.year, end.month, end.day, tzinfo=timezone.utc) + timedelta(days=1))


async def tz() -> str:
    return (await get_rules_doc())["timezone"]


def default_range(start: date | None, end: date | None, zone: str) -> tuple[date, date]:
    today = local_today(zone)
    s = start or (today - timedelta(days=today.weekday()))
    e = end or (s + timedelta(days=6))
    if e < s:
        raise ValidationFailed("end must be after start")
    if (e - s).days > 92:
        raise ValidationFailed("Range limited to 92 days")
    return s, e


async def agg(coll: str, pipeline: list) -> list:
    return await (await get_db()[coll].aggregate(pipeline)).to_list()


@app.get("/health", tags=["Health"])
async def health():
    from app.database.mongo import Mongo
    return {"service": "analytics", "status": "ok", "mongodb": await Mongo.ping()}


@router.get("/overview")
async def overview(department_id: str | None = None, x_user_scope: str | None = Header(None)):
    scope = scope_from(x_user_scope, department_id)
    zone = await tz()
    rules = await get_rules_doc()
    today = local_today(zone)
    week_end = today + timedelta(days=6)
    db = get_db()
    emp_q = {"status": "active", **dept_match(scope, "department_ids")}
    total_employees = await db[C.EMPLOYEES].count_documents(emp_q)
    active_depts = await db[C.DEPARTMENTS].count_documents({"is_active": True, **dept_match(scope, "_id")})
    published = await db[C.SCHEDULES].distinct("_id", {"status": "published", **dept_match(scope)})

    shift_week = await agg(C.SHIFTS, [
        {"$match": {"local_date": {"$gte": today.isoformat(), "$lte": week_end.isoformat()}, **dept_match(scope)}},
        {"$group": {"_id": "$local_date", "required": {"$sum": "$required_staff"},
                    "filled": {"$sum": {"$min": ["$assigned_count", "$required_staff"]}}, "shifts": {"$sum": 1},
                    "unfilled_shifts": {"$sum": {"$cond": [{"$lt": ["$assigned_count", "$required_staff"]}, 1, 0]}}}},
        {"$sort": {"_id": 1}},
    ])
    by_day = {d["_id"]: d for d in shift_week}
    required = sum(d["required"] for d in shift_week)
    filled = sum(d["filled"] for d in shift_week)

    today_shifts = by_day.get(today.isoformat(), {}).get("shifts", 0)
    t0, t1 = utc_bounds(today, today)
    now = utcnow()
    scheduled_today = len(await db[C.ASSIGNMENTS].distinct("employee_id", {
        "status": "active", "schedule_id": {"$in": published},
        "start": {"$lt": now + timedelta(hours=24)}, "end": {"$gt": now - timedelta(hours=2)}, **dept_match(scope)}))
    on_leave = await db[C.LEAVE_REQUESTS].count_documents({"status": "approved", "start_date": {"$lte": today.isoformat()},
                                                           "end_date": {"$gte": today.isoformat()}, **dept_match(scope)})
    monday = today - timedelta(days=today.weekday())
    w0, w1 = utc_bounds(monday, monday + timedelta(days=6))
    threshold = rules.get("overtime_threshold_hours", 40)
    hours_week = await agg(C.ASSIGNMENTS, [
        {"$match": {"status": "active", "start": {"$gte": w0 + timedelta(hours=6), "$lt": w1}, **dept_match(scope)}},
        {"$group": {"_id": "$employee_id", "hours": {"$sum": "$duration_hours"}}},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "_id", "foreignField": "_id", "as": "e",
                     "pipeline": [{"$project": {"full_name": 1, "max_weekly_hours": 1}}]}},
        {"$unwind": "$e"},
        {"$match": {"$expr": {"$or": [{"$gt": ["$hours", threshold]},
                                      {"$gte": ["$hours", {"$multiply": ["$e.max_weekly_hours", 0.9]}]}]}}},
        {"$project": {"name": "$e.full_name", "hours": 1, "max": "$e.max_weekly_hours"}},
        {"$sort": {"hours": -1}},
    ])
    timeline = await agg(C.SHIFTS, [
        {"$match": {"start": {"$gte": now - timedelta(hours=4), "$lte": now + timedelta(hours=30)}, **dept_match(scope)}},
        {"$sort": {"start": 1}}, {"$limit": 12},
        {"$lookup": {"from": C.ASSIGNMENTS, "localField": "_id", "foreignField": "shift_id", "as": "assignees",
                     "pipeline": [{"$match": {"status": "active"}},
                                  {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id",
                                               "as": "e", "pipeline": [{"$project": {"full_name": 1}}]}},
                                  {"$project": {"name": {"$first": "$e.full_name"}}}]}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "dept",
                     "pipeline": [{"$project": {"name": 1, "code": 1}}]}},
        {"$project": {"name": 1, "template_code": 1, "start": 1, "end": 1, "required_staff": 1, "assigned_count": 1,
                      "assignees": "$assignees.name", "department": {"$first": "$dept"}}},
    ])
    dept_overview = await agg(C.SHIFTS, [
        {"$match": {"local_date": {"$gte": today.isoformat(), "$lte": week_end.isoformat()}, **dept_match(scope)}},
        {"$group": {"_id": "$department_id", "required": {"$sum": "$required_staff"},
                    "filled": {"$sum": {"$min": ["$assigned_count", "$required_staff"]}}}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "_id", "foreignField": "_id", "as": "d"}},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "_id", "foreignField": "department_ids", "as": "staff",
                     "pipeline": [{"$match": {"status": "active"}}, {"$project": {"_id": 1}}]}},
        {"$project": {"name": {"$first": "$d.name"}, "code": {"$first": "$d.code"}, "required": 1, "filled": 1,
                      "staff": {"$size": "$staff"}}},
        {"$sort": {"name": 1}},
    ])
    vacancies = await db[C.ASSIGNMENTS].count_documents({"status": "absent", "replaced_by_assignment_id": None,
                                                         "end": {"$gte": now}, **dept_match(scope)})
    understaffed = await agg(C.SHIFTS, [
        {"$match": {"local_date": {"$gte": today.isoformat(), "$lte": week_end.isoformat()},
                    "$expr": {"$lt": ["$assigned_count", "$required_staff"]}, **dept_match(scope)}},
        {"$sort": {"start": 1}}, {"$limit": 8},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "d",
                     "pipeline": [{"$project": {"name": 1}}]}},
        {"$lookup": {"from": C.SCHEDULES, "localField": "schedule_id", "foreignField": "_id", "as": "sc",
                     "pipeline": [{"$project": {"status": 1}}]}},
        {"$project": {"name": 1, "local_date": 1, "required_staff": 1, "assigned_count": 1,
                      "department": {"$first": "$d.name"}, "schedule_status": {"$first": "$sc.status"}}},
    ])
    emp_ids = await db[C.EMPLOYEES].distinct("_id", emp_q)
    with_avail = await db[C.AVAILABILITY].count_documents({"employee_id": {"$in": emp_ids}, "recurring.0": {"$exists": True}})
    unavailable_today = await db[C.AVAILABILITY].count_documents({"employee_id": {"$in": emp_ids},
                                                                  "unavailable_dates": today.isoformat()})
    pref_breakdown = await agg(C.AVAILABILITY, [
        {"$match": {"employee_id": {"$in": emp_ids}}}, {"$unwind": "$preferred_shifts"},
        {"$group": {"_id": "$preferred_shifts", "count": {"$sum": 1}}}, {"$sort": {"_id": 1}},
    ])
    activity = await db[C.AUDIT_LOGS].find({}, {"action": 1, "actor_email": 1, "entity_type": 1, "created_at": 1,
                                                "details": 1}).sort("created_at", -1).limit(10).to_list()
    days = [(today + timedelta(days=i)).isoformat() for i in range(7)]
    return serialize({
        "as_of": now, "today": today.isoformat(),
        "kpis": {
            "total_employees": total_employees, "scheduled_today": scheduled_today,
            "active_departments": active_depts, "todays_shifts": today_shifts,
            "unfilled_shifts": sum(d["unfilled_shifts"] for d in shift_week),
            "unfilled_slots": required - filled, "employees_on_leave": on_leave,
            "overtime_risk": len(hours_week),
            "weekly_coverage_pct": round(100 * filled / required, 1) if required else None,
        },
        "weekly_distribution": [{"date": d, "required": by_day.get(d, {}).get("required", 0),
                                 "filled": by_day.get(d, {}).get("filled", 0)} for d in days],
        "department_overview": dept_overview, "timeline": timeline, "overtime_risk": hours_week[:8],
        "alerts": {"open_vacancies": vacancies, "understaffed_shifts": understaffed},
        "availability": {"employees": total_employees, "with_availability": with_avail,
                         "unavailable_today": unavailable_today,
                         "preferences": {p["_id"]: p["count"] for p in pref_breakdown}},
        "activity": activity,
    })


@router.get("/coverage")
async def coverage(start: date | None = None, end: date | None = None, department_id: str | None = None,
                   x_user_scope: str | None = Header(None)):
    scope = scope_from(x_user_scope, department_id)
    s, e = default_range(start, end, await tz())
    rows = await agg(C.SHIFTS, [
        {"$match": {"local_date": {"$gte": s.isoformat(), "$lte": e.isoformat()}, **dept_match(scope)}},
        {"$group": {"_id": {"date": "$local_date", "code": "$template_code"},
                    "required": {"$sum": "$required_staff"},
                    "filled": {"$sum": {"$min": ["$assigned_count", "$required_staff"]}}}},
        {"$project": {"_id": 0, "date": "$_id.date", "template_code": "$_id.code", "required": 1, "filled": 1,
                      "coverage_pct": {"$cond": [{"$gt": ["$required", 0]},
                                                 {"$round": [{"$multiply": [{"$divide": ["$filled", "$required"]}, 100]}, 1]},
                                                 100]}}},
        {"$sort": {"date": 1, "template_code": 1}},
    ])
    return {"start": s.isoformat(), "end": e.isoformat(), "cells": rows}


async def _assignment_rows(s: date, e: date, scope, zone: str) -> list:
    t0, t1 = utc_bounds(s, e)
    return await agg(C.ASSIGNMENTS, [
        {"$match": {"status": "active", "start": {"$gte": t0, "$lt": t1}, **dept_match(scope)}},
        {"$lookup": {"from": C.SHIFTS, "localField": "shift_id", "foreignField": "_id", "as": "shift",
                     "pipeline": [{"$project": {"local_date": 1, "is_night": 1, "is_weekend": 1, "template_code": 1}}]}},
        {"$unwind": "$shift"},
        {"$match": {"shift.local_date": {"$gte": s.isoformat(), "$lte": e.isoformat()}}},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id", "as": "emp",
                     "pipeline": [{"$project": {"full_name": 1, "employee_code": 1, "hourly_wage": 1,
                                                "max_weekly_hours": 1, "primary_department_id": 1}}]}},
        {"$unwind": "$emp"},
    ])


@router.get("/hours")
async def hours(start: date | None = None, end: date | None = None, department_id: str | None = None,
                x_user_scope: str | None = Header(None)):
    scope = scope_from(x_user_scope, department_id)
    zone = await tz()
    s, e = default_range(start, end, zone)
    threshold = (await get_rules_doc()).get("overtime_threshold_hours", 40)
    t0, t1 = utc_bounds(s, e)
    rows = await agg(C.ASSIGNMENTS, [
        {"$match": {"status": "active", "start": {"$gte": t0, "$lt": t1}, **dept_match(scope)}},
        {"$lookup": {"from": C.SHIFTS, "localField": "shift_id", "foreignField": "_id", "as": "shift",
                     "pipeline": [{"$project": {"local_date": 1, "is_night": 1, "is_weekend": 1}}]}},
        {"$unwind": "$shift"},
        {"$match": {"shift.local_date": {"$gte": s.isoformat(), "$lte": e.isoformat()}}},
        {"$group": {"_id": {"emp": "$employee_id",
                            "week": {"$dateToString": {"format": "%G-W%V", "date": "$start", "timezone": zone}}},
                    "hours": {"$sum": "$duration_hours"}, "shifts": {"$sum": 1},
                    "nights": {"$sum": {"$cond": ["$shift.is_night", 1, 0]}},
                    "weekends": {"$sum": {"$cond": ["$shift.is_weekend", 1, 0]}}}},
        {"$addFields": {"overtime": {"$max": [0, {"$subtract": ["$hours", threshold]}]}}},
        {"$group": {"_id": "$_id.emp", "hours": {"$sum": "$hours"}, "shifts": {"$sum": "$shifts"},
                    "nights": {"$sum": "$nights"}, "weekends": {"$sum": "$weekends"},
                    "overtime_hours": {"$sum": "$overtime"}, "weeks": {"$sum": 1}}},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "_id", "foreignField": "_id", "as": "emp",
                     "pipeline": [{"$project": {"full_name": 1, "employee_code": 1, "max_weekly_hours": 1,
                                                "hourly_wage": 1}}]}},
        {"$unwind": "$emp"},
        {"$project": {"_id": 0, "employee_id": "$_id", "name": "$emp.full_name", "code": "$emp.employee_code",
                      "max_weekly_hours": "$emp.max_weekly_hours", "hours": 1, "shifts": 1, "nights": 1,
                      "weekends": 1, "overtime_hours": 1,
                      "labor_cost": {"$multiply": ["$hours", "$emp.hourly_wage"]}}},
        {"$sort": {"hours": -1}},
    ])
    return {"start": s.isoformat(), "end": e.isoformat(), "overtime_threshold": threshold, "employees": serialize(rows)}


@router.get("/departments")
async def department_utilization(start: date | None = None, end: date | None = None,
                                 x_user_scope: str | None = Header(None)):
    scope = scope_from(x_user_scope, None)
    zone = await tz()
    s, e = default_range(start, end, zone)
    weeks = max(1, ((e - s).days + 1) / 7)
    t0, t1 = utc_bounds(s, e)
    rows = await agg(C.DEPARTMENTS, [
        {"$match": {"is_active": True, **dept_match(scope, "_id")}},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "_id", "foreignField": "primary_department_id", "as": "staff",
                     "pipeline": [{"$match": {"status": "active"}}, {"$project": {"max_weekly_hours": 1}}]}},
        {"$lookup": {"from": C.ASSIGNMENTS, "localField": "_id", "foreignField": "department_id", "as": "work",
                     "pipeline": [{"$match": {"status": "active", "start": {"$gte": t0, "$lt": t1}}},
                                  {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id",
                                               "as": "e", "pipeline": [{"$project": {"hourly_wage": 1}}]}},
                                  {"$project": {"duration_hours": 1, "wage": {"$first": "$e.hourly_wage"}}}]}},
        {"$lookup": {"from": C.SHIFTS, "localField": "_id", "foreignField": "department_id", "as": "demand",
                     "pipeline": [{"$match": {"local_date": {"$gte": s.isoformat(), "$lte": e.isoformat()}}},
                                  {"$project": {"required_staff": 1, "assigned_count": 1, "duration_hours": 1}}]}},
        {"$project": {
            "name": 1, "code": 1,
            "staff": {"$size": "$staff"},
            "capacity_hours": {"$multiply": [{"$sum": "$staff.max_weekly_hours"}, weeks]},
            "assigned_hours": {"$sum": "$work.duration_hours"},
            "labor_cost": {"$sum": {"$map": {"input": "$work", "as": "w",
                                             "in": {"$multiply": ["$$w.duration_hours", {"$ifNull": ["$$w.wage", 0]}]}}}},
            "required_hours": {"$sum": {"$map": {"input": "$demand", "as": "d",
                                                 "in": {"$multiply": ["$$d.required_staff", "$$d.duration_hours"]}}}},
            "shortage_slots": {"$sum": {"$map": {"input": "$demand", "as": "d",
                                                 "in": {"$max": [0, {"$subtract": ["$$d.required_staff",
                                                                                   "$$d.assigned_count"]}]}}}},
        }},
        {"$addFields": {"utilization_pct": {"$cond": [{"$gt": ["$capacity_hours", 0]}, {"$round": [
            {"$multiply": [{"$divide": ["$assigned_hours", "$capacity_hours"]}, 100]}, 1]}, 0]}}},
        {"$sort": {"name": 1}},
    ])
    return {"start": s.isoformat(), "end": e.isoformat(), "departments": serialize(rows)}


@router.get("/labor-cost")
async def labor_cost(start: date | None = None, end: date | None = None, department_id: str | None = None,
                     x_user_scope: str | None = Header(None)):
    scope = scope_from(x_user_scope, department_id)
    zone = await tz()
    s, e = default_range(start, end, zone)
    t0, t1 = utc_bounds(s, e)
    rows = await agg(C.ASSIGNMENTS, [
        {"$match": {"status": "active", "start": {"$gte": t0, "$lt": t1}, **dept_match(scope)}},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id", "as": "e",
                     "pipeline": [{"$project": {"hourly_wage": 1}}]}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "d",
                     "pipeline": [{"$project": {"code": 1}}]}},
        {"$group": {"_id": {"date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$start", "timezone": zone}},
                            "dept": {"$first": "$d.code"}},
                    "cost": {"$sum": {"$multiply": ["$duration_hours", {"$first": "$e.hourly_wage"}]}},
                    "hours": {"$sum": "$duration_hours"}}},
        {"$match": {"_id.date": {"$gte": s.isoformat(), "$lte": e.isoformat()}}},
        {"$project": {"_id": 0, "date": "$_id.date", "department": "$_id.dept", "cost": {"$round": ["$cost", 0]},
                      "hours": 1}},
        {"$sort": {"date": 1, "department": 1}},
    ])
    return {"start": s.isoformat(), "end": e.isoformat(), "rows": rows}


@router.get("/leave-trends")
async def leave_trends(months: int = Query(6, ge=1, le=24), department_id: str | None = None,
                       x_user_scope: str | None = Header(None)):
    scope = scope_from(x_user_scope, department_id)
    since = (local_today(await tz()).replace(day=1) - timedelta(days=31 * (months - 1))).replace(day=1)
    rows = await agg(C.LEAVE_REQUESTS, [
        {"$match": {"start_date": {"$gte": since.isoformat()}, **dept_match(scope)}},
        {"$group": {"_id": {"month": {"$substrBytes": ["$start_date", 0, 7]}, "type": "$leave_type",
                            "status": "$status"}, "count": {"$sum": 1}}},
        {"$project": {"_id": 0, "month": "$_id.month", "leave_type": "$_id.type", "status": "$_id.status",
                      "count": 1}},
        {"$sort": {"month": 1}},
    ])
    return {"since": since.isoformat(), "rows": rows}


@router.get("/shortages")
async def shortages(start: date | None = None, end: date | None = None, department_id: str | None = None,
                    x_user_scope: str | None = Header(None)):
    scope = scope_from(x_user_scope, department_id)
    s, e = default_range(start, end, await tz())
    rows = await agg(C.SHIFTS, [
        {"$match": {"local_date": {"$gte": s.isoformat(), "$lte": e.isoformat()},
                    "$expr": {"$lt": ["$assigned_count", "$required_staff"]}, **dept_match(scope)}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "d",
                     "pipeline": [{"$project": {"name": 1}}]}},
        {"$project": {"local_date": 1, "name": 1, "template_code": 1, "required_staff": 1, "assigned_count": 1,
                      "missing": {"$subtract": ["$required_staff", "$assigned_count"]}, "department": {"$first": "$d.name"}}},
        {"$sort": {"local_date": 1, "template_code": 1}},
    ])
    return {"start": s.isoformat(), "end": e.isoformat(), "shortages": serialize(rows)}


@router.get("/fairness")
async def fairness(schedule_id: str, x_user_scope: str | None = Header(None)):
    schedule = await get_db()[C.SCHEDULES].find_one({"_id": oid(schedule_id)})
    if not schedule:
        raise NotFoundError("Schedule not found")
    scope_from(x_user_scope, str(schedule["department_id"]))
    ctx = await schedule_context(schedule)
    pairs = [(str(a["shift_id"]), str(a["employee_id"])) for a in ctx["assignments"]]
    m = compute_metrics(ctx["shifts"], ctx["employees"], pairs, ctx["rules"])
    m.pop("violations", None)
    m["formula"] = ("fairness = 100 x (0.4 x (1 - Gini(hours / contract hours)) + 0.2 x (1 - Gini(night shifts)) "
                    "+ 0.2 x (1 - Gini(weekend shifts)) + 0.2 x preference satisfaction)")
    return m


@router.get("/optimization-comparison")
async def optimization_comparison(schedule_id: str | None = None, department_id: str | None = None,
                                  x_user_scope: str | None = Header(None)):
    scope = scope_from(x_user_scope, department_id)
    q = {"status": "completed", "kind": "generate", **dept_match(scope)}
    if schedule_id:
        q["schedule_id"] = oid(schedule_id)
    run = await get_db()[C.OPTIMIZATION_RUNS].find_one(q, sort=[("finished_at", -1)])
    if not run:
        return {"run": None, "rows": []}
    keys = ["coverage_pct", "fairness_score", "preference_satisfaction_pct", "labor_cost", "overtime_hours",
            "constraint_violations", "unfilled_count"]
    rows = []
    res = run["result"]
    for name, v in res.get("variants", {}).items():
        if v.get("metrics"):
            rows.append({"strategy": f"CP-SAT {name}", "solve_seconds": v["solve_seconds"],
                         **{k: v["metrics"][k] for k in keys}})
    for name, v in res.get("baselines", {}).items():
        rows.append({"strategy": f"Baseline {name}", "solve_seconds": v["solve_seconds"],
                     **{k: v["metrics"][k] for k in keys}})
    return {"run": {"id": str(run["_id"]), "schedule_id": str(run["schedule_id"]), "finished_at": run["finished_at"]},
            "rows": serialize(rows)}


@router.get("/export/{report}")
async def export(report: str, start: date | None = None, end: date | None = None, department_id: str | None = None,
                 x_user_scope: str | None = Header(None)):
    if report == "hours":
        data = (await hours(start, end, department_id, x_user_scope))["employees"]
        cols = ["code", "name", "hours", "shifts", "nights", "weekends", "overtime_hours", "labor_cost"]
    elif report == "coverage":
        data = (await coverage(start, end, department_id, x_user_scope))["cells"]
        cols = ["date", "template_code", "required", "filled", "coverage_pct"]
    elif report == "labor-cost":
        data = (await labor_cost(start, end, department_id, x_user_scope))["rows"]
        cols = ["date", "department", "hours", "cost"]
    elif report == "shortages":
        data = (await shortages(start, end, department_id, x_user_scope))["shortages"]
        cols = ["local_date", "department", "name", "required_staff", "assigned_count", "missing"]
    else:
        raise NotFoundError("Unknown report")
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    for r in data:
        w.writerow(r)
    return {"filename": f"smartshift-{report}-{date.today().isoformat()}.csv", "csv": buf.getvalue(), "rows": len(data)}


@router.get("/query-performance", summary="CO1: explain-plan comparison with and without indexes")
async def query_performance():
    from app.database.explain import compare_all
    return await compare_all(get_db())


app.include_router(router)
