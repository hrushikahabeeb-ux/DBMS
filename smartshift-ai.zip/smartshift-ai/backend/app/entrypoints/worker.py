"""Scheduling job worker (separate process).

Reliable queue pattern: BLMOVE moves a job from ``smartshift:jobs`` to a
processing list; it is removed only after the run is persisted. On startup any
jobs left in the processing list (worker crash) are moved back to the queue.
"""
import asyncio
import json
import logging
import signal

from bson import ObjectId

from app.core.logging import configure_logging, correlation_id_var, log_event
from app.database.mongo import Mongo
from app.services.events import JOBS_PROCESSING, JOBS_QUEUE, get_redis
from app.services.optimization_jobs import process_run
from app.utils.timeutils import utcnow

logger = logging.getLogger("worker")
HEARTBEAT_KEY = "smartshift:worker:heartbeat"


async def recover(redis) -> int:
    moved = 0
    while await redis.lmove(JOBS_PROCESSING, JOBS_QUEUE, "RIGHT", "LEFT"):
        moved += 1
    return moved


async def heartbeat(redis, stop: asyncio.Event) -> None:
    while not stop.is_set():
        try:
            await redis.set(HEARTBEAT_KEY, utcnow().isoformat(), ex=30)
        except Exception:  # noqa: BLE001
            pass
        await asyncio.sleep(10)


async def run_worker(stop: asyncio.Event | None = None) -> None:
    configure_logging("smartshift-worker")
    stop = stop or asyncio.Event()
    Mongo.connect()
    redis = get_redis()
    recovered = await recover(redis)
    log_event(logger, "worker started", recovered_jobs=recovered)
    beat = asyncio.create_task(heartbeat(redis, stop))
    while not stop.is_set():
        try:
            raw = await redis.blmove(JOBS_QUEUE, JOBS_PROCESSING, timeout=2, src="RIGHT", dest="LEFT")
        except Exception as exc:  # noqa: BLE001
            log_event(logger, "redis unavailable", error=str(exc))
            await asyncio.sleep(3)
            continue
        if not raw:
            continue
        job = json.loads(raw)
        token = correlation_id_var.set(job.get("correlation_id", "-"))
        try:
            log_event(logger, "job started", run_id=job["run_id"])
            result = await process_run(ObjectId(job["run_id"]))
            log_event(logger, "job finished", run_id=job["run_id"], result=result)
            if result.get("retry"):
                await asyncio.sleep(3)
                await redis.lpush(JOBS_QUEUE, raw)
        finally:
            await redis.lrem(JOBS_PROCESSING, 1, raw)
            correlation_id_var.reset(token)
    beat.cancel()
    await Mongo.close()


def main() -> None:
    stop = asyncio.Event()

    async def runner():
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, stop.set)
        await run_worker(stop)

    asyncio.run(runner())


if __name__ == "__main__":
    main()
