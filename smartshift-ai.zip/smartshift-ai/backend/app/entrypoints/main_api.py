"""Main API service (port 8000): auth, workforce data, schedules, workflows."""
from fastapi import APIRouter

from app.api import admin, assignments, auth, departments, employees, schedules, users, workforce
from app.database.init_db import init_database
from app.database.mongo import Mongo, get_db
from app.entrypoints.common import create_service
from app.services.events import close_redis, redis_ok


async def startup():
    try:
        await init_database(get_db())
    except Exception:  # noqa: BLE001 - the API still starts and reports 503s while MongoDB is down
        import logging
        logging.getLogger(__name__).exception("database initialization failed; will retry on demand")


app = create_service(
    "smartshift-api", "SmartShift AI - Main API",
    "Authentication, employees, departments, schedules, assignments, leave, swaps and emergency replacement.",
    on_startup=startup, on_shutdown=close_redis,
)

api = APIRouter(prefix="/api")
for r in (auth.router, users.router, employees.router, departments.router, schedules.router, assignments.router,
          workforce.router, admin.router):
    api.include_router(r)
app.include_router(api)


@app.get("/health", tags=["Health"])
@app.get("/api/health", tags=["Health"], include_in_schema=False)
async def health():
    mongo = await Mongo.ping()
    redis = await redis_ok()
    return {"service": "api", "status": "ok" if mongo else "degraded", "mongodb": mongo, "redis": redis}
