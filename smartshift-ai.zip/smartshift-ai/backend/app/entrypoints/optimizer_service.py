"""Scheduling Optimization Service (port 8001).

Stateless: receives fully assembled inputs over authenticated HTTP, runs CP-SAT
and the baselines, and returns schedules plus metrics. It owns no data.
"""
import asyncio
import time

from fastapi import Depends

from app.api.deps import require_service
from app.entrypoints.common import create_service
from app.optimization.constraints import evaluate, Interval, verify
from app.optimization.metrics import compute_metrics
from app.optimization.solver import optimize
from app.optimization.types import OptimizeRequest, ValidateRequest

app = create_service("smartshift-optimizer", "SmartShift AI - Optimization Service",
                     "OR-Tools CP-SAT schedule optimization, constraint validation and metrics.", use_mongo=False)

_started = time.time()
_runs = {"count": 0}
_semaphore = asyncio.Semaphore(2)


@app.get("/health", tags=["Health"])
async def health():
    import ortools
    return {"service": "optimizer", "status": "ok", "ortools": ortools.__version__, "uptime_s": round(time.time() - _started),
            "runs_served": _runs["count"]}


@app.post("/optimize", dependencies=[Depends(require_service)], tags=["Optimization"])
async def run_optimize(req: OptimizeRequest):
    async with _semaphore:
        result = await asyncio.to_thread(optimize, req)
    _runs["count"] += 1
    return result


@app.post("/validate", dependencies=[Depends(require_service)], tags=["Optimization"])
async def run_validate(req: ValidateRequest):
    pairs = [(p.shift_id, p.employee_id) for p in req.assignments]
    violations = verify(req.shifts, req.employees, pairs, req.rules)
    return {"violations": [v.to_dict() for v in violations], "metrics": compute_metrics(req.shifts, req.employees, pairs,
                                                                                         req.rules)}


@app.post("/check-pair", dependencies=[Depends(require_service)], tags=["Optimization"])
async def check_pair(req: ValidateRequest):
    """Evaluate the first assignment in ``req.assignments`` against all hard constraints."""
    p = req.assignments[0]
    emp = next(e for e in req.employees if e.id == p.employee_id)
    shift = next(s for s in req.shifts if s.id == p.shift_id)
    return evaluate(emp, shift, [Interval.from_fixed(f) for f in emp.fixed], req.rules)
