"""Notification Service (port 8002).

* Consumes events from the Redis list ``smartshift:events`` asynchronously.
* Persists notifications in MongoDB (it owns the ``notifications`` collection).
* Delivers them in real time over WebSockets.
* Periodically emits upcoming-shift reminders (deduplicated by a unique key).
"""
import asyncio
import json
import logging
from datetime import timedelta

from bson import ObjectId
from fastapi import Depends, Query, WebSocket, WebSocketDisconnect
from pymongo.errors import DuplicateKeyError

from app.api.deps import CurrentUser, get_current_user
from app.core.errors import NotFoundError, UnauthorizedError
from app.core.logging import correlation_id_var, log_event
from app.core.security import decode_access_token
from app.database.mongo import Collections as C
from app.database.mongo import get_db, serialize
from app.entrypoints.common import create_service
from app.services.events import EVENTS_QUEUE, close_redis, get_redis, redis_ok
from app.utils.ids import oid
from app.utils.timeutils import utcnow
from app.websocket.manager import manager

logger = logging.getLogger("notifications")
_tasks: list[asyncio.Task] = []
_stats = {"processed": 0, "delivered_ws": 0, "reminders": 0}


async def deliver(event: dict) -> int:
    db = get_db()
    now = utcnow()
    created = 0
    for uid in event.get("user_ids", []):
        doc = {"user_id": ObjectId(uid), "type": event["type"], "title": event["title"], "message": event["message"],
               "data": event.get("data") or {}, "read": False, "created_at": now}
        if event.get("dedupe_key"):
            doc["dedupe_key"] = f"{event['dedupe_key']}:{uid}"
        try:
            res = await db[C.NOTIFICATIONS].insert_one(doc)
        except DuplicateKeyError:
            continue
        doc["_id"] = res.inserted_id
        created += 1
        _stats["delivered_ws"] += await manager.send(uid, {"kind": "notification", "notification": serialize(doc)})
    return created


async def consume(stop: asyncio.Event) -> None:
    redis = get_redis()
    while not stop.is_set():
        try:
            item = await redis.brpop([EVENTS_QUEUE], timeout=2)
        except Exception as exc:  # noqa: BLE001
            log_event(logger, "event bus unavailable", error=str(exc))
            await asyncio.sleep(3)
            continue
        if not item:
            continue
        event = json.loads(item[1])
        token = correlation_id_var.set(event.get("correlation_id", "-"))
        try:
            n = await deliver(event)
            _stats["processed"] += 1
            log_event(logger, "event processed", type=event.get("type"), created=n)
        except Exception:  # noqa: BLE001
            logger.exception("failed to process event; requeueing")
            await redis.lpush(EVENTS_QUEUE, item[1])
            await asyncio.sleep(1)
        finally:
            correlation_id_var.reset(token)


async def reminders_once(hours: int = 12) -> int:
    db = get_db()
    now = utcnow()
    published = await db[C.SCHEDULES].distinct("_id", {"status": "published"})
    pipeline = [
        {"$match": {"status": "active", "schedule_id": {"$in": published},
                    "start": {"$gte": now, "$lte": now + timedelta(hours=hours)}}},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id", "as": "employee",
                     "pipeline": [{"$project": {"user_id": 1}}]}},
        {"$lookup": {"from": C.SHIFTS, "localField": "shift_id", "foreignField": "_id", "as": "shift",
                     "pipeline": [{"$project": {"name": 1, "local_date": 1}}]}},
        {"$unwind": "$employee"}, {"$unwind": "$shift"},
        {"$match": {"employee.user_id": {"$ne": None}}},
    ]
    count = 0
    async for a in await db[C.ASSIGNMENTS].aggregate(pipeline):
        count += await deliver({
            "type": "shift.upcoming", "title": "Upcoming shift",
            "message": f"Reminder: {a['shift']['name']} shift on {a['shift']['local_date']}.",
            "data": {"assignment_id": str(a["_id"])}, "user_ids": [str(a["employee"]["user_id"])],
            "dedupe_key": f"upcoming:{a['_id']}"})
    _stats["reminders"] += count
    return count


async def reminder_loop(stop: asyncio.Event) -> None:
    while not stop.is_set():
        try:
            await reminders_once()
        except Exception:  # noqa: BLE001
            logger.exception("reminder pass failed")
        try:
            await asyncio.wait_for(stop.wait(), timeout=300)
        except asyncio.TimeoutError:
            pass


_stop = asyncio.Event()


async def startup():
    _stop.clear()
    _tasks.append(asyncio.create_task(consume(_stop)))
    _tasks.append(asyncio.create_task(reminder_loop(_stop)))


async def shutdown():
    _stop.set()
    for t in _tasks:
        t.cancel()
    _tasks.clear()
    await close_redis()


app = create_service("smartshift-notifications", "SmartShift AI - Notification Service",
                     "Asynchronous event processing, persisted notifications and WebSocket delivery.",
                     on_startup=startup, on_shutdown=shutdown)


@app.get("/health", tags=["Health"])
async def health():
    from app.database.mongo import Mongo
    return {"service": "notification", "status": "ok", "mongodb": await Mongo.ping(), "redis": await redis_ok(),
            "websocket_connections": manager.connection_count, **_stats}


@app.get("/notifications", tags=["Notifications"])
async def list_notifications(unread_only: bool = False, limit: int = Query(50, ge=1, le=200),
                             user: CurrentUser = Depends(get_current_user)):
    q: dict = {"user_id": user.id}
    if unread_only:
        q["read"] = False
    db = get_db()
    items = await db[C.NOTIFICATIONS].find(q).sort("created_at", -1).limit(limit).to_list()
    unread = await db[C.NOTIFICATIONS].count_documents({"user_id": user.id, "read": False})
    return {"items": serialize(items), "unread": unread}


@app.post("/notifications/{notification_id}/read", tags=["Notifications"])
async def mark_read(notification_id: str, user: CurrentUser = Depends(get_current_user)):
    res = await get_db()[C.NOTIFICATIONS].update_one({"_id": oid(notification_id), "user_id": user.id},
                                                     {"$set": {"read": True, "read_at": utcnow()}})
    if res.matched_count == 0:
        raise NotFoundError("Notification not found")
    return {"read": True}


@app.post("/notifications/read-all", tags=["Notifications"])
async def mark_all(user: CurrentUser = Depends(get_current_user)):
    res = await get_db()[C.NOTIFICATIONS].update_many({"user_id": user.id, "read": False},
                                                      {"$set": {"read": True, "read_at": utcnow()}})
    return {"updated": res.modified_count}


@app.websocket("/ws")
async def websocket(ws: WebSocket, token: str = Query(...)):
    try:
        payload = decode_access_token(token)
    except UnauthorizedError:
        await ws.close(code=4401)
        return
    uid = payload["sub"]
    await manager.connect(uid, ws)
    try:
        await ws.send_text(json.dumps({"kind": "hello", "user_id": uid}))
        while True:
            msg = await ws.receive_text()
            if msg == "ping":
                await ws.send_text(json.dumps({"kind": "pong"}))
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(uid, ws)
