"""Consistent status values shared across services."""
from enum import Enum


class StrEnum(str, Enum):
    def __str__(self) -> str:  # pragma: no cover - cosmetic
        return self.value


class Role(StrEnum):
    SUPER_ADMIN = "super_admin"
    MANAGER = "manager"
    EMPLOYEE = "employee"


class EmployeeStatus(StrEnum):
    ACTIVE = "active"
    INACTIVE = "inactive"


class ScheduleStatus(StrEnum):
    DRAFT = "draft"
    PUBLISHED = "published"
    ARCHIVED = "archived"


class AssignmentStatus(StrEnum):
    ACTIVE = "active"
    ABSENT = "absent"
    REPLACED = "replaced"
    CANCELLED = "cancelled"


class AssignmentSource(StrEnum):
    OPTIMIZER = "optimizer"
    MANUAL = "manual"
    REPLACEMENT = "replacement"
    SWAP = "swap"
    SEED = "seed"


class LeaveType(StrEnum):
    ANNUAL = "annual"
    SICK = "sick"
    CASUAL = "casual"
    EMERGENCY = "emergency"
    TRAINING = "training"
    UNPAID = "unpaid"


class LeaveStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"


class SwapStatus(StrEnum):
    PENDING_PEER = "pending_peer"
    PEER_ACCEPTED = "peer_accepted"
    APPROVED = "approved"
    REJECTED = "rejected"
    DECLINED = "declined"
    CANCELLED = "cancelled"


class RunKind(StrEnum):
    GENERATE = "generate"
    SIMULATE = "simulate"


class RunStatus(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Preset(StrEnum):
    BALANCED = "balanced"
    COST = "cost"
    WELLBEING = "wellbeing"
