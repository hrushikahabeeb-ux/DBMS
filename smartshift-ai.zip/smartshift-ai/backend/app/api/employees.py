"""Employee management (CRUD, search, filter, sort, pagination, profile)."""
import re
from datetime import timedelta

from fastapi import APIRouter, Depends, Query, status

from app.api.deps import CurrentUser, get_current_user, require_manager
from app.core.errors import ForbiddenError, NotFoundError, ValidationFailed
from app.core.security import hash_password
from app.database.mongo import Collections as C
from app.database.mongo import get_db, run_transaction, serialize
from app.models.enums import EmployeeStatus
from app.schemas.models import EmployeeCreate, EmployeeOut, EmployeeUpdate, Page
from app.services.audit import audit
from app.utils.ids import oid, page_meta, parse_sort
from app.utils.timeutils import utcnow

router = APIRouter(prefix="/employees", tags=["Employees"])
SORTABLE = {"full_name", "employee_code", "job_role", "hourly_wage", "max_weekly_hours", "joining_date", "status"}
DEFAULT_PASSWORD = "Welcome@123"


def emp_out(doc: dict) -> dict:
    return serialize(doc)


def _scope_filter(user: CurrentUser) -> dict:
    scope = user.department_scope()
    if scope is None:
        return {}
    if user.is_manager:
        return {"department_ids": {"$in": scope}}
    raise ForbiddenError("Employees can only view their own profile")


async def _check_departments(user: CurrentUser, primary: str, dept_ids: list[str]) -> tuple:
    p = oid(primary, "primary_department_id")
    ids = sorted({oid(d, "department_ids") for d in dept_ids} | {p})
    if await get_db()[C.DEPARTMENTS].count_documents({"_id": {"$in": ids}}) != len(ids):
        raise ValidationFailed("One or more departments do not exist")
    for d in ids:
        user.require_department(d)
    return p, ids


@router.get("", response_model=Page[EmployeeOut], summary="List employees with search, filters, sorting and pagination")
async def list_employees(
    search: str | None = Query(None, max_length=80),
    department_id: str | None = None,
    skill: list[str] | None = Query(None),
    status_: EmployeeStatus | None = Query(None, alias="status"),
    job_role: str | None = None,
    sort: str | None = Query("full_name", description="Field, prefix '-' for descending"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    user: CurrentUser = Depends(require_manager),
):
    q: dict = _scope_filter(user)
    if search:
        rx = re.compile(re.escape(search), re.IGNORECASE)
        q["$or"] = [{"full_name": rx}, {"employee_code": rx}, {"email": rx}, {"job_role": rx}]
    if department_id:
        d = oid(department_id)
        if not user.can_manage_department(d):
            raise ForbiddenError("You are not authorized for this department")
        q["department_ids"] = d
    if skill:
        q["skills"] = {"$all": skill}
    if status_:
        q["status"] = status_.value
    if job_role:
        q["job_role"] = job_role
    db = get_db()
    total = await db[C.EMPLOYEES].count_documents(q)
    docs = await (db[C.EMPLOYEES].find(q).sort(parse_sort(sort, SORTABLE, "full_name"))
                  .skip((page - 1) * page_size).limit(page_size).to_list())
    return {"items": [emp_out(d) for d in docs], **page_meta(total, page, page_size)}


@router.get("/facets", summary="Distinct skills and roles for filters")
async def facets(user: CurrentUser = Depends(require_manager)):
    db = get_db()
    q = _scope_filter(user)
    return {"skills": sorted(await db[C.EMPLOYEES].distinct("skills", q)),
            "job_roles": sorted(await db[C.EMPLOYEES].distinct("job_role", q))}


@router.post("", status_code=status.HTTP_201_CREATED, summary="Create employee (optionally with login)")
async def create_employee(body: EmployeeCreate, user: CurrentUser = Depends(require_manager)):
    db = get_db()
    primary, dept_ids = await _check_departments(user, body.primary_department_id, body.department_ids)
    now = utcnow()
    doc = body.model_dump(exclude={"create_login", "initial_password", "primary_department_id", "department_ids"})
    doc.update({"email": body.email.lower(), "primary_department_id": primary, "department_ids": dept_ids,
                "joining_date": body.joining_date.isoformat(), "status": "active", "user_id": None, "version": 1,
                "created_at": now, "updated_at": now})
    password = body.initial_password or DEFAULT_PASSWORD

    async def txn(session):
        res = await db[C.EMPLOYEES].insert_one(doc, session=session)
        doc["_id"] = res.inserted_id
        await db[C.AVAILABILITY].insert_one(
            {"employee_id": res.inserted_id, "recurring": [{"weekday": d, "start": "07:00", "end": "23:00"} for d in range(7)],
             "unavailable_dates": [], "preferred_shifts": body.preferred_shifts, "preferred_days_off": [],
             "updated_at": now}, session=session)
        if body.create_login:
            u = await db[C.USERS].insert_one(
                {"email": doc["email"], "password_hash": hash_password(password), "full_name": body.full_name,
                 "role": "employee", "employee_id": res.inserted_id, "managed_department_ids": [], "is_active": True,
                 "created_at": now, "updated_at": now}, session=session)
            await db[C.EMPLOYEES].update_one({"_id": res.inserted_id}, {"$set": {"user_id": u.inserted_id}}, session=session)
            doc["user_id"] = u.inserted_id
        await audit(user, "employee.create", "employee", res.inserted_id, {"code": body.employee_code}, session=session)

    await run_transaction(txn)
    out = emp_out(doc)
    if body.create_login:
        out["initial_password"] = password
    return out


async def _get_scoped(employee_id: str, user: CurrentUser) -> dict:
    emp = await get_db()[C.EMPLOYEES].find_one({"_id": oid(employee_id)})
    if not emp:
        raise NotFoundError("Employee not found")
    if user.employee_id == emp["_id"]:
        return emp
    if not any(user.can_manage_department(d) for d in emp["department_ids"]):
        raise ForbiddenError("You are not authorized to view this employee")
    return emp


@router.get("/{employee_id}", response_model=EmployeeOut)
async def get_employee(employee_id: str, user: CurrentUser = Depends(get_current_user)):
    return emp_out(await _get_scoped(employee_id, user))


@router.get("/{employee_id}/profile", summary="Profile with assignments, weekly hours history and leave records")
async def profile(employee_id: str, user: CurrentUser = Depends(get_current_user)):
    emp = await _get_scoped(employee_id, user)
    db = get_db()
    now = utcnow()
    upcoming = await db[C.ASSIGNMENTS].aggregate([
        {"$match": {"employee_id": emp["_id"], "status": "active", "end": {"$gte": now - timedelta(days=1)}}},
        {"$sort": {"start": 1}}, {"$limit": 30},
        {"$lookup": {"from": C.SHIFTS, "localField": "shift_id", "foreignField": "_id", "as": "shift"}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "department",
                     "pipeline": [{"$project": {"name": 1, "code": 1}}]}},
        {"$lookup": {"from": C.SCHEDULES, "localField": "schedule_id", "foreignField": "_id", "as": "schedule",
                     "pipeline": [{"$project": {"status": 1}}]}},
        {"$unwind": "$shift"}, {"$unwind": "$department"}, {"$unwind": "$schedule"},
    ])
    hours = await db[C.ASSIGNMENTS].aggregate([
        {"$match": {"employee_id": emp["_id"], "status": "active", "start": {"$gte": now - timedelta(days=84)}}},
        {"$group": {"_id": {"$dateToString": {"format": "%G-W%V", "date": "$start", "timezone": "Asia/Kolkata"}},
                    "hours": {"$sum": "$duration_hours"}, "shifts": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
    ])
    leave = await db[C.LEAVE_REQUESTS].find({"employee_id": emp["_id"]}).sort("start_date", -1).limit(20).to_list()
    avail = await db[C.AVAILABILITY].find_one({"employee_id": emp["_id"]})
    depts = await db[C.DEPARTMENTS].find({"_id": {"$in": emp["department_ids"]}}, {"name": 1, "code": 1}).to_list()
    return {
        "employee": emp_out(emp),
        "departments": serialize(depts),
        "availability": serialize(avail),
        "assignments": serialize(await upcoming.to_list()),
        "hours_history": [{"week": h["_id"], "hours": h["hours"], "shifts": h["shifts"]} for h in await hours.to_list()],
        "leave": serialize(leave),
    }


@router.patch("/{employee_id}", response_model=EmployeeOut)
async def update_employee(employee_id: str, body: EmployeeUpdate, user: CurrentUser = Depends(require_manager)):
    emp = await _get_scoped(employee_id, user)
    changes = body.model_dump(exclude_none=True)
    if "primary_department_id" in changes or "department_ids" in changes:
        p, ids = await _check_departments(user, changes.get("primary_department_id", str(emp["primary_department_id"])),
                                          changes.get("department_ids", [str(d) for d in emp["department_ids"]]))
        changes["primary_department_id"], changes["department_ids"] = p, ids
    if "joining_date" in changes:
        changes["joining_date"] = changes["joining_date"].isoformat()
    if "email" in changes:
        changes["email"] = changes["email"].lower()
    if "status" in changes:
        changes["status"] = changes["status"].value
    changes["updated_at"] = utcnow()
    db = get_db()
    doc = await db[C.EMPLOYEES].find_one_and_update({"_id": emp["_id"]}, {"$set": changes, "$inc": {"version": 1}},
                                                    return_document=True)
    if "full_name" in changes and emp.get("user_id"):
        await db[C.USERS].update_one({"_id": emp["user_id"]}, {"$set": {"full_name": changes["full_name"]}})
    await audit(user, "employee.update", "employee", emp["_id"], {k: str(v) for k, v in changes.items()})
    return emp_out(doc)


@router.delete("/{employee_id}", summary="Deactivate employee (soft delete; future assignments are blocked)")
async def deactivate_employee(employee_id: str, user: CurrentUser = Depends(require_manager)):
    emp = await _get_scoped(employee_id, user)
    db = get_db()
    upcoming = await db[C.ASSIGNMENTS].count_documents({"employee_id": emp["_id"], "status": "active",
                                                        "start": {"$gte": utcnow()}})
    await db[C.EMPLOYEES].update_one({"_id": emp["_id"]}, {"$set": {"status": "inactive", "updated_at": utcnow()},
                                                           "$inc": {"version": 1}})
    if emp.get("user_id"):
        await db[C.USERS].update_one({"_id": emp["user_id"]}, {"$set": {"is_active": False}})
    await audit(user, "employee.deactivate", "employee", emp["_id"], {"upcoming_assignments": upcoming})
    return {"message": "Employee deactivated", "upcoming_assignments_to_review": upcoming}


@router.post("/{employee_id}/reactivate", response_model=EmployeeOut)
async def reactivate(employee_id: str, user: CurrentUser = Depends(require_manager)):
    emp = await _get_scoped(employee_id, user)
    db = get_db()
    doc = await db[C.EMPLOYEES].find_one_and_update({"_id": emp["_id"]}, {"$set": {"status": "active"},
                                                                          "$inc": {"version": 1}}, return_document=True)
    if emp.get("user_id"):
        await db[C.USERS].update_one({"_id": emp["user_id"]}, {"$set": {"is_active": True}})
    await audit(user, "employee.reactivate", "employee", emp["_id"], {})
    return emp_out(doc)
