"""User administration (super admin)."""
from fastapi import APIRouter, Depends, Query, status

from app.api.auth import user_out
from app.api.deps import CurrentUser, require_admin
from app.core.errors import NotFoundError, ValidationFailed
from app.core.security import hash_password
from app.database.mongo import Collections as C
from app.database.mongo import get_db
from app.models.enums import Role
from app.schemas.models import Page, UserCreate, UserOut, UserUpdate
from app.services.audit import audit
from app.utils.ids import oid, oid_or_none, page_meta
from app.utils.timeutils import utcnow

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("", response_model=Page[UserOut])
async def list_users(role: Role | None = None, page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=100),
                     _: CurrentUser = Depends(require_admin)):
    q = {"role": role.value} if role else {}
    db = get_db()
    total = await db[C.USERS].count_documents(q)
    docs = await db[C.USERS].find(q).sort("full_name", 1).skip((page - 1) * page_size).limit(page_size).to_list()
    return {"items": [user_out(d) for d in docs], **page_meta(total, page, page_size)}


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def create_user(body: UserCreate, actor: CurrentUser = Depends(require_admin)):
    db = get_db()
    dept_ids = [oid(d, "department_id") for d in body.managed_department_ids]
    if body.role == Role.MANAGER and not dept_ids:
        raise ValidationFailed("Managers must be assigned at least one department")
    if dept_ids and await db[C.DEPARTMENTS].count_documents({"_id": {"$in": dept_ids}}) != len(dept_ids):
        raise ValidationFailed("One or more departments do not exist")
    now = utcnow()
    doc = {"email": body.email.lower(), "password_hash": hash_password(body.password), "full_name": body.full_name,
           "role": body.role.value, "employee_id": oid_or_none(body.employee_id), "managed_department_ids": dept_ids,
           "is_active": True, "created_at": now, "updated_at": now}
    res = await db[C.USERS].insert_one(doc)
    doc["_id"] = res.inserted_id
    if body.role == Role.MANAGER:
        await db[C.DEPARTMENTS].update_many({"_id": {"$in": dept_ids}, "manager_user_id": None},
                                            {"$set": {"manager_user_id": res.inserted_id}})
    await audit(actor, "user.create", "user", res.inserted_id, {"role": body.role.value})
    return user_out(doc)


@router.patch("/{user_id}", response_model=UserOut)
async def update_user(user_id: str, body: UserUpdate, actor: CurrentUser = Depends(require_admin)):
    db = get_db()
    changes = body.model_dump(exclude_none=True)
    if "password" in changes:
        changes["password_hash"] = hash_password(changes.pop("password"))
    if "managed_department_ids" in changes:
        changes["managed_department_ids"] = [oid(d) for d in changes["managed_department_ids"]]
    if "role" in changes:
        changes["role"] = changes["role"].value
    if oid(user_id) == actor.id and changes.get("is_active") is False:
        raise ValidationFailed("You cannot deactivate your own account")
    changes["updated_at"] = utcnow()
    doc = await db[C.USERS].find_one_and_update({"_id": oid(user_id)}, {"$set": changes}, return_document=True)
    if not doc:
        raise NotFoundError("User not found")
    await audit(actor, "user.update", "user", user_id, {k: v for k, v in changes.items() if k != "password_hash"})
    return user_out(doc)
