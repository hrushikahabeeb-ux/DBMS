"""Authentication endpoints."""
from fastapi import APIRouter, Depends, status
from fastapi.security import OAuth2PasswordRequestForm

from app.api.deps import CurrentUser, get_current_user
from app.core.errors import ConflictError, UnauthorizedError
from app.core.security import create_access_token, hash_password, verify_password
from app.database.mongo import Collections as C
from app.database.mongo import get_db
from app.schemas.models import LoginRequest, RegisterRequest, TokenResponse, UserOut
from app.services.audit import audit
from app.utils.timeutils import utcnow

router = APIRouter(prefix="/auth", tags=["Authentication"])


def user_out(u: dict) -> UserOut:
    return UserOut(id=str(u["_id"]), email=u["email"], full_name=u["full_name"], role=u["role"],
                   employee_id=str(u["employee_id"]) if u.get("employee_id") else None,
                   managed_department_ids=[str(d) for d in u.get("managed_department_ids", [])],
                   is_active=u.get("is_active", True))


async def _login(email: str, password: str) -> TokenResponse:
    db = get_db()
    user = await db[C.USERS].find_one({"email": email.lower()})
    if not user or not verify_password(password, user["password_hash"]):
        raise UnauthorizedError("Incorrect email or password")
    if not user.get("is_active", True):
        raise UnauthorizedError("This account is disabled")
    await db[C.USERS].update_one({"_id": user["_id"]}, {"$set": {"last_login_at": utcnow()}})
    token = create_access_token(str(user["_id"]), user["role"])
    return TokenResponse(access_token=token, user=user_out(user))


@router.post("/login", response_model=TokenResponse, summary="Sign in with email and password")
async def login(body: LoginRequest):
    return await _login(body.email, body.password)


@router.post("/token", response_model=TokenResponse, include_in_schema=True, summary="OAuth2 password flow (Swagger)")
async def token(form: OAuth2PasswordRequestForm = Depends()):
    return await _login(form.username, form.password)


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED,
             summary="Activate an employee account (email must match an employee record)")
async def register(body: RegisterRequest):
    db = get_db()
    email = body.email.lower()
    employee = await db[C.EMPLOYEES].find_one({"email": email, "status": "active"})
    if not employee:
        raise ConflictError("No active employee record uses this email. Ask your manager to add you first.")
    if employee.get("user_id") or await db[C.USERS].find_one({"email": email}):
        raise ConflictError("An account already exists for this email")
    now = utcnow()
    doc = {"email": email, "password_hash": hash_password(body.password), "full_name": body.full_name,
           "role": "employee", "employee_id": employee["_id"], "managed_department_ids": [], "is_active": True,
           "created_at": now, "updated_at": now}
    res = await db[C.USERS].insert_one(doc)
    await db[C.EMPLOYEES].update_one({"_id": employee["_id"]}, {"$set": {"user_id": res.inserted_id}})
    doc["_id"] = res.inserted_id
    await audit(None, "user.register", "user", res.inserted_id, {"email": email})
    return TokenResponse(access_token=create_access_token(str(res.inserted_id), "employee"), user=user_out(doc))


@router.get("/me", response_model=UserOut, summary="Current user")
async def me(user: CurrentUser = Depends(get_current_user)):
    doc = await get_db()[C.USERS].find_one({"_id": user.id})
    return user_out(doc)
