"""Department management."""
from fastapi import APIRouter, Depends, status

from app.api.deps import CurrentUser, get_current_user, require_admin, require_manager
from app.core.errors import ConflictError, NotFoundError
from app.database.mongo import Collections as C
from app.database.mongo import get_db, serialize
from app.schemas.models import DepartmentCreate, DepartmentUpdate
from app.services.audit import audit
from app.utils.ids import oid, oid_or_none
from app.utils.timeutils import utcnow

router = APIRouter(prefix="/departments", tags=["Departments"])


@router.get("", summary="List departments with staffing counts")
async def list_departments(include_inactive: bool = False, user: CurrentUser = Depends(get_current_user)):
    match: dict = {} if include_inactive else {"is_active": True}
    if not user.is_admin:
        if user.is_manager:
            match["_id"] = {"$in": user.managed_department_ids}
        else:
            emp = await get_db()[C.EMPLOYEES].find_one({"_id": user.employee_id}, {"department_ids": 1})
            match["_id"] = {"$in": (emp or {}).get("department_ids", [])}
    pipeline = [
        {"$match": match},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "_id", "foreignField": "department_ids", "as": "staff",
                     "pipeline": [{"$match": {"status": "active"}}, {"$project": {"_id": 1}}]}},
        {"$lookup": {"from": C.USERS, "localField": "manager_user_id", "foreignField": "_id", "as": "manager",
                     "pipeline": [{"$project": {"full_name": 1, "email": 1}}]}},
        {"$addFields": {"employee_count": {"$size": "$staff"}, "manager": {"$first": "$manager"},
                        "daily_required_staff": {"$sum": "$shift_configurations.required_staff"}}},
        {"$project": {"staff": 0}},
        {"$sort": {"name": 1}},
    ]
    return serialize(await (await get_db()[C.DEPARTMENTS].aggregate(pipeline)).to_list())


@router.get("/{department_id}")
async def get_department(department_id: str, user: CurrentUser = Depends(get_current_user)):
    d = await get_db()[C.DEPARTMENTS].find_one({"_id": oid(department_id)})
    if not d:
        raise NotFoundError("Department not found")
    return serialize(d)


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_department(body: DepartmentCreate, user: CurrentUser = Depends(require_admin)):
    now = utcnow()
    doc = body.model_dump()
    doc.update({"manager_user_id": oid_or_none(body.manager_user_id), "is_active": True, "created_at": now,
                "updated_at": now})
    res = await get_db()[C.DEPARTMENTS].insert_one(doc)
    doc["_id"] = res.inserted_id
    if doc["manager_user_id"]:
        await get_db()[C.USERS].update_one({"_id": doc["manager_user_id"]},
                                           {"$addToSet": {"managed_department_ids": res.inserted_id}})
    await audit(user, "department.create", "department", res.inserted_id, {"code": body.code})
    return serialize(doc)


@router.patch("/{department_id}")
async def update_department(department_id: str, body: DepartmentUpdate, user: CurrentUser = Depends(require_manager)):
    did = oid(department_id)
    user.require_department(did)
    changes = body.model_dump(exclude_none=True)
    if "manager_user_id" in changes:
        if not user.is_admin:
            changes.pop("manager_user_id")
        else:
            changes["manager_user_id"] = oid_or_none(changes["manager_user_id"])
            if changes["manager_user_id"]:
                await get_db()[C.USERS].update_one({"_id": changes["manager_user_id"]},
                                                   {"$addToSet": {"managed_department_ids": did}})
    if "is_active" in changes and not user.is_admin:
        changes.pop("is_active")
    changes["updated_at"] = utcnow()
    doc = await get_db()[C.DEPARTMENTS].find_one_and_update({"_id": did}, {"$set": changes}, return_document=True)
    if not doc:
        raise NotFoundError("Department not found")
    await audit(user, "department.update", "department", did, {"fields": sorted(changes)})
    return serialize(doc)


@router.delete("/{department_id}", summary="Archive a department (only when it has no upcoming schedules)")
async def delete_department(department_id: str, user: CurrentUser = Depends(require_admin)):
    did = oid(department_id)
    db = get_db()
    if await db[C.SCHEDULES].count_documents({"department_id": did, "status": {"$in": ["draft", "published"]},
                                               "end_date": {"$gte": utcnow().date().isoformat()}}):
        raise ConflictError("Department has current or upcoming schedules; archive them first")
    res = await db[C.DEPARTMENTS].update_one({"_id": did}, {"$set": {"is_active": False, "updated_at": utcnow()}})
    if res.matched_count == 0:
        raise NotFoundError("Department not found")
    await audit(user, "department.archive", "department", did, {})
    return {"message": "Department archived"}
