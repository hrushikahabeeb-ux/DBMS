"""Assignments: manual assignment, drag-and-drop moves, validation, explanations
and emergency replacement."""
from fastapi import APIRouter, Depends, status

from app.api.deps import CurrentUser, require_manager
from app.core.errors import NotFoundError
from app.database.mongo import Collections as C
from app.database.mongo import get_db, serialize
from app.schemas.models import (
    AbsenceRequest,
    AssignmentCreate,
    AssignmentMove,
    AssignmentPatch,
    AssignmentValidate,
    ReplacementRequest,
)
from app.services import assignment_service as svc
from app.services.audit import audit
from app.utils.ids import oid, oid_or_none
from app.utils.timeutils import utcnow

router = APIRouter(tags=["Assignments"])


async def _assignment(assignment_id: str, user: CurrentUser) -> dict:
    a = await get_db()[C.ASSIGNMENTS].find_one({"_id": oid(assignment_id)})
    if not a:
        raise NotFoundError("Assignment not found")
    user.require_department(a["department_id"])
    return a


@router.post("/assignments/validate", summary="Check an employee/shift pair against every hard constraint")
async def validate(body: AssignmentValidate, user: CurrentUser = Depends(require_manager)):
    shift = await get_db()[C.SHIFTS].find_one({"_id": oid(body.shift_id)})
    if not shift:
        raise NotFoundError("Shift not found")
    user.require_department(shift["department_id"])
    excl = [oid_or_none(body.exclude_assignment_id)] if body.exclude_assignment_id else None
    return await svc.validate_pair(oid(body.employee_id), shift, exclude=excl)


@router.get("/shifts/{shift_id}/candidates", summary="Every department employee with validation results for a shift")
async def shift_candidates(shift_id: str, user: CurrentUser = Depends(require_manager)):
    db = get_db()
    shift = await db[C.SHIFTS].find_one({"_id": oid(shift_id)})
    if not shift:
        raise NotFoundError("Shift not found")
    user.require_department(shift["department_id"])
    assigned = set(await db[C.ASSIGNMENTS].distinct("employee_id", {"shift_id": shift["_id"], "status": "active"}))
    fake = {"employee_id": None, "shift_id": shift["_id"], "department_id": shift["department_id"]}
    data = await svc.replacement_candidates(fake)
    data["candidates"] = [c for c in data["candidates"] if oid(c["employee_id"]) not in assigned]
    data["rejected"] = [r for r in data["rejected"] if oid(r["employee_id"]) not in assigned]
    return data


@router.post("/assignments", status_code=status.HTTP_201_CREATED, summary="Manually assign (validated, transactional)")
async def create(body: AssignmentCreate, user: CurrentUser = Depends(require_manager)):
    shift = await get_db()[C.SHIFTS].find_one({"_id": oid(body.shift_id)})
    if not shift:
        raise NotFoundError("Shift not found")
    user.require_department(shift["department_id"])
    return serialize(await svc.create_assignment(user, shift["_id"], oid(body.employee_id), body.locked))


@router.patch("/assignments/{assignment_id}/move", summary="Move an assignment to another shift (drag and drop)")
async def move(assignment_id: str, body: AssignmentMove, user: CurrentUser = Depends(require_manager)):
    a = await _assignment(assignment_id, user)
    return serialize(await svc.move_assignment(user, a["_id"], oid(body.target_shift_id)))


@router.patch("/assignments/{assignment_id}", summary="Lock or unlock an assignment")
async def patch(assignment_id: str, body: AssignmentPatch, user: CurrentUser = Depends(require_manager)):
    a = await _assignment(assignment_id, user)
    doc = await get_db()[C.ASSIGNMENTS].find_one_and_update(
        {"_id": a["_id"]}, {"$set": {"locked": body.locked, "updated_at": utcnow()}}, return_document=True)
    await audit(user, "assignment.lock" if body.locked else "assignment.unlock", "assignment", a["_id"], {})
    return serialize(doc)


@router.delete("/assignments/{assignment_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(assignment_id: str, user: CurrentUser = Depends(require_manager)):
    a = await _assignment(assignment_id, user)
    await svc.cancel_assignment(user, a["_id"])


@router.get("/assignments/{assignment_id}/explain", summary="Why was this employee assigned?")
async def explain(assignment_id: str, user: CurrentUser = Depends(require_manager)):
    a = await _assignment(assignment_id, user)
    return await svc.explain_assignment(a["_id"])


@router.post("/assignments/{assignment_id}/absence", summary="Mark absent and get ranked replacement candidates")
async def absence(assignment_id: str, body: AbsenceRequest, user: CurrentUser = Depends(require_manager)):
    a = await _assignment(assignment_id, user)
    return await svc.mark_absent(user, a["_id"], body.reason)


@router.get("/assignments/{assignment_id}/replacements", summary="Ranked replacement candidates for an absence")
async def replacements(assignment_id: str, user: CurrentUser = Depends(require_manager)):
    a = await _assignment(assignment_id, user)
    return await svc.replacement_candidates(a)


@router.post("/assignments/{assignment_id}/replace", summary="Approve a replacement (re-validated in a transaction)")
async def replace(assignment_id: str, body: ReplacementRequest, user: CurrentUser = Depends(require_manager)):
    a = await _assignment(assignment_id, user)
    return serialize(await svc.approve_replacement(user, a["_id"], oid(body.employee_id)))


@router.get("/emergency/vacancies", summary="Open absences that still need cover")
async def vacancies(user: CurrentUser = Depends(require_manager)):
    return await svc.open_vacancies(user.department_scope())
