"""Schedules, shifts, calendar feed, optimization runs and publishing."""
from datetime import date, datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query, status

from app.api.deps import CurrentUser, get_current_user, require_manager
from app.core.errors import ForbiddenError, NotFoundError, ValidationFailed
from app.database.mongo import Collections as C
from app.database.mongo import get_db, serialize
from app.models.enums import RunKind
from app.optimization.presets import PRESET_LABELS
from app.schemas.models import ApplyRunRequest, GenerateRequest, RequirementUpdate, ScenarioIn, ScheduleCreate
from app.services import assignment_service, schedule_service
from app.utils.ids import oid, page_meta

router = APIRouter(tags=["Schedules"])


async def _schedule(schedule_id: str, user: CurrentUser, manage: bool = True) -> dict:
    s = await get_db()[C.SCHEDULES].find_one({"_id": oid(schedule_id)})
    if not s:
        raise NotFoundError("Schedule not found")
    if manage:
        user.require_department(s["department_id"])
    return s


@router.get("/schedules", summary="List schedules")
async def list_schedules(department_id: str | None = None, status_: str | None = Query(None, alias="status"),
                         page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
                         user: CurrentUser = Depends(require_manager)):
    q: dict = {}
    scope = user.department_scope()
    if scope is not None:
        q["department_id"] = {"$in": scope}
    if department_id:
        d = oid(department_id)
        user.require_department(d)
        q["department_id"] = d
    if status_:
        q["status"] = status_
    db = get_db()
    total = await db[C.SCHEDULES].count_documents(q)
    pipeline = [
        {"$match": q}, {"$sort": {"start_date": -1}}, {"$skip": (page - 1) * page_size}, {"$limit": page_size},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "department",
                     "pipeline": [{"$project": {"name": 1, "code": 1}}]}},
        {"$lookup": {"from": C.SHIFTS, "localField": "_id", "foreignField": "schedule_id", "as": "shifts",
                     "pipeline": [{"$project": {"required_staff": 1, "assigned_count": 1}}]}},
        {"$addFields": {"department": {"$first": "$department"},
                        "required_slots": {"$sum": "$shifts.required_staff"},
                        "filled_slots": {"$sum": {"$map": {"input": "$shifts", "as": "s",
                                                           "in": {"$min": ["$$s.assigned_count", "$$s.required_staff"]}}}},
                        "shift_count": {"$size": "$shifts"}}},
        {"$project": {"shifts": 0}},
    ]
    items = await (await db[C.SCHEDULES].aggregate(pipeline)).to_list()
    return {"items": serialize(items), **page_meta(total, page, page_size)}


@router.post("/schedules", status_code=status.HTTP_201_CREATED, summary="Create a draft schedule period and its shifts")
async def create_schedule(body: ScheduleCreate, user: CurrentUser = Depends(require_manager)):
    did = oid(body.department_id)
    user.require_department(did)
    s = await schedule_service.create_schedule(user, did, body.start_date, body.days, body.requirement_overrides)
    return serialize(s)


@router.get("/schedules/{schedule_id}", summary="Schedule with shifts and assignments")
async def get_schedule(schedule_id: str, user: CurrentUser = Depends(require_manager)):
    s = await _schedule(schedule_id, user)
    db = get_db()
    shifts = await db[C.SHIFTS].find({"schedule_id": s["_id"]}).sort("start", 1).to_list()
    assigns = await (await db[C.ASSIGNMENTS].aggregate([
        {"$match": {"schedule_id": s["_id"], "status": {"$in": ["active", "absent"]}}},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id", "as": "employee",
                     "pipeline": [{"$project": {"full_name": 1, "employee_code": 1, "job_role": 1, "skills": 1}}]}},
        {"$addFields": {"employee": {"$first": "$employee"}}},
    ])).to_list()
    dept = await db[C.DEPARTMENTS].find_one({"_id": s["department_id"]})
    return {"schedule": serialize(s), "department": serialize(dept), "shifts": serialize(shifts),
            "assignments": serialize(assigns)}


@router.patch("/schedules/{schedule_id}/requirements", summary="Adjust staffing requirements per shift type")
async def update_requirements(schedule_id: str, body: RequirementUpdate, user: CurrentUser = Depends(require_manager)):
    s = await _schedule(schedule_id, user)
    changed = await schedule_service.update_requirements(user, s, body.requirement_overrides)
    return {"updated_shifts": changed}


@router.post("/schedules/{schedule_id}/generate", status_code=status.HTTP_202_ACCEPTED,
             summary="Queue CP-SAT schedule generation (returns a job id)")
async def generate(schedule_id: str, body: GenerateRequest, user: CurrentUser = Depends(require_manager)):
    s = await _schedule(schedule_id, user)
    run = await schedule_service.enqueue_run(user, s, RunKind.GENERATE, [p.value for p in body.presets])
    return {"job_id": str(run["_id"]), "status": run["status"]}


@router.post("/schedules/{schedule_id}/simulate", status_code=status.HTTP_202_ACCEPTED,
             summary="Queue a what-if simulation (never modifies the schedule)")
async def simulate(schedule_id: str, body: ScenarioIn, user: CurrentUser = Depends(require_manager)):
    s = await _schedule(schedule_id, user)
    scenario = body.model_dump(exclude={"preset"}, mode="json")
    if not any([scenario["absent_employee_ids"], scenario["absent_count"], scenario["demand_increase_pct"],
                scenario["workforce_reduction_pct"], scenario["extra_skill"], scenario["max_weekly_hours"]]):
        raise ValidationFailed("Describe at least one hypothetical change")
    run = await schedule_service.enqueue_run(user, s, RunKind.SIMULATE, [body.preset.value], scenario)
    return {"job_id": str(run["_id"]), "status": run["status"]}


@router.get("/schedules/{schedule_id}/runs", summary="Optimization history for a schedule")
async def list_runs(schedule_id: str, user: CurrentUser = Depends(require_manager)):
    s = await _schedule(schedule_id, user)
    runs = await get_db()[C.OPTIMIZATION_RUNS].find(
        {"schedule_id": s["_id"]}, {"result.variants.assignments": 0, "result.baselines": 0}
    ).sort("created_at", -1).limit(20).to_list()
    return serialize(runs)


@router.get("/runs/{run_id}", summary="Job status and results")
async def get_run(run_id: str, user: CurrentUser = Depends(require_manager)):
    run = await get_db()[C.OPTIMIZATION_RUNS].find_one({"_id": oid(run_id)})
    if not run:
        raise NotFoundError("Run not found")
    user.require_department(run["department_id"])
    out = serialize(run)
    out["preset_labels"] = PRESET_LABELS
    return out


@router.post("/runs/{run_id}/apply", summary="Apply a run variant to the draft schedule (transactional)")
async def apply_run(run_id: str, body: ApplyRunRequest, user: CurrentUser = Depends(require_manager)):
    return await schedule_service.apply_run(user, oid(run_id), body.variant)


@router.post("/schedules/{schedule_id}/publish")
async def publish(schedule_id: str, user: CurrentUser = Depends(require_manager)):
    s = await _schedule(schedule_id, user)
    return serialize(await schedule_service.publish(user, s["_id"]))


@router.post("/schedules/{schedule_id}/unpublish")
async def unpublish(schedule_id: str, user: CurrentUser = Depends(require_manager)):
    s = await _schedule(schedule_id, user)
    return serialize(await schedule_service.unpublish(user, s["_id"]))


@router.delete("/schedules/{schedule_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_schedule(schedule_id: str, user: CurrentUser = Depends(require_manager)):
    await schedule_service.delete_schedule(user, oid(schedule_id))


@router.get("/schedules/{schedule_id}/conflicts", summary="Run the conflict detection engine")
async def conflicts(schedule_id: str, user: CurrentUser = Depends(require_manager)):
    s = await _schedule(schedule_id, user)
    items = await assignment_service.schedule_conflicts(s)
    summary: dict[str, int] = {}
    for c in items:
        summary[c["type"]] = summary.get(c["type"], 0) + 1
    return {"conflicts": items, "summary": summary, "total": len(items)}


@router.get("/calendar", summary="Calendar feed of shifts and assignments (role-aware)")
async def calendar(start: date, end: date, department_id: str | None = None, employee_id: str | None = None,
                   user: CurrentUser = Depends(get_current_user)):
    if (end - start).days > 62:
        raise ValidationFailed("Calendar range is limited to 62 days")
    db = get_db()
    t0 = datetime(start.year, start.month, start.day, tzinfo=timezone.utc) - timedelta(days=1)
    t1 = datetime(end.year, end.month, end.day, tzinfo=timezone.utc) + timedelta(days=1)
    if user.role.value == "employee":
        if not user.employee_id:
            raise ForbiddenError("No employee profile linked to this account")
        published = await db[C.SCHEDULES].distinct("_id", {"status": "published"})
        assigns = await (await db[C.ASSIGNMENTS].aggregate([
            {"$match": {"employee_id": user.employee_id, "status": {"$in": ["active", "absent"]},
                        "schedule_id": {"$in": published}, "start": {"$gte": t0, "$lt": t1}}},
            {"$lookup": {"from": C.SHIFTS, "localField": "shift_id", "foreignField": "_id", "as": "shift"}},
            {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id",
                         "as": "department", "pipeline": [{"$project": {"name": 1, "code": 1, "color": 1}}]}},
            {"$addFields": {"shift": {"$first": "$shift"}, "department": {"$first": "$department"}}},
        ])).to_list()
        return {"mode": "employee", "shifts": [], "assignments": serialize(assigns)}

    q: dict = {"start": {"$gte": t0, "$lt": t1}}
    scope = user.department_scope()
    if scope is not None:
        q["department_id"] = {"$in": scope}
    if department_id:
        d = oid(department_id)
        user.require_department(d)
        q["department_id"] = d
    shifts = await (await db[C.SHIFTS].aggregate([
        {"$match": q}, {"$sort": {"start": 1}},
        {"$lookup": {"from": C.SCHEDULES, "localField": "schedule_id", "foreignField": "_id", "as": "schedule",
                     "pipeline": [{"$project": {"status": 1, "version": 1}}]}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "department",
                     "pipeline": [{"$project": {"name": 1, "code": 1, "color": 1}}]}},
        {"$addFields": {"schedule": {"$first": "$schedule"}, "department": {"$first": "$department"}}},
    ])).to_list()
    aq: dict = {"shift_id": {"$in": [s["_id"] for s in shifts]}, "status": {"$in": ["active", "absent"]}}
    if employee_id:
        aq["employee_id"] = oid(employee_id)
    assigns = await (await db[C.ASSIGNMENTS].aggregate([
        {"$match": aq},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id", "as": "employee",
                     "pipeline": [{"$project": {"full_name": 1, "employee_code": 1, "job_role": 1}}]}},
        {"$addFields": {"employee": {"$first": "$employee"}}},
    ])).to_list()
    return {"mode": "manager", "shifts": serialize(shifts), "assignments": serialize(assigns)}
