"""Rules configuration, audit logs, system health, analytics gateway and demo tools."""
import asyncio
import re

from fastapi import APIRouter, Depends, Query, Request

from app.api.deps import CurrentUser, get_current_user, require_admin, require_manager
from app.core.config import get_settings
from app.core.service_client import ServiceClient, analytics_client
from app.database.mongo import Collections as C
from app.database.mongo import Mongo, get_db, serialize
from app.optimization.presets import DEFAULT_WEIGHTS, PRESET_LABELS
from app.schemas.models import RulesUpdate
from app.services.audit import audit
from app.services.events import JOBS_QUEUE, get_redis, redis_ok
from app.utils.ids import page_meta
from app.utils.timeutils import utcnow

router = APIRouter(tags=["Administration"])


@router.get("/rules", summary="Organization scheduling rules and optimization weights")
async def get_rules(_: CurrentUser = Depends(get_current_user)):
    from app.services.scheduling_data import get_rules_doc
    doc = await get_rules_doc()
    return {**serialize(doc), "preset_labels": PRESET_LABELS, "default_weights": DEFAULT_WEIGHTS}


@router.put("/rules", summary="Update scheduling rules (super admin)")
async def put_rules(body: RulesUpdate, user: CurrentUser = Depends(require_admin)):
    changes = body.model_dump(exclude_none=True)
    if "weights" in changes:
        merged = {k: {**DEFAULT_WEIGHTS[k], **changes["weights"].get(k, {})} for k in DEFAULT_WEIGHTS}
        changes["weights"] = merged
    changes.update({"updated_at": utcnow(), "updated_by": user.id})
    doc = await get_db()[C.SCHEDULING_RULES].find_one_and_update({"scope": "organization"}, {"$set": changes},
                                                                 return_document=True, upsert=True)
    await audit(user, "rules.update", "scheduling_rules", doc["_id"], {"fields": sorted(changes)})
    return serialize(doc)


@router.get("/audit-logs", summary="Audit trail with filters and pagination")
async def audit_logs(action: str | None = None, entity_type: str | None = None, actor: str | None = None,
                     page: int = Query(1, ge=1), page_size: int = Query(30, ge=1, le=200),
                     user: CurrentUser = Depends(require_manager)):
    q: dict = {}
    if not user.is_admin:
        q["actor_user_id"] = user.id
    if action:
        q["action"] = {"$regex": f"^{re.escape(action)}"}
    if entity_type:
        q["entity_type"] = entity_type
    if actor:
        q["actor_email"] = {"$regex": re.escape(actor), "$options": "i"}
    db = get_db()
    total = await db[C.AUDIT_LOGS].count_documents(q)
    items = await db[C.AUDIT_LOGS].find(q).sort("created_at", -1).skip((page - 1) * page_size).limit(page_size).to_list()
    return {"items": serialize(items), **page_meta(total, page, page_size)}


@router.get("/system/health", summary="Health of every service (main API view)")
async def system_health(_: CurrentUser = Depends(get_current_user)):
    s = get_settings()

    async def probe(name: str, url: str):
        try:
            data = await ServiceClient(name, url, timeout=3, max_retries=1).get("/health")
            return name, {"status": data.get("status", "ok"), **data}
        except Exception as exc:  # noqa: BLE001
            return name, {"status": "down", "error": getattr(exc, "message", str(exc))}

    results = dict(await asyncio.gather(probe("optimizer", s.optimizer_url), probe("notification", s.notification_url),
                                        probe("analytics", s.analytics_url)))
    queue_depth = None
    if await redis_ok():
        queue_depth = await get_redis().llen(JOBS_QUEUE)
    results["api"] = {"status": "ok", "mongodb": await Mongo.ping(), "redis": await redis_ok(), "queue_depth": queue_depth}
    from app.services.events import get_redis as _r
    try:
        worker_beat = await _r().get("smartshift:worker:heartbeat")
    except Exception:  # noqa: BLE001
        worker_beat = None
    results["worker"] = {"status": "ok" if worker_beat else "down", "last_heartbeat": worker_beat}
    return results


@router.api_route("/analytics/{path:path}", methods=["GET"], summary="Gateway to the analytics service")
async def analytics_gateway(path: str, request: Request, user: CurrentUser = Depends(require_manager)):
    scope = user.department_scope()
    headers = {"X-User-Id": str(user.id), "X-User-Role": user.role.value,
               "X-User-Scope": "*" if scope is None else ",".join(str(d) for d in scope)}
    return await analytics_client().get(f"/analytics/{path}", params=dict(request.query_params), headers=headers)


@router.post("/demo/reset", summary="Re-seed the expo demo dataset (super admin)")
async def demo_reset(user: CurrentUser = Depends(require_admin)):
    from scripts.seed import seed
    summary = await seed(get_db(), reset=True)
    await audit(user, "demo.reset", "system", None, summary)
    return summary
