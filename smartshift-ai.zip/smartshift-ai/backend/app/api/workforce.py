"""Availability, leave, shift swaps and employee self-service."""
from datetime import timedelta

from fastapi import APIRouter, Depends, Query, status

from app.api.deps import CurrentUser, get_current_user, require_manager
from app.core.errors import ConflictError, ForbiddenError, NotFoundError
from app.database.mongo import Collections as C
from app.database.mongo import get_db, serialize
from app.schemas.models import AvailabilityIn, Decision, LeaveCreate, SwapCreate, SwapResponse
from app.services import workflow_service as wf
from app.services.audit import audit
from app.utils.ids import oid, oid_or_none, page_meta
from app.utils.timeutils import utcnow

router = APIRouter(tags=["Workforce"])


async def _my_employee(user: CurrentUser) -> dict:
    if not user.employee_id:
        raise ForbiddenError("This account is not linked to an employee profile")
    emp = await get_db()[C.EMPLOYEES].find_one({"_id": user.employee_id})
    if not emp:
        raise NotFoundError("Employee profile not found")
    return emp


async def _employee_for(user: CurrentUser, employee_id: str | None) -> dict:
    if employee_id is None or (user.employee_id and oid(employee_id) == user.employee_id):
        return await _my_employee(user)
    emp = await get_db()[C.EMPLOYEES].find_one({"_id": oid(employee_id)})
    if not emp:
        raise NotFoundError("Employee not found")
    if not any(user.can_manage_department(d) for d in emp["department_ids"]):
        raise ForbiddenError("You are not authorized for this employee")
    return emp


# ---------------------------------------------------------------- availability
@router.get("/availability", summary="Availability for one employee (default: yourself)")
async def get_availability(employee_id: str | None = None, user: CurrentUser = Depends(get_current_user)):
    emp = await _employee_for(user, employee_id)
    doc = await get_db()[C.AVAILABILITY].find_one({"employee_id": emp["_id"]})
    return serialize(doc or {"employee_id": emp["_id"], "recurring": [], "unavailable_dates": [], "preferred_shifts": [],
                             "preferred_days_off": []})


@router.put("/availability", summary="Submit availability and preferences")
async def put_availability(body: AvailabilityIn, employee_id: str | None = None,
                           user: CurrentUser = Depends(get_current_user)):
    emp = await _employee_for(user, employee_id)
    doc = body.model_dump(mode="json")
    doc.update({"employee_id": emp["_id"], "updated_at": utcnow(), "updated_by": user.id})
    db = get_db()
    await db[C.AVAILABILITY].replace_one({"employee_id": emp["_id"]}, doc, upsert=True)
    await db[C.EMPLOYEES].update_one({"_id": emp["_id"]}, {"$set": {"preferred_shifts": body.preferred_shifts},
                                                           "$inc": {"version": 1}})
    await audit(user, "availability.update", "employee", emp["_id"], {"windows": len(body.recurring)})
    return serialize(doc)


@router.get("/availability/team", summary="Team availability grid for a department and date range")
async def team_availability(department_id: str, days: int = Query(7, ge=1, le=31), start: str | None = None,
                            user: CurrentUser = Depends(require_manager)):
    from datetime import date
    did = oid(department_id)
    user.require_department(did)
    first = date.fromisoformat(start) if start else utcnow().date()
    last = first + timedelta(days=days - 1)
    db = get_db()
    pipeline = [
        {"$match": {"department_ids": did, "status": "active"}},
        {"$sort": {"full_name": 1}},
        {"$lookup": {"from": C.AVAILABILITY, "localField": "_id", "foreignField": "employee_id", "as": "availability"}},
        {"$lookup": {"from": C.LEAVE_REQUESTS, "localField": "_id", "foreignField": "employee_id", "as": "leave",
                     "pipeline": [{"$match": {"status": "approved", "start_date": {"$lte": last.isoformat()},
                                              "end_date": {"$gte": first.isoformat()}}},
                                  {"$project": {"start_date": 1, "end_date": 1, "leave_type": 1}}]}},
        {"$project": {"full_name": 1, "employee_code": 1, "job_role": 1, "availability": {"$first": "$availability"},
                      "leave": 1}},
    ]
    rows = await (await db[C.EMPLOYEES].aggregate(pipeline)).to_list()
    return {"start": first.isoformat(), "days": days, "employees": serialize(rows)}


# ---------------------------------------------------------------- leave
@router.get("/leave", summary="Leave requests (employees see their own)")
async def list_leave(status_: str | None = Query(None, alias="status"), department_id: str | None = None,
                     page: int = Query(1, ge=1), page_size: int = Query(25, ge=1, le=100),
                     user: CurrentUser = Depends(get_current_user)):
    q: dict = {}
    if user.role.value == "employee":
        q["employee_id"] = user.employee_id
    else:
        scope = user.department_scope()
        if scope is not None:
            q["department_id"] = {"$in": scope}
        if department_id:
            q["department_id"] = oid(department_id)
    if status_:
        q["status"] = status_
    db = get_db()
    total = await db[C.LEAVE_REQUESTS].count_documents(q)
    items = await (await db[C.LEAVE_REQUESTS].aggregate([
        {"$match": q}, {"$sort": {"created_at": -1}}, {"$skip": (page - 1) * page_size}, {"$limit": page_size},
        {"$lookup": {"from": C.EMPLOYEES, "localField": "employee_id", "foreignField": "_id", "as": "employee",
                     "pipeline": [{"$project": {"full_name": 1, "employee_code": 1, "job_role": 1}}]}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "department",
                     "pipeline": [{"$project": {"name": 1}}]}},
        {"$addFields": {"employee": {"$first": "$employee"}, "department": {"$first": "$department"}}},
    ])).to_list()
    return {"items": serialize(items), **page_meta(total, page, page_size)}


@router.post("/leave", status_code=status.HTTP_201_CREATED, summary="Request leave")
async def create_leave(body: LeaveCreate, user: CurrentUser = Depends(get_current_user)):
    emp = await _my_employee(user)
    return serialize(await wf.request_leave(user, emp, body.leave_type.value, body.start_date, body.end_date, body.reason))


@router.get("/leave/{leave_id}/impact", summary="Published assignments that approving this leave would affect")
async def leave_impact(leave_id: str, user: CurrentUser = Depends(require_manager)):
    leave = await get_db()[C.LEAVE_REQUESTS].find_one({"_id": oid(leave_id)})
    if not leave:
        raise NotFoundError("Leave request not found")
    user.require_department(leave["department_id"])
    affected = await wf.leave_conflicts(leave)
    return {"affected_assignments": serialize(affected), "count": len(affected)}


@router.post("/leave/{leave_id}/decision", summary="Approve or reject leave (approval opens replacement planning)")
async def decide_leave(leave_id: str, body: Decision, user: CurrentUser = Depends(require_manager)):
    return await wf.decide_leave(user, oid(leave_id), body.approve, body.note)


@router.post("/leave/{leave_id}/cancel", summary="Cancel your pending leave request")
async def cancel_leave(leave_id: str, user: CurrentUser = Depends(get_current_user)):
    emp = await _my_employee(user)
    now = utcnow()
    res = await get_db()[C.LEAVE_REQUESTS].update_one(
        {"_id": oid(leave_id), "employee_id": emp["_id"], "status": "pending"},
        {"$set": {"status": "cancelled", "updated_at": now}, "$push": {"history": {"status": "cancelled", "by": user.id,
                                                                                  "at": now}}})
    if res.modified_count == 0:
        raise ConflictError("Only your pending requests can be cancelled")
    await audit(user, "leave.cancel", "leave_request", leave_id, {})
    return {"status": "cancelled"}


# ---------------------------------------------------------------- swaps
@router.get("/swaps", summary="Swap requests visible to you")
async def list_swaps(status_: str | None = Query(None, alias="status"), user: CurrentUser = Depends(get_current_user)):
    q: dict = {}
    if user.role.value == "employee":
        q["$or"] = [{"requester_employee_id": user.employee_id}, {"target_employee_id": user.employee_id}]
    else:
        scope = user.department_scope()
        if scope is not None:
            q["department_id"] = {"$in": scope}
    if status_:
        q["status"] = status_
    emp_lookup = lambda field, alias: {"$lookup": {"from": C.EMPLOYEES, "localField": field, "foreignField": "_id",  # noqa: E731
                                                   "as": alias, "pipeline": [{"$project": {"full_name": 1,
                                                                                           "employee_code": 1}}]}}
    asg_lookup = lambda field, alias: {"$lookup": {"from": C.ASSIGNMENTS, "localField": field, "foreignField": "_id",  # noqa: E731
                                                   "as": alias, "pipeline": [
                                                       {"$lookup": {"from": C.SHIFTS, "localField": "shift_id",
                                                                    "foreignField": "_id", "as": "shift"}},
                                                       {"$project": {"start": 1, "end": 1, "status": 1,
                                                                     "shift": {"$first": "$shift"}}}]}}
    items = await (await get_db()[C.SWAP_REQUESTS].aggregate([
        {"$match": q}, {"$sort": {"created_at": -1}}, {"$limit": 100},
        emp_lookup("requester_employee_id", "requester"), emp_lookup("target_employee_id", "target"),
        asg_lookup("requester_assignment_id", "requester_assignment"),
        asg_lookup("target_assignment_id", "target_assignment"),
        {"$addFields": {"requester": {"$first": "$requester"}, "target": {"$first": "$target"},
                        "requester_assignment": {"$first": "$requester_assignment"},
                        "target_assignment": {"$first": "$target_assignment"}}},
    ])).to_list()
    return serialize(items)


@router.post("/swaps", status_code=status.HTTP_201_CREATED, summary="Request a shift swap or cover")
async def create_swap(body: SwapCreate, user: CurrentUser = Depends(get_current_user)):
    emp = await _my_employee(user)
    return serialize(await wf.create_swap(user, emp, oid(body.assignment_id), oid(body.target_employee_id),
                                          oid_or_none(body.target_assignment_id), body.message))


@router.post("/swaps/{swap_id}/respond", summary="Colleague accepts or declines")
async def respond(swap_id: str, body: SwapResponse, user: CurrentUser = Depends(get_current_user)):
    emp = await _my_employee(user)
    return await wf.respond_swap(user, emp, oid(swap_id), body.accept)


@router.post("/swaps/{swap_id}/decision", summary="Manager approves (atomic exchange) or rejects")
async def decide(swap_id: str, body: Decision, user: CurrentUser = Depends(require_manager)):
    return await wf.decide_swap(user, oid(swap_id), body.approve, body.note)


@router.post("/swaps/{swap_id}/cancel")
async def cancel(swap_id: str, user: CurrentUser = Depends(get_current_user)):
    emp = await _my_employee(user)
    return await wf.cancel_swap(user, emp, oid(swap_id))


# ---------------------------------------------------------------- me
@router.get("/me/overview", summary="Employee dashboard: upcoming shifts, hours, pending requests")
async def my_overview(user: CurrentUser = Depends(get_current_user)):
    emp = await _my_employee(user)
    db = get_db()
    now = utcnow()
    published = await db[C.SCHEDULES].distinct("_id", {"status": "published"})
    upcoming = await (await db[C.ASSIGNMENTS].aggregate([
        {"$match": {"employee_id": emp["_id"], "status": "active", "schedule_id": {"$in": published},
                    "end": {"$gte": now}}},
        {"$sort": {"start": 1}}, {"$limit": 14},
        {"$lookup": {"from": C.SHIFTS, "localField": "shift_id", "foreignField": "_id", "as": "shift"}},
        {"$lookup": {"from": C.DEPARTMENTS, "localField": "department_id", "foreignField": "_id", "as": "department",
                     "pipeline": [{"$project": {"name": 1, "code": 1}}]}},
        {"$addFields": {"shift": {"$first": "$shift"}, "department": {"$first": "$department"}}},
    ])).to_list()
    week_hours = await (await db[C.ASSIGNMENTS].aggregate([
        {"$match": {"employee_id": emp["_id"], "status": "active", "schedule_id": {"$in": published},
                    "start": {"$gte": now - timedelta(days=42), "$lt": now + timedelta(days=21)}}},
        {"$group": {"_id": {"$dateToString": {"format": "%G-W%V", "date": "$start", "timezone": "Asia/Kolkata"}},
                    "hours": {"$sum": "$duration_hours"}, "shifts": {"$sum": 1},
                    "nights": {"$sum": {"$cond": [{"$gte": [{"$hour": {"date": "$start", "timezone": "Asia/Kolkata"}},
                                                            22]}, 1, 0]}}}},
        {"$sort": {"_id": 1}},
    ])).to_list()
    pending_swaps = await db[C.SWAP_REQUESTS].count_documents({"target_employee_id": emp["_id"], "status": "pending_peer"})
    pending_leave = await db[C.LEAVE_REQUESTS].count_documents({"employee_id": emp["_id"], "status": "pending"})
    return {"employee": serialize(emp), "upcoming": serialize(upcoming),
            "weekly_hours": [{"week": w["_id"], "hours": w["hours"], "shifts": w["shifts"], "nights": w["nights"]}
                             for w in week_hours],
            "pending_swaps_for_me": pending_swaps, "pending_leave": pending_leave}


@router.get("/me/swap-options", summary="Colleagues and their shifts available for a swap")
async def swap_options(assignment_id: str, user: CurrentUser = Depends(get_current_user)):
    emp = await _my_employee(user)
    db = get_db()
    a = await db[C.ASSIGNMENTS].find_one({"_id": oid(assignment_id), "employee_id": emp["_id"], "status": "active"})
    if not a:
        raise NotFoundError("Assignment not found")
    colleagues = await db[C.EMPLOYEES].find({"department_ids": a["department_id"], "status": "active",
                                             "_id": {"$ne": emp["_id"]}},
                                            {"full_name": 1, "employee_code": 1, "job_role": 1}).sort("full_name", 1).to_list()
    their = await (await db[C.ASSIGNMENTS].aggregate([
        {"$match": {"department_id": a["department_id"], "status": "active", "employee_id": {"$ne": emp["_id"]},
                    "start": {"$gte": utcnow(), "$lte": a["start"] + timedelta(days=10)}}},
        {"$lookup": {"from": C.SHIFTS, "localField": "shift_id", "foreignField": "_id", "as": "shift"}},
        {"$addFields": {"shift": {"$first": "$shift"}}},
        {"$project": {"employee_id": 1, "start": 1, "end": 1, "shift.name": 1, "shift.local_date": 1,
                      "shift.template_code": 1}},
        {"$sort": {"start": 1}},
    ])).to_list()
    return {"colleagues": serialize(colleagues), "colleague_assignments": serialize(their)}
