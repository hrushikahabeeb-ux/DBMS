"""Authentication and role/department-scoped authorization dependencies."""
from dataclasses import dataclass, field

from bson import ObjectId
from fastapi import Depends, Header
from fastapi.security import OAuth2PasswordBearer

from app.core.errors import ForbiddenError, UnauthorizedError
from app.core.security import SERVICE_TOKEN_HEADER, decode_access_token, verify_service_token
from app.database.mongo import Collections as C
from app.database.mongo import get_db
from app.models.enums import Role

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token", auto_error=False)


@dataclass
class CurrentUser:
    id: ObjectId
    email: str
    full_name: str
    role: Role
    employee_id: ObjectId | None = None
    managed_department_ids: list[ObjectId] = field(default_factory=list)

    @property
    def is_admin(self) -> bool:
        return self.role == Role.SUPER_ADMIN

    @property
    def is_manager(self) -> bool:
        return self.role == Role.MANAGER

    def can_manage_department(self, department_id: ObjectId | None) -> bool:
        if self.is_admin:
            return True
        return self.is_manager and department_id is not None and department_id in self.managed_department_ids

    def require_department(self, department_id: ObjectId | None) -> None:
        if not self.can_manage_department(department_id):
            raise ForbiddenError("You are not authorized to manage this department")

    def department_scope(self) -> list[ObjectId] | None:
        """None means unrestricted (super admin)."""
        if self.is_admin:
            return None
        if self.is_manager:
            return list(self.managed_department_ids)
        return []

    def audit_actor(self) -> dict:
        return {"actor_user_id": self.id, "actor_email": self.email, "actor_role": self.role.value}


async def get_current_user(token: str | None = Depends(oauth2_scheme)) -> CurrentUser:
    if not token:
        raise UnauthorizedError("Authentication required")
    payload = decode_access_token(token)
    user = await get_db()[C.USERS].find_one({"_id": ObjectId(payload["sub"])})
    if not user or not user.get("is_active", False):
        raise UnauthorizedError("Account not found or disabled")
    return CurrentUser(
        id=user["_id"], email=user["email"], full_name=user["full_name"], role=Role(user["role"]),
        employee_id=user.get("employee_id"), managed_department_ids=user.get("managed_department_ids", []),
    )


def require_roles(*roles: Role):
    async def checker(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if user.role not in roles:
            raise ForbiddenError("Your role does not permit this action")
        return user

    return checker


require_admin = require_roles(Role.SUPER_ADMIN)
require_manager = require_roles(Role.SUPER_ADMIN, Role.MANAGER)


async def require_service(x_service_token: str | None = Header(default=None, alias=SERVICE_TOKEN_HEADER)) -> None:
    verify_service_token(x_service_token)
