"""CO1 query performance comparison using MongoDB explain plans.

Each query runs twice with ``explain('executionStats')``: once forced to a
collection scan (``hint={'$natural': 1}``) and once letting the planner use
the designed index. The numbers returned are real measurements from the
current database.
"""
from datetime import timedelta

from pymongo.asynchronous.database import AsyncDatabase

from app.database.mongo import Collections as C
from app.utils.timeutils import utcnow


def _stage(plan: dict) -> str:
    stages = []
    node = plan
    while node:
        stages.append(node.get("stage"))
        node = node.get("inputStage") or (node.get("inputStages") or [None])[0]
    return " <- ".join(s for s in stages if s)


async def _explain(db: AsyncDatabase, coll: str, flt: dict, sort: list | None, hint) -> dict:
    cmd = {"find": coll, "filter": flt}
    if sort:
        cmd["sort"] = dict(sort)
    if hint is not None:
        cmd["hint"] = hint
    out = await db.command({"explain": cmd, "verbosity": "executionStats"})
    stats = out["executionStats"]
    return {
        "plan": _stage(out["queryPlanner"]["winningPlan"]),
        "index": _index_name(out["queryPlanner"]["winningPlan"]),
        "docs_examined": stats["totalDocsExamined"],
        "keys_examined": stats["totalKeysExamined"],
        "returned": stats["nReturned"],
        "time_ms": stats["executionTimeMillis"],
    }


def _index_name(plan: dict) -> str | None:
    node = plan
    while node:
        if node.get("indexName"):
            return node["indexName"]
        node = node.get("inputStage") or (node.get("inputStages") or [None])[0]
    return None


async def compare_all(db: AsyncDatabase) -> dict:
    emp = await db[C.EMPLOYEES].find_one({}, sort=[("employee_code", 1)])
    dept = await db[C.DEPARTMENTS].find_one({})
    sched = await db[C.SCHEDULES].find_one({}, sort=[("start_date", -1)])
    user = await db[C.USERS].find_one({"role": "employee"})
    if not (emp and dept and sched and user):
        return {"queries": [], "note": "Seed the database first"}
    now = utcnow()
    queries = [
        ("Employee assignments in a 14-day window", C.ASSIGNMENTS,
         {"employee_id": emp["_id"], "start": {"$gte": now - timedelta(days=7), "$lt": now + timedelta(days=7)}},
         [("start", 1)]),
        ("Active employees of a department", C.EMPLOYEES, {"department_ids": dept["_id"], "status": "active"}, None),
        ("Shifts of a schedule ordered by start", C.SHIFTS, {"schedule_id": sched["_id"]}, [("start", 1)]),
        ("Unread notifications for a user", C.NOTIFICATIONS, {"user_id": user["_id"], "read": False},
         [("created_at", -1)]),
        ("Department assignments by date and status", C.ASSIGNMENTS,
         {"department_id": dept["_id"], "start": {"$gte": now - timedelta(days=3)}, "status": "active"}, None),
    ]
    results = []
    for title, coll, flt, sort in queries:
        scan = await _explain(db, coll, flt, sort, {"$natural": 1})
        indexed = await _explain(db, coll, flt, sort, None)
        ratio = round(scan["docs_examined"] / max(1, indexed["docs_examined"]), 1)
        results.append({"query": title, "collection": coll, "filter": str(flt), "collection_scan": scan,
                        "indexed": indexed, "docs_examined_reduction_x": ratio})
    counts = {c: await db[c].estimated_document_count() for c in C.ALL}
    return {"queries": results, "collection_counts": counts, "measured_at": now.isoformat()}
