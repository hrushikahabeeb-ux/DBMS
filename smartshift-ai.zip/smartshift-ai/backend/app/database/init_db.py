"""Database creation: collections with validators, indexes and default rules."""
import logging
from datetime import datetime, timezone

from pymongo.asynchronous.database import AsyncDatabase
from pymongo.errors import CollectionInvalid

from app.core.config import get_settings
from app.database.mongo import Collections as C
from app.database.schema import INDEXES, VALIDATORS
from app.optimization.presets import DEFAULT_WEIGHTS

logger = logging.getLogger(__name__)


def default_rules() -> dict:
    settings = get_settings()
    return {
        "scope": "organization",
        "organization_name": settings.org_name,
        "timezone": settings.org_timezone,
        "min_rest_hours": 11,
        "max_consecutive_days": 6,
        "overtime_threshold_hours": 40,
        "overtime_multiplier": 1.5,
        "night_shift_codes": ["night"],
        "weekend_days": [5, 6],
        "allow_understaffing": True,
        "solver_time_limit_seconds": settings.solver_time_limit_seconds,
        "weights": DEFAULT_WEIGHTS,
        "updated_at": datetime.now(timezone.utc),
        "updated_by": None,
    }


async def init_database(db: AsyncDatabase) -> dict:
    """Idempotently create every collection, apply validators and indexes."""
    existing = set(await db.list_collection_names())
    created = []
    for name in C.ALL:
        validator = {"$jsonSchema": {"bsonType": "object", **VALIDATORS[name]}}
        if name not in existing:
            try:
                await db.create_collection(name, validator=validator, validationLevel="strict", validationAction="error")
                created.append(name)
            except CollectionInvalid:
                pass
        else:
            await db.command({"collMod": name, "validator": validator, "validationLevel": "strict", "validationAction": "error"})
        await db[name].create_indexes(INDEXES[name])

    rules = db[C.SCHEDULING_RULES]
    if await rules.find_one({"scope": "organization"}) is None:
        await rules.insert_one(default_rules())
    logger.info("database initialized", extra={"extra_fields": {"created": created}})
    return {"created": created, "collections": C.ALL}
