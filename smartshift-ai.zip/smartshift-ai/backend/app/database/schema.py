"""Collection validators ($jsonSchema) and index definitions.

Server-side validation is the last line of defense; Pydantic validates requests
first. Both are kept intentionally aligned.
"""
from pymongo import ASCENDING, DESCENDING, IndexModel

from app.database.mongo import Collections as C
from app.models.enums import (
    AssignmentSource,
    AssignmentStatus,
    EmployeeStatus,
    LeaveStatus,
    LeaveType,
    Role,
    RunKind,
    RunStatus,
    ScheduleStatus,
    SwapStatus,
)

OID = {"bsonType": "objectId"}
OID_OR_NULL = {"bsonType": ["objectId", "null"]}
DATE = {"bsonType": "date"}
STR = {"bsonType": "string"}
DATE_STR = {"bsonType": "string", "pattern": r"^\d{4}-\d{2}-\d{2}$"}
TIME_STR = {"bsonType": "string", "pattern": r"^([01]\d|2[0-3]):[0-5]\d$"}
NUM = {"bsonType": ["int", "long", "double", "decimal"]}
INT = {"bsonType": ["int", "long"]}
BOOL = {"bsonType": "bool"}


def enum(values) -> dict:
    return {"enum": [v.value for v in values]}


def arr(items: dict) -> dict:
    return {"bsonType": "array", "items": items}


VALIDATORS: dict[str, dict] = {
    C.USERS: {
        "required": ["email", "password_hash", "full_name", "role", "is_active", "created_at"],
        "properties": {
            "email": {"bsonType": "string", "pattern": r"^[^@\s]+@[^@\s]+\.[^@\s]+$"},
            "password_hash": STR,
            "full_name": {"bsonType": "string", "minLength": 2},
            "role": enum(Role),
            "employee_id": OID_OR_NULL,
            "managed_department_ids": arr(OID),
            "is_active": BOOL,
            "created_at": DATE,
        },
    },
    C.EMPLOYEES: {
        "required": ["employee_code", "full_name", "email", "primary_department_id", "department_ids", "job_role",
                     "skills", "status", "max_weekly_hours", "hourly_wage", "joining_date", "created_at"],
        "properties": {
            "employee_code": {"bsonType": "string", "pattern": r"^[A-Z]{2,4}-\d{3,5}$"},
            "full_name": {"bsonType": "string", "minLength": 2},
            "email": STR,
            "user_id": OID_OR_NULL,
            "primary_department_id": OID,
            "department_ids": {"bsonType": "array", "minItems": 1, "items": OID},
            "job_role": STR,
            "skills": arr(STR),
            "status": enum(EmployeeStatus),
            "max_weekly_hours": {"bsonType": ["int", "long", "double"], "minimum": 4, "maximum": 80},
            "preferred_shifts": arr(STR),
            "hourly_wage": {"bsonType": ["int", "long", "double"], "minimum": 0},
            "joining_date": DATE_STR,
            "version": INT,
        },
    },
    C.DEPARTMENTS: {
        "required": ["code", "name", "shift_configurations", "is_active", "created_at"],
        "properties": {
            "code": {"bsonType": "string", "pattern": r"^[A-Z]{2,6}$"},
            "name": {"bsonType": "string", "minLength": 2},
            "description": STR,
            "manager_user_id": OID_OR_NULL,
            "required_skills": arr(STR),
            "operating_hours": {
                "bsonType": "object",
                "properties": {"start": TIME_STR, "end": TIME_STR, "days": arr({"bsonType": "int", "minimum": 0, "maximum": 6})},
            },
            "shift_configurations": arr({
                "bsonType": "object",
                "required": ["code", "name", "start_time", "duration_hours", "required_staff"],
                "properties": {
                    "code": STR,
                    "name": STR,
                    "start_time": TIME_STR,
                    "duration_hours": {"bsonType": ["int", "long", "double"], "minimum": 1, "maximum": 16},
                    "required_staff": {"bsonType": ["int", "long"], "minimum": 0},
                    "required_skills": arr(STR),
                    "skill_mix": arr({"bsonType": "object", "required": ["skill", "min"],
                                      "properties": {"skill": STR, "min": {"bsonType": ["int", "long"], "minimum": 1}}}),
                },
            }),
            "is_active": BOOL,
        },
    },
    C.SCHEDULES: {
        "required": ["department_id", "start_date", "end_date", "days", "status", "version", "created_at"],
        "properties": {
            "department_id": OID,
            "start_date": DATE_STR,
            "end_date": DATE_STR,
            "days": {"bsonType": ["int", "long"], "minimum": 1, "maximum": 31},
            "status": enum(ScheduleStatus),
            "version": INT,
        },
    },
    C.SHIFTS: {
        "required": ["schedule_id", "department_id", "template_code", "local_date", "start", "end", "duration_hours",
                     "required_staff", "assigned_count"],
        "properties": {
            "schedule_id": OID,
            "department_id": OID,
            "template_code": STR,
            "local_date": DATE_STR,
            "start": DATE,
            "end": DATE,
            "duration_hours": NUM,
            "required_staff": {"bsonType": ["int", "long"], "minimum": 0},
            "assigned_count": {"bsonType": ["int", "long"], "minimum": 0},
            "required_skills": arr(STR),
            "is_night": BOOL,
            "is_weekend": BOOL,
        },
    },
    C.ASSIGNMENTS: {
        "required": ["schedule_id", "shift_id", "employee_id", "department_id", "start", "end", "duration_hours",
                     "status", "locked", "source", "created_at"],
        "properties": {
            "schedule_id": OID,
            "shift_id": OID,
            "employee_id": OID,
            "department_id": OID,
            "start": DATE,
            "end": DATE,
            "duration_hours": NUM,
            "status": enum(AssignmentStatus),
            "locked": BOOL,
            "source": enum(AssignmentSource),
        },
    },
    C.AVAILABILITY: {
        "required": ["employee_id", "recurring", "unavailable_dates", "updated_at"],
        "properties": {
            "employee_id": OID,
            "recurring": arr({"bsonType": "object", "required": ["weekday", "start", "end"],
                              "properties": {"weekday": {"bsonType": "int", "minimum": 0, "maximum": 6},
                                             "start": TIME_STR, "end": TIME_STR}}),
            "unavailable_dates": arr(DATE_STR),
            "preferred_shifts": arr(STR),
            "preferred_days_off": arr({"bsonType": "int", "minimum": 0, "maximum": 6}),
        },
    },
    C.LEAVE_REQUESTS: {
        "required": ["employee_id", "leave_type", "start_date", "end_date", "status", "history", "created_at"],
        "properties": {
            "employee_id": OID,
            "leave_type": enum(LeaveType),
            "start_date": DATE_STR,
            "end_date": DATE_STR,
            "status": enum(LeaveStatus),
            "history": arr({"bsonType": "object"}),
        },
    },
    C.SWAP_REQUESTS: {
        "required": ["requester_employee_id", "requester_assignment_id", "target_employee_id", "status", "is_open", "created_at"],
        "properties": {
            "requester_employee_id": OID,
            "requester_assignment_id": OID,
            "target_employee_id": OID,
            "target_assignment_id": OID_OR_NULL,
            "status": enum(SwapStatus),
            "is_open": BOOL,
        },
    },
    C.NOTIFICATIONS: {
        "required": ["user_id", "type", "title", "message", "read", "created_at"],
        "properties": {"user_id": OID, "type": STR, "title": STR, "message": STR, "read": BOOL, "created_at": DATE},
    },
    C.SCHEDULING_RULES: {
        "required": ["scope", "timezone", "min_rest_hours", "overtime_threshold_hours", "weights", "updated_at"],
        "properties": {
            "scope": STR,
            "timezone": STR,
            "min_rest_hours": {"bsonType": ["int", "long", "double"], "minimum": 0, "maximum": 48},
            "max_consecutive_days": {"bsonType": ["int", "long"], "minimum": 1, "maximum": 14},
            "overtime_threshold_hours": {"bsonType": ["int", "long", "double"], "minimum": 0},
            "weights": {"bsonType": "object"},
        },
    },
    C.OPTIMIZATION_RUNS: {
        "required": ["kind", "schedule_id", "department_id", "status", "created_at"],
        "properties": {
            "kind": enum(RunKind),
            "schedule_id": OID,
            "department_id": OID,
            "status": enum(RunStatus),
            "progress": {"bsonType": ["int", "long", "double"], "minimum": 0, "maximum": 100},
        },
    },
    C.AUDIT_LOGS: {
        "required": ["action", "entity_type", "created_at"],
        "properties": {"action": STR, "entity_type": STR, "actor_user_id": OID_OR_NULL, "created_at": DATE},
    },
}

INDEXES: dict[str, list[IndexModel]] = {
    C.USERS: [
        IndexModel([("email", ASCENDING)], unique=True, name="uniq_email"),
        IndexModel([("employee_id", ASCENDING)], unique=True, name="uniq_employee_link",
                   partialFilterExpression={"employee_id": {"$type": "objectId"}}),
        IndexModel([("role", ASCENDING)], name="role"),
    ],
    C.EMPLOYEES: [
        IndexModel([("employee_code", ASCENDING)], unique=True, name="uniq_employee_code"),
        IndexModel([("email", ASCENDING)], unique=True, name="uniq_employee_email"),
        IndexModel([("department_ids", ASCENDING), ("status", ASCENDING)], name="dept_status"),
        IndexModel([("skills", ASCENDING)], name="skills_multikey"),
        IndexModel([("full_name", "text"), ("employee_code", "text"), ("job_role", "text")], name="employee_text"),
    ],
    C.DEPARTMENTS: [
        IndexModel([("code", ASCENDING)], unique=True, name="uniq_dept_code"),
        IndexModel([("name", ASCENDING)], unique=True, name="uniq_dept_name"),
    ],
    C.SCHEDULES: [
        IndexModel([("department_id", ASCENDING), ("start_date", ASCENDING)], unique=True, name="uniq_dept_period"),
        IndexModel([("status", ASCENDING), ("start_date", DESCENDING)], name="status_start"),
    ],
    C.SHIFTS: [
        IndexModel([("schedule_id", ASCENDING), ("start", ASCENDING)], name="schedule_start"),
        IndexModel([("department_id", ASCENDING), ("start", ASCENDING)], name="dept_start"),
        IndexModel([("schedule_id", ASCENDING), ("local_date", ASCENDING), ("template_code", ASCENDING)], unique=True,
                   name="uniq_schedule_day_template"),
    ],
    C.ASSIGNMENTS: [
        IndexModel([("shift_id", ASCENDING), ("employee_id", ASCENDING)], unique=True, name="uniq_active_assignment",
                   partialFilterExpression={"status": "active"}),
        IndexModel([("employee_id", ASCENDING), ("start", ASCENDING)], name="employee_start"),
        IndexModel([("schedule_id", ASCENDING), ("status", ASCENDING)], name="schedule_status"),
        IndexModel([("department_id", ASCENDING), ("start", ASCENDING), ("status", ASCENDING)], name="dept_start_status"),
        IndexModel([("status", ASCENDING), ("start", ASCENDING)], name="status_start"),
    ],
    C.AVAILABILITY: [IndexModel([("employee_id", ASCENDING)], unique=True, name="uniq_availability_employee")],
    C.LEAVE_REQUESTS: [
        IndexModel([("employee_id", ASCENDING), ("start_date", ASCENDING)], name="employee_start"),
        IndexModel([("status", ASCENDING), ("start_date", ASCENDING)], name="status_start"),
        IndexModel([("department_id", ASCENDING), ("status", ASCENDING)], name="dept_status"),
    ],
    C.SWAP_REQUESTS: [
        IndexModel([("requester_assignment_id", ASCENDING)], unique=True, name="uniq_open_swap_per_assignment",
                   partialFilterExpression={"is_open": True}),
        IndexModel([("target_employee_id", ASCENDING), ("status", ASCENDING)], name="target_status"),
        IndexModel([("department_id", ASCENDING), ("status", ASCENDING)], name="dept_status"),
    ],
    C.NOTIFICATIONS: [
        IndexModel([("user_id", ASCENDING), ("read", ASCENDING), ("created_at", DESCENDING)], name="user_unread"),
        IndexModel([("dedupe_key", ASCENDING)], unique=True, name="uniq_dedupe",
                   partialFilterExpression={"dedupe_key": {"$type": "string"}}),
    ],
    C.SCHEDULING_RULES: [IndexModel([("scope", ASCENDING)], unique=True, name="uniq_scope")],
    C.OPTIMIZATION_RUNS: [
        IndexModel([("schedule_id", ASCENDING), ("created_at", DESCENDING)], name="schedule_created"),
        IndexModel([("status", ASCENDING), ("created_at", ASCENDING)], name="status_created"),
    ],
    C.AUDIT_LOGS: [
        IndexModel([("created_at", DESCENDING)], name="created_desc"),
        IndexModel([("entity_type", ASCENDING), ("entity_id", ASCENDING)], name="entity"),
        IndexModel([("actor_user_id", ASCENDING), ("created_at", DESCENDING)], name="actor_created"),
    ],
}
