"""MongoDB connection management (PyMongo Async API)."""
import logging
from collections.abc import Awaitable, Callable
from typing import Any, TypeVar

from bson.codec_options import CodecOptions
from pymongo import AsyncMongoClient
from pymongo.asynchronous.client_session import AsyncClientSession
from pymongo.asynchronous.database import AsyncDatabase
from pymongo.read_concern import ReadConcern
from pymongo.write_concern import WriteConcern

from app.core.config import get_settings

logger = logging.getLogger(__name__)

T = TypeVar("T")


class Collections:
    USERS = "users"
    EMPLOYEES = "employees"
    DEPARTMENTS = "departments"
    SHIFTS = "shifts"
    SCHEDULES = "schedules"
    ASSIGNMENTS = "assignments"
    AVAILABILITY = "availability"
    LEAVE_REQUESTS = "leave_requests"
    SWAP_REQUESTS = "swap_requests"
    NOTIFICATIONS = "notifications"
    SCHEDULING_RULES = "scheduling_rules"
    OPTIMIZATION_RUNS = "optimization_runs"
    AUDIT_LOGS = "audit_logs"

    ALL = [USERS, EMPLOYEES, DEPARTMENTS, SHIFTS, SCHEDULES, ASSIGNMENTS, AVAILABILITY, LEAVE_REQUESTS,
           SWAP_REQUESTS, NOTIFICATIONS, SCHEDULING_RULES, OPTIMIZATION_RUNS, AUDIT_LOGS]


class Mongo:
    client: AsyncMongoClient | None = None
    db_name: str | None = None

    @classmethod
    def connect(cls, uri: str | None = None, db_name: str | None = None) -> AsyncMongoClient:
        settings = get_settings()
        cls.client = AsyncMongoClient(
            uri or settings.mongodb_uri,
            tz_aware=True,
            serverSelectionTimeoutMS=settings.mongodb_timeout_ms,
            connectTimeoutMS=settings.mongodb_timeout_ms,
            appname=settings.service_name,
        )
        cls.db_name = db_name or settings.mongodb_db
        return cls.client

    @classmethod
    async def close(cls) -> None:
        if cls.client is not None:
            await cls.client.close()
            cls.client = None

    @classmethod
    def db(cls) -> AsyncDatabase:
        if cls.client is None:
            cls.connect()
        return cls.client[cls.db_name]  # type: ignore[index]

    @classmethod
    async def ping(cls) -> bool:
        try:
            await cls.db().command("ping")
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("mongo ping failed: %s", exc)
            return False


def get_db() -> AsyncDatabase:
    return Mongo.db()


async def run_transaction(callback: Callable[[AsyncClientSession], Awaitable[T]]) -> T:
    """Run ``callback`` inside a multi-document transaction.

    ``with_transaction`` retries automatically on TransientTransactionError and
    UnknownTransactionCommitResult, which is what makes concurrent edits safe.
    Requires a replica set or MongoDB Atlas deployment.
    """
    if Mongo.client is None:
        Mongo.connect()
    async with Mongo.client.start_session() as session:  # type: ignore[union-attr]
        return await session.with_transaction(
            callback,
            read_concern=ReadConcern("snapshot"),
            write_concern=WriteConcern("majority"),
        )


def codec() -> CodecOptions:
    return CodecOptions(tz_aware=True)


def serialize(doc: Any) -> Any:
    """Convert ObjectIds/datetimes in Mongo documents into JSON-friendly values."""
    from datetime import datetime

    from bson import ObjectId

    if isinstance(doc, list):
        return [serialize(d) for d in doc]
    if isinstance(doc, dict):
        out = {}
        for k, v in doc.items():
            key = "id" if k == "_id" else k
            out[key] = serialize(v)
        return out
    if isinstance(doc, ObjectId):
        return str(doc)
    if isinstance(doc, datetime):
        return doc.isoformat()
    return doc
