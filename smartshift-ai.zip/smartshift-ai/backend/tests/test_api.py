"""API, authorization, CRUD, scheduling workflow and MongoDB persistence tests.
They run against a real MongoDB replica set (transactions) and real Redis."""
import asyncio
from datetime import date, timedelta

import pytest
from bson import ObjectId
from pymongo.errors import WriteError

from app.database.mongo import Collections as C
from app.services.optimization_jobs import process_run

pytestmark = pytest.mark.asyncio


# ------------------------------------------------------------------ authentication & roles
async def test_login_success_and_failure(client):
    ok = await client.post("/api/auth/login", json={"email": "admin@smartshift.ai", "password": "Admin@123"})
    assert ok.status_code == 200 and ok.json()["user"]["role"] == "super_admin"
    bad = await client.post("/api/auth/login", json={"email": "admin@smartshift.ai", "password": "wrong"})
    assert bad.status_code == 401
    assert bad.json()["error"]["code"] == "unauthorized"


async def test_protected_routes_require_token(client):
    assert (await client.get("/api/employees")).status_code == 401
    assert (await client.get("/api/employees", headers={"Authorization": "Bearer garbage"})).status_code == 401


async def test_passwords_are_hashed(db):
    u = await db[C.USERS].find_one({"email": "admin@smartshift.ai"})
    assert u["password_hash"].startswith("$2b$") and "Admin@123" not in u["password_hash"]


async def test_role_permissions(client, login, manager, admin):
    emp = await login("ananya.sharma@smartshift.ai")
    assert (await client.get("/api/employees", headers=emp)).status_code == 403
    assert (await client.post("/api/departments", headers=manager, json={})).status_code in (403, 422)
    assert (await client.get("/api/users", headers=manager)).status_code == 403
    assert (await client.get("/api/users", headers=admin)).status_code == 200


async def test_department_scoped_authorization(client, manager, db):
    icu = await db[C.DEPARTMENTS].find_one({"code": "ICU"})
    r = await client.get("/api/employees", headers=manager, params={"department_id": str(icu["_id"])})
    assert r.status_code == 403
    sched = await db[C.SCHEDULES].find_one({"department_id": icu["_id"]})
    assert (await client.get(f"/api/schedules/{sched['_id']}", headers=manager)).status_code == 403
    # Listing is automatically scoped to the manager's departments.
    r = await client.get("/api/employees", headers=manager, params={"page_size": 100})
    emr = await db[C.DEPARTMENTS].find_one({"code": "EMR"})
    assert all(str(emr["_id"]) in e["department_ids"] for e in r.json()["items"])


async def test_register_requires_existing_employee(client, admin, db):
    r = await client.post("/api/auth/register", json={"email": "nobody@x.com", "password": "Passw0rdX", "full_name": "No One"})
    assert r.status_code == 409


# ------------------------------------------------------------------ employee CRUD
async def test_employee_crud_and_validation(client, manager, db):
    emr = await db[C.DEPARTMENTS].find_one({"code": "EMR"})
    body = {"employee_code": "EMP-901", "full_name": "Test Nurse", "email": "test.nurse@smartshift.ai",
            "primary_department_id": str(emr["_id"]), "job_role": "Registered Nurse", "skills": ["BLS", "Triage"],
            "max_weekly_hours": 40, "hourly_wage": 500, "joining_date": "2025-01-01", "create_login": True}
    r = await client.post("/api/employees", headers=manager, json=body)
    assert r.status_code == 201, r.text
    eid = r.json()["id"]
    assert (await client.post("/api/employees", headers=manager, json=body)).status_code == 409  # unique code/email
    invalid = {**body, "employee_code": "bad", "hourly_wage": -5}
    r = await client.post("/api/employees", headers=manager, json=invalid)
    assert r.status_code == 422 and {e["field"] for e in r.json()["error"]["details"]} >= {"employee_code", "hourly_wage"}

    r = await client.get("/api/employees", headers=manager, params={"search": "Test Nurse"})
    assert r.json()["total"] == 1
    r = await client.get("/api/employees", headers=manager, params={"skill": "Triage", "sort": "-hourly_wage",
                                                                    "page_size": 3, "page": 1})
    data = r.json()
    wages = [e["hourly_wage"] for e in data["items"]]
    assert wages == sorted(wages, reverse=True) and data["page_size"] == 3 and data["pages"] >= 1
    r = await client.patch(f"/api/employees/{eid}", headers=manager, json={"max_weekly_hours": 32})
    assert r.json()["max_weekly_hours"] == 32
    profile = await client.get(f"/api/employees/{eid}/profile", headers=manager)
    assert profile.status_code == 200 and "hours_history" in profile.json()
    r = await client.delete(f"/api/employees/{eid}", headers=manager)
    assert r.status_code == 200
    doc = await db[C.EMPLOYEES].find_one({"_id": ObjectId(eid)})
    assert doc["status"] == "inactive"


async def test_mongodb_schema_validation_rejects_bad_documents(db):
    with pytest.raises(WriteError):
        await db[C.EMPLOYEES].insert_one({"full_name": "X"})
    with pytest.raises(WriteError):
        await db[C.ASSIGNMENTS].insert_one({"status": "nonsense"})


# ------------------------------------------------------------------ departments
async def test_department_crud(client, admin):
    body = {"code": "LAB", "name": "Laboratory", "description": "Pathology lab",
            "shift_configurations": [{"code": "day", "name": "Day", "start_time": "08:00", "duration_hours": 8,
                                      "required_staff": 2}]}
    r = await client.post("/api/departments", headers=admin, json=body)
    assert r.status_code == 201
    did = r.json()["id"]
    r = await client.patch(f"/api/departments/{did}", headers=admin, json={"description": "Clinical lab"})
    assert r.json()["description"] == "Clinical lab"
    dup = await client.post("/api/departments", headers=admin, json={**body, "code": "LABB"})
    assert dup.status_code == 409  # unique name
    bad = await client.post("/api/departments", headers=admin, json={**body, "code": "LB2",
                                                                    "shift_configurations": []})
    assert bad.status_code == 422
    assert (await client.delete(f"/api/departments/{did}", headers=admin)).status_code == 200


# ------------------------------------------------------------------ scheduling
async def _emr(db):
    return await db[C.DEPARTMENTS].find_one({"code": "EMR"})


async def _new_schedule(client, headers, db, offset_days: int, days: int = 1):
    emr = await _emr(db)
    start = date.today() + timedelta(days=offset_days)
    start -= timedelta(days=start.weekday())
    r = await client.post("/api/schedules", headers=headers, json={"department_id": str(emr["_id"]),
                                                                   "start_date": start.isoformat(), "days": days})
    assert r.status_code == 201, r.text
    return r.json()["id"]


async def test_schedule_generation_apply_publish(client, manager, db):
    sched = await db[C.SCHEDULES].find_one({"status": "draft"})
    r = await client.post(f"/api/schedules/{sched['_id']}/generate", headers=manager,
                          json={"presets": ["balanced", "cost"]})
    assert r.status_code == 202
    run_id = ObjectId(r.json()["job_id"])
    dup = await client.post(f"/api/schedules/{sched['_id']}/generate", headers=manager, json={})
    assert dup.status_code == 409  # one active job per schedule
    await process_run(run_id)
    run = (await client.get(f"/api/runs/{run_id}", headers=manager)).json()
    assert run["status"] == "completed"
    bal = run["result"]["variants"]["balanced"]
    assert bal["metrics"]["constraint_violations"] == 0
    assert set(run["result"]["baselines"]) == {"greedy", "round_robin"}
    r = await client.post(f"/api/runs/{run_id}/apply", headers=manager, json={"variant": "balanced"})
    assert r.status_code == 200 and r.json()["assignments_created"] == len(bal["assignments"])
    conflicts = (await client.get(f"/api/schedules/{sched['_id']}/conflicts", headers=manager)).json()
    assert not [c for c in conflicts["conflicts"] if c["type"] not in ("understaffed", "skill_mix")]
    assert (await client.post(f"/api/schedules/{sched['_id']}/publish", headers=manager)).status_code == 200
    assert (await client.post(f"/api/schedules/{sched['_id']}/publish", headers=manager)).status_code == 409
    count = await db[C.ASSIGNMENTS].count_documents({"schedule_id": sched["_id"], "status": "active"})
    assert count == len(bal["assignments"])  # persisted in MongoDB


async def test_invalid_manual_assignment_rejected(client, manager, db):
    sid = await _new_schedule(client, manager, db, 63)
    shifts = await db[C.SHIFTS].find({"schedule_id": ObjectId(sid)}).sort("start", 1).to_list()
    morning, evening = shifts[0], shifts[1]
    emp = await db[C.EMPLOYEES].find_one({"employee_code": "EMP-001"})
    ok = await client.post("/api/assignments", headers=manager, json={"shift_id": str(morning["_id"]),
                                                                      "employee_id": str(emp["_id"])})
    assert ok.status_code == 201
    bad = await client.post("/api/assignments", headers=manager, json={"shift_id": str(evening["_id"]),
                                                                       "employee_id": str(emp["_id"])})
    assert bad.status_code == 409
    assert any(c["code"] == "rest" for c in bad.json()["error"]["details"]["failed"])
    icu_only = await db[C.EMPLOYEES].find_one({"employee_code": "EMP-012"})
    r = await client.post("/api/assignments/validate", headers=manager,
                          json={"shift_id": str(evening["_id"]), "employee_id": str(icu_only["_id"])})
    assert not r.json()["valid"] and any(c["code"] == "department" for c in r.json()["failed"])
    explain = await client.get(f"/api/assignments/{ok.json()['id']}/explain", headers=manager)
    assert explain.json()["valid"] and explain.json()["checks"]


async def test_concurrent_assignments_cannot_overfill_or_double_book(client, manager, db):
    sid = await _new_schedule(client, manager, db, 70)
    shifts = await db[C.SHIFTS].find({"schedule_id": ObjectId(sid)}).sort("start", 1).to_list()
    morning, evening = shifts[0], shifts[1]
    emr = await _emr(db)
    staff = await db[C.EMPLOYEES].find({"primary_department_id": emr["_id"], "status": "active",
                                        "employee_code": {"$in": ["EMP-001", "EMP-003", "EMP-004", "EMP-006", "EMP-008"]}}
                                       ).to_list()
    reqs = [client.post("/api/assignments", headers=manager,
                        json={"shift_id": str(morning["_id"]), "employee_id": str(e["_id"])}) for e in staff]
    results = await asyncio.gather(*reqs)
    created = [r for r in results if r.status_code == 201]
    assert len(created) == morning["required_staff"]  # capacity respected under concurrency
    assert all(r.status_code in (201, 409) for r in results)
    doc = await db[C.SHIFTS].find_one({"_id": morning["_id"]})
    assert doc["assigned_count"] == morning["required_staff"]

    free = [e for e in staff if e["_id"] not in {ObjectId(r.json()["employee_id"]) for r in created}][0]
    night = shifts[2]
    both = await asyncio.gather(
        client.post("/api/assignments", headers=manager, json={"shift_id": str(evening["_id"]), "employee_id": str(free["_id"])}),
        client.post("/api/assignments", headers=manager, json={"shift_id": str(night["_id"]), "employee_id": str(free["_id"])}),
    )
    assert sorted(r.status_code for r in both) == [201, 409]  # no double booking across concurrent requests


async def test_drag_and_drop_move_validated(client, manager, db):
    sid = await _new_schedule(client, manager, db, 77, days=2)
    shifts = await db[C.SHIFTS].find({"schedule_id": ObjectId(sid)}).sort("start", 1).to_list()
    emp = await db[C.EMPLOYEES].find_one({"employee_code": "EMP-006"})
    a = await client.post("/api/assignments", headers=manager, json={"shift_id": str(shifts[0]["_id"]),
                                                                     "employee_id": str(emp["_id"])})
    moved = await client.patch(f"/api/assignments/{a.json()['id']}/move", headers=manager,
                               json={"target_shift_id": str(shifts[3]["_id"])})
    assert moved.status_code == 200 and moved.json()["shift_id"] == str(shifts[3]["_id"])
    other = await client.post("/api/assignments", headers=manager, json={"shift_id": str(shifts[2]["_id"]),
                                                                         "employee_id": str(emp["_id"])})
    assert other.status_code == 409  # night before the moved morning shift: overlap


# ------------------------------------------------------------------ emergency replacement
async def test_emergency_replacement_flow(client, manager, db):
    now = __import__("app.utils.timeutils", fromlist=["utcnow"]).utcnow()
    emr = await _emr(db)
    a = await db[C.ASSIGNMENTS].find_one({"department_id": emr["_id"], "status": "active",
                                          "start": {"$gt": now + timedelta(hours=2)}}, sort=[("start", 1)])
    r = await client.post(f"/api/assignments/{a['_id']}/absence", headers=manager, json={"reason": "Sudden illness"})
    assert r.status_code == 200
    data = r.json()
    assert "ranking_formula" in data
    vac = (await client.get("/api/emergency/vacancies", headers=manager)).json()
    assert any(v["id"] == str(a["_id"]) for v in vac)
    if data["shortage"]:
        return
    scores = [c["score"] for c in data["candidates"]]
    assert scores == sorted(scores, reverse=True)
    best = data["candidates"][0]
    assert all(c["passed"] for c in best["checks"])
    ok = await client.post(f"/api/assignments/{a['_id']}/replace", headers=manager, json={"employee_id": best["employee_id"]})
    assert ok.status_code == 200
    again = await client.post(f"/api/assignments/{a['_id']}/replace", headers=manager,
                              json={"employee_id": best["employee_id"]})
    assert again.status_code == 409
    old = await db[C.ASSIGNMENTS].find_one({"_id": a["_id"]})
    assert old["status"] == "replaced" and old["replaced_by_assignment_id"]


# ------------------------------------------------------------------ leave
async def test_leave_approval_affects_scheduling(client, login, manager, db):
    emp = await db[C.EMPLOYEES].find_one({"employee_code": "EMP-002"})
    now = __import__("app.utils.timeutils", fromlist=["utcnow"]).utcnow()
    a = await db[C.ASSIGNMENTS].find_one({"employee_id": emp["_id"], "status": "active", "start": {"$gt": now}},
                                         sort=[("start", 1)])
    shift = await db[C.SHIFTS].find_one({"_id": a["shift_id"]})
    headers = await login(emp["email"])
    r = await client.post("/api/leave", headers=headers, json={"leave_type": "sick", "start_date": shift["local_date"],
                                                               "end_date": shift["local_date"], "reason": "Flu symptoms"})
    assert r.status_code == 201
    lid = r.json()["id"]
    dup = await client.post("/api/leave", headers=headers, json={"leave_type": "sick", "start_date": shift["local_date"],
                                                                 "end_date": shift["local_date"], "reason": "Again"})
    assert dup.status_code == 409
    impact = (await client.get(f"/api/leave/{lid}/impact", headers=manager)).json()
    assert impact["count"] >= 1
    d = await client.post(f"/api/leave/{lid}/decision", headers=manager, json={"approve": True})
    assert d.status_code == 200 and d.json()["replacement_required"]
    assert (await db[C.ASSIGNMENTS].find_one({"_id": a["_id"]}))["status"] == "absent"
    again = await client.post(f"/api/leave/{lid}/decision", headers=manager, json={"approve": False})
    assert again.status_code == 409
    # Approved leave now blocks new assignments that day.
    v = await client.post("/api/assignments/validate", headers=manager,
                          json={"shift_id": str(shift["_id"]), "employee_id": str(emp["_id"])})
    assert any(c["code"] == "leave" for c in v.json()["failed"])


# ------------------------------------------------------------------ swaps
async def test_shift_swap_workflow_with_duplicate_approval_guard(client, login, manager, db):
    emr = await _emr(db)
    now = __import__("app.utils.timeutils", fromlist=["utcnow"]).utcnow()
    pool = await db[C.ASSIGNMENTS].find({"department_id": emr["_id"], "status": "active",
                                         "start": {"$gt": now + timedelta(days=1)}}).sort("start", 1).to_list(200)
    requester_assign = target = None
    for a in pool:
        req_emp = await db[C.EMPLOYEES].find_one({"_id": a["employee_id"]})
        for e in await db[C.EMPLOYEES].find({"department_ids": emr["_id"], "status": "active",
                                             "_id": {"$ne": a["employee_id"]}}).to_list():
            shift = await db[C.SHIFTS].find_one({"_id": a["shift_id"]})
            v = await client.post("/api/assignments/validate", headers=manager,
                                  json={"shift_id": str(shift["_id"]), "employee_id": str(e["_id"])})
            if v.json()["valid"]:
                requester_assign, target, requester = a, e, req_emp
                break
        if target:
            break
    assert target, "no valid cover candidate found in seed data"
    rh = await login(requester["email"])
    r = await client.post("/api/swaps", headers=rh, json={"assignment_id": str(requester_assign["_id"]),
                                                          "target_employee_id": str(target["_id"])})
    assert r.status_code == 201, r.text
    swap_id = r.json()["id"]
    dup = await client.post("/api/swaps", headers=rh, json={"assignment_id": str(requester_assign["_id"]),
                                                            "target_employee_id": str(target["_id"])})
    assert dup.status_code == 409  # unique open swap per assignment
    th = await login(target["email"])
    assert (await client.post(f"/api/swaps/{swap_id}/respond", headers=th, json={"accept": True})).status_code == 200
    results = await asyncio.gather(*[client.post(f"/api/swaps/{swap_id}/decision", headers=manager, json={"approve": True})
                                     for _ in range(3)])
    assert sorted(r.status_code for r in results) == [200, 409, 409]
    moved = await db[C.ASSIGNMENTS].find_one({"_id": requester_assign["_id"]})
    assert moved["employee_id"] == target["_id"] and moved["source"] == "swap"


# ------------------------------------------------------------------ simulation, analytics, persistence
async def test_simulation_never_modifies_schedule(client, manager, db):
    sched = await db[C.SCHEDULES].find_one({"status": "published", "department_id": (await _emr(db))["_id"]},
                                           sort=[("start_date", -1)])
    before = sorted([(str(a["shift_id"]), str(a["employee_id"])) async for a in
                     db[C.ASSIGNMENTS].find({"schedule_id": sched["_id"], "status": "active"})])
    r = await client.post(f"/api/schedules/{sched['_id']}/simulate", headers=manager,
                          json={"absent_count": 3, "demand_increase_pct": 30})
    assert r.status_code == 202
    await process_run(ObjectId(r.json()["job_id"]))
    run = (await client.get(f"/api/runs/{r.json()['job_id']}", headers=manager)).json()
    assert run["status"] == "completed"
    assert len(run["result"]["scenario_changes"]["removed_employees"]) == 3
    assert run["result"]["current"] is not None
    after = sorted([(str(a["shift_id"]), str(a["employee_id"])) async for a in
                    db[C.ASSIGNMENTS].find({"schedule_id": sched["_id"], "status": "active"})])
    assert before == after


async def test_analytics_gateway_and_aggregations(client, manager, admin):
    ov = await client.get("/api/analytics/overview", headers=manager)
    assert ov.status_code == 200 and ov.json()["kpis"]["total_employees"] > 0
    for path in ("coverage", "hours", "departments", "labor-cost", "leave-trends", "shortages",
                 "optimization-comparison", "export/hours"):
        r = await client.get(f"/api/analytics/{path}", headers=admin)
        assert r.status_code == 200, (path, r.text)
    perf = (await client.get("/api/analytics/query-performance", headers=admin)).json()
    assert perf["queries"] and all(q["indexed"]["index"] for q in perf["queries"])


async def test_audit_log_written(client, admin, db):
    assert await db[C.AUDIT_LOGS].count_documents({"action": "assignment.create"}) > 0
    r = await client.get("/api/audit-logs", headers=admin, params={"action": "assignment"})
    assert r.status_code == 200 and r.json()["total"] > 0


async def test_employee_sees_only_own_published_schedule(client, login, db):
    emp = await db[C.EMPLOYEES].find_one({"employee_code": "EMP-001"})
    h = await login(emp["email"])
    today = date.today()
    r = await client.get("/api/calendar", headers=h, params={"start": (today - timedelta(days=7)).isoformat(),
                                                             "end": (today + timedelta(days=14)).isoformat()})
    assert r.status_code == 200 and r.json()["mode"] == "employee"
    assert all(a["employee_id"] == str(emp["_id"]) for a in r.json()["assignments"])
    published = {str(s) for s in await db[C.SCHEDULES].distinct("_id", {"status": "published"})}
    assert all(a["schedule_id"] in published for a in r.json()["assignments"])
