"""Pure optimization-engine tests (no database). These demonstrate that CP-SAT
never violates hard constraints, detects infeasibility honestly and beats the
baselines on measurable criteria."""
import random
from datetime import timedelta

import pytest

from app.optimization.constraints import Interval, conflicts, dynamic_checks, static_checks, verify
from app.optimization.metrics import compute_metrics, gini
from app.optimization.solver import optimize, solve
from app.optimization.types import Pair, Rules, Weights
from tests.factories import MONDAY, make_employees, make_request, make_shifts

RULES = Rules(time_limit_seconds=5, workers=4)


def pairs_of(variant):
    return [(a["shift_id"], a["employee_id"]) for a in variant["assignments"]]


def hard_violations(shifts, emps, pairs, rules=RULES):
    return [v for v in verify(shifts, emps, pairs, rules) if v.type not in ("understaffed", "skill_mix", "overstaffed")]


def test_full_coverage_without_violations():
    shifts, emps = make_shifts(MONDAY), make_employees(9)
    out = optimize(make_request(shifts, emps, rules=RULES))
    v = out["variants"]["balanced"]
    assert v["status"] == "SUCCESS"
    assert v["metrics"]["coverage_pct"] == 100
    assert hard_violations(shifts, emps, pairs_of(v)) == []


@pytest.mark.parametrize("seed", [1, 2, 3, 4, 5])
def test_randomized_instances_never_violate_hard_constraints(seed):
    rnd = random.Random(seed)
    shifts = make_shifts(MONDAY, staff=(rnd.randint(1, 3), rnd.randint(1, 3), rnd.randint(1, 2)),
                         mix=[{"skill": "ACLS", "min": 1}] if seed % 2 else None)
    emps = make_employees(rnd.randint(6, 10))
    for e in emps:
        e.max_weekly_hours = rnd.choice([24, 32, 40, 48])
        if rnd.random() < 0.5:
            e.skills.append("ACLS")
        if rnd.random() < 0.3:
            e.windows = [w for w in e.windows if w.start_min != 23 * 60]  # day-only staff
        if rnd.random() < 0.3:
            e.leave_dates = [(MONDAY + timedelta(days=rnd.randint(0, 6))).isoformat()]
        if rnd.random() < 0.3:
            e.unavailable_dates = [(MONDAY + timedelta(days=rnd.randint(0, 6))).isoformat()]
    out = optimize(make_request(shifts, emps, rules=RULES))
    v = out["variants"]["balanced"]
    assert v["status"] in ("SUCCESS", "PARTIAL")
    assert hard_violations(shifts, emps, pairs_of(v)) == []
    # Unfilled slots are reported, never hidden.
    assert v["metrics"]["filled_slots"] + v["metrics"]["unfilled_count"] == v["metrics"]["required_slots"]


def test_minimum_rest_and_overlap():
    shifts = make_shifts(MONDAY, days=2)
    by = {s.id: s for s in shifts}
    m, e, n = by[f"{MONDAY}-morning"], by[f"{MONDAY}-evening"], by[f"{MONDAY}-night"]
    assert conflicts(Interval.from_shift(m), Interval.from_shift(e), 11)[0]  # 0h rest
    assert conflicts(Interval.from_shift(e), Interval.from_shift(n), 11)[0]
    next_morning = by[f"{MONDAY + timedelta(days=1)}-morning"]
    assert conflicts(Interval.from_shift(e), Interval.from_shift(next_morning), 11)[0]  # 8h rest
    assert not conflicts(Interval.from_shift(m), Interval.from_shift(next_morning), 11)[0]  # 16h rest
    emp = make_employees(1)[0]
    checks = {c.code: c for c in dynamic_checks(emp, e, [Interval.from_shift(m)], RULES)}
    assert not checks["rest"].passed


def test_weekly_hour_limit_is_respected():
    shifts = make_shifts(MONDAY, staff=(1, 1, 1))
    emps = make_employees(3, max_hours=56)
    emps[0].max_weekly_hours = 16
    out = solve(make_request(shifts, emps, rules=RULES), Weights())
    hours = {e.id: 0 for e in emps}
    for sid, eid in pairs_of(out):
        hours[eid] += 8
    assert hours[emps[0].id] <= 16


def test_skills_leave_availability_respected():
    shifts = make_shifts(MONDAY, days=3, skills=["Critical Care"])
    emps = make_employees(8, skills=("BLS",))
    for e in emps[:5]:
        e.skills.append("Critical Care")
    emps[0].leave_dates = [MONDAY.isoformat()]
    emps[1].windows = []  # never available
    v = optimize(make_request(shifts, emps, rules=RULES, include_baselines=False))["variants"]["balanced"]
    assigned = {eid for _, eid in pairs_of(v)}
    assert not assigned & {e.id for e in emps[5:]}, "unqualified staff assigned"
    assert emps[1].id not in assigned
    assert all(not (sid.startswith(MONDAY.isoformat()) and eid == emps[0].id) for sid, eid in pairs_of(v))


def test_deactivated_employee_never_assigned():
    shifts, emps = make_shifts(MONDAY), make_employees(9)
    emps[0].active = False
    v = optimize(make_request(shifts, emps, rules=RULES, include_baselines=False))["variants"]["balanced"]
    assert emps[0].id not in {eid for _, eid in pairs_of(v)}


def test_locked_assignments_preserved():
    shifts, emps = make_shifts(MONDAY), make_employees(9)
    lock = Pair(shift_id=shifts[4].id, employee_id=emps[8].id)
    v = optimize(make_request(shifts, emps, rules=RULES, locked=[lock], include_baselines=False))["variants"]["balanced"]
    assert (lock.shift_id, lock.employee_id) in pairs_of(v)


def test_invalid_lock_is_reported_not_fabricated():
    shifts, emps = make_shifts(MONDAY), make_employees(9)
    emps[0].leave_dates = [MONDAY.isoformat()]
    lock = Pair(shift_id=shifts[0].id, employee_id=emps[0].id)
    v = optimize(make_request(shifts, emps, rules=RULES, locked=[lock], include_baselines=False))["variants"]["balanced"]
    assert v["status"] == "INFEASIBLE" and v["assignments"] == []
    assert any(i["type"] == "invalid_locked_assignment" for i in v["diagnosis"]["issues"])


def test_infeasible_when_understaffing_disallowed():
    shifts, emps = make_shifts(MONDAY, staff=(4, 4, 4)), make_employees(5)
    rules = Rules(time_limit_seconds=5, workers=4, allow_understaffing=False)
    v = optimize(make_request(shifts, emps, rules=rules, include_baselines=False))["variants"]["balanced"]
    assert v["status"] == "INFEASIBLE"
    assert v["assignments"] == []
    assert v["diagnosis"]["suggestions"], "must explain how to resolve the shortage"
    assert v["diagnosis"]["available_capacity_hours"] < v["diagnosis"]["required_hours"]


def test_partial_schedule_reports_unfilled_shifts():
    shifts, emps = make_shifts(MONDAY, staff=(3, 3, 2)), make_employees(5)
    v = optimize(make_request(shifts, emps, rules=RULES, include_baselines=False))["variants"]["balanced"]
    assert v["status"] == "PARTIAL"
    assert v["metrics"]["unfilled_count"] > 0 and v["warnings"]
    assert hard_violations(shifts, emps, pairs_of(v)) == []


def test_skill_mix_enforced():
    shifts = make_shifts(MONDAY, mix=[{"skill": "ACLS", "min": 1}])
    emps = make_employees(10)
    for e in emps[:6]:  # 6 qualified x 5 shifts = 30 >= 21 shifts needing one each
        e.skills.append("ACLS")
    v = optimize(make_request(shifts, emps, rules=RULES, include_baselines=False))["variants"]["balanced"]
    acls = {e.id for e in emps[:6]}
    by_shift = {}
    for sid, eid in pairs_of(v):
        by_shift.setdefault(sid, []).append(eid)
    assert all(any(e in acls for e in by_shift.get(s.id, [])) for s in shifts if s.required_staff)


def test_cpsat_beats_baselines_on_preferences_and_violations():
    shifts = make_shifts(MONDAY)
    emps = make_employees(10)
    for i, e in enumerate(emps):
        e.preferred_shifts = [["morning"], ["evening"], ["night"]][i % 3]
    out = optimize(make_request(shifts, emps, rules=RULES))
    cp = out["variants"]["balanced"]["metrics"]
    greedy, rr = out["baselines"]["greedy"]["metrics"], out["baselines"]["round_robin"]["metrics"]
    assert cp["constraint_violations"] == 0
    assert cp["preference_satisfaction_pct"] >= greedy["preference_satisfaction_pct"]
    assert cp["preference_satisfaction_pct"] >= rr["preference_satisfaction_pct"]
    assert rr["constraint_violations"] >= cp["constraint_violations"]


def test_cost_preset_is_cheaper_than_wellbeing():
    shifts = make_shifts(MONDAY)
    emps = make_employees(12)
    for i, e in enumerate(emps):
        e.hourly_wage = 300 + 150 * (i % 4)
        e.preferred_shifts = ["morning"] if i % 2 else ["evening"]
    presets = {"cost": Weights(cost=10, preference=1, fairness=1, night_balance=1, weekend_balance=1, overtime=10),
               "wellbeing": Weights(cost=1, preference=10, fairness=10, night_balance=8, weekend_balance=8)}
    out = optimize(make_request(shifts, emps, rules=RULES, presets=presets, include_baselines=False))
    assert out["variants"]["cost"]["metrics"]["labor_cost"] <= out["variants"]["wellbeing"]["metrics"]["labor_cost"]
    assert (out["variants"]["wellbeing"]["metrics"]["preference_satisfaction_pct"]
            >= out["variants"]["cost"]["metrics"]["preference_satisfaction_pct"])


def test_verifier_detects_every_violation_type():
    shifts = make_shifts(MONDAY, days=1, skills=["ICU"])
    emps = make_employees(2)
    emps[1].leave_dates = [MONDAY.isoformat()]
    m, e = shifts[0].id, shifts[1].id
    v = verify(shifts, emps, [(m, emps[0].id), (e, emps[0].id), (m, emps[0].id), (m, emps[1].id)], RULES)
    types = {x.type for x in v}
    assert {"duplicate", "insufficient_rest", "skills", "leave", "understaffed"} <= types


def test_static_checks_messages():
    s = make_shifts(MONDAY, days=1, skills=["ACLS"])[0]
    e = make_employees(1)[0]
    failed = [c.code for c in static_checks(e, s) if not c.passed]
    assert failed == ["skills"]


def test_metrics_and_gini():
    assert gini([5, 5, 5]) == 0
    assert gini([0, 0, 10]) > 0.6
    shifts, emps = make_shifts(MONDAY, days=1), make_employees(5)
    m = compute_metrics(shifts, emps, [(shifts[0].id, emps[0].id)], RULES)
    assert m["coverage_pct"] == 20.0 and m["unfilled_count"] == 4
    assert 0 <= m["fairness_score"] <= 100
