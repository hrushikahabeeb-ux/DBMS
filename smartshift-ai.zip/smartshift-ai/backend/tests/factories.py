"""Synthetic optimizer inputs for pure algorithm tests (no database)."""
from datetime import date, timedelta

from app.optimization.types import EmployeeIn, OptimizeRequest, Rules, ShiftIn, SkillMix, Weights, Window
from app.utils.timeutils import shift_times

TZ = "Asia/Kolkata"
TEMPLATES = [("morning", "Morning", "07:00", 8), ("evening", "Evening", "15:00", 8), ("night", "Night", "23:00", 8)]


def make_shifts(start: date, days: int = 7, staff=(2, 2, 1), dept="D1", skills=None, mix=None) -> list[ShiftIn]:
    out = []
    for i in range(days):
        d = start + timedelta(days=i)
        for (code, name, st, dur), req in zip(TEMPLATES, staff):
            t = shift_times(d, st, dur, TZ)
            out.append(ShiftIn(id=f"{d.isoformat()}-{code}", department_id=dept, template_code=code, name=name,
                               duration_hours=dur, required_staff=req, required_skills=skills or [],
                               skill_mix=[SkillMix(**m) for m in (mix or [])],
                               is_night=code == "night", is_weekend=d.weekday() >= 5, **t))
    return out


def full_windows() -> list[Window]:
    w = []
    for wd in range(7):
        w.append(Window(weekday=wd, start_min=7 * 60, end_min=23 * 60))
        w.append(Window(weekday=wd, start_min=23 * 60, end_min=7 * 60 + 1440))
    return w


def make_employees(n: int, dept="D1", skills=("BLS",), max_hours=40, wage=500, **kw) -> list[EmployeeIn]:
    return [EmployeeIn(id=f"E{i:02d}", code=f"EMP-{i:03d}", name=f"Employee {i}", department_ids=[dept],
                       skills=list(skills), max_weekly_hours=max_hours, hourly_wage=wage + 10 * i,
                       windows=full_windows(), **kw) for i in range(n)]


def make_request(shifts, employees, **kw) -> OptimizeRequest:
    rules = kw.pop("rules", Rules(time_limit_seconds=5, workers=4))
    presets = kw.pop("presets", {"balanced": Weights()})
    return OptimizeRequest(department_id="D1", shifts=shifts, employees=employees, rules=rules, presets=presets, **kw)


MONDAY = date(2026, 11, 2)
