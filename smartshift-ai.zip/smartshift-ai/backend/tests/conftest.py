"""Test fixtures: a dedicated MongoDB database seeded with the demo dataset, the
main API and optimizer service mounted in-process (real HTTP semantics via ASGI
transports), and real Redis on a separate logical database."""
import os

os.environ.setdefault("MONGODB_DB", "smartshift_test")
os.environ.setdefault("REDIS_URL", "redis://127.0.0.1:6379/15")
os.environ.setdefault("OPTIMIZER_URL", "http://optimizer.test")
os.environ.setdefault("ANALYTICS_URL", "http://analytics.test")

import httpx  # noqa: E402
import pytest  # noqa: E402

from app.core.config import get_settings  # noqa: E402
from app.core.service_client import register_transport  # noqa: E402
from app.database.mongo import Mongo  # noqa: E402

PASSWORDS = {"admin@smartshift.ai": "Admin@123", "er.manager@smartshift.ai": "Manager@123",
             "icu.manager@smartshift.ai": "Manager@123"}


@pytest.fixture(scope="session")
async def db():
    Mongo.connect(db_name=get_settings().mongodb_db)
    from scripts.seed import seed
    await seed(Mongo.db(), reset=True)
    yield Mongo.db()
    await Mongo.client.drop_database(get_settings().mongodb_db)
    await Mongo.close()


@pytest.fixture(scope="session")
async def client(db):
    from app.entrypoints.analytics_service import app as analytics_app
    from app.entrypoints.main_api import api  # noqa: F401 - ensures routers are mounted
    from app.entrypoints.main_api import app
    from app.entrypoints.optimizer_service import app as optimizer_app

    register_transport(get_settings().optimizer_url, httpx.ASGITransport(app=optimizer_app))
    register_transport(get_settings().analytics_url, httpx.ASGITransport(app=analytics_app))
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://api.test",
                                 timeout=120) as c:
        yield c


async def _login(client, email, password):
    r = await client.post("/api/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="session")
async def admin(client):
    return await _login(client, "admin@smartshift.ai", "Admin@123")


@pytest.fixture(scope="session")
async def manager(client):
    return await _login(client, "er.manager@smartshift.ai", "Manager@123")


@pytest.fixture(scope="session")
async def icu_manager(client):
    return await _login(client, "icu.manager@smartshift.ai", "Manager@123")


@pytest.fixture
def login(client):
    async def _do(email, password="Employee@123"):
        return await _login(client, email, password)
    return _do
