#!/usr/bin/env bash
# Start every SmartShift AI service locally without Docker.
# Prerequisites: MongoDB running as a replica set (rs0) and Redis on default ports.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/.logs"
cd "$ROOT/backend"
start() {  # start <name> <port>
  nohup python -m uvicorn "app.entrypoints.$1:app" --host 127.0.0.1 --port "$2" > "$ROOT/.logs/$1.log" 2>&1 &
  echo "started: $1 on :$2"
}
start main_api 8000
start optimizer_service 8001
start notification_service 8002
start analytics_service 8003
nohup python -m app.entrypoints.worker > "$ROOT/.logs/worker.log" 2>&1 & echo "started: worker"
cd "$ROOT/frontend"
nohup npm run dev > "$ROOT/.logs/frontend.log" 2>&1 & echo "started: frontend on http://localhost:5173"
echo "Logs: $ROOT/.logs. Stop with: pkill -f 'app.entrypoints' ; pkill -f vite"
