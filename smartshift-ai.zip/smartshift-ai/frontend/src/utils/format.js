export const TZ = 'Asia/Kolkata'
export const WEEKDAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

const inr = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 })
const num = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 1 })

export const fmtMoney = (v) => (v == null ? '—' : inr.format(v))
export const fmtNum = (v) => (v == null ? '—' : num.format(v))
export const fmtPct = (v, d = 1) => (v == null ? '—' : `${Number(v).toFixed(d)}%`)

export function fmtDate(value, opts = { day: 'numeric', month: 'short' }) {
  if (!value) return '—'
  const d = typeof value === 'string' && value.length === 10 ? new Date(`${value}T00:00:00`) : new Date(value)
  return d.toLocaleDateString('en-IN', { ...opts, timeZone: value.length === 10 ? undefined : TZ })
}

export function fmtDateTime(value) {
  if (!value) return '—'
  return new Date(value).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: TZ })
}

export function fmtTime(value) {
  if (!value) return '—'
  return new Date(value).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: TZ })
}

export function relativeTime(value) {
  if (!value) return ''
  const diff = (Date.now() - new Date(value).getTime()) / 1000
  if (diff < 60) return 'just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  return `${Math.floor(diff / 86400)}d ago`
}

export function isoDate(d) {
  const z = new Date(d)
  const y = z.getFullYear()
  const m = String(z.getMonth() + 1).padStart(2, '0')
  const day = String(z.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function addDays(d, n) {
  const x = new Date(d)
  x.setDate(x.getDate() + n)
  return x
}

export function startOfWeek(d = new Date()) {
  const x = new Date(d)
  const wd = (x.getDay() + 6) % 7
  x.setHours(0, 0, 0, 0)
  return addDays(x, -wd)
}

export function initials(name = '') {
  return name.split(' ').filter(Boolean).slice(0, 2).map((p) => p[0]).join('').toUpperCase()
}

export const SHIFT_COLORS = {
  morning: { bg: '#0ea5e9', soft: 'rgba(14,165,233,0.16)', label: 'Morning' },
  evening: { bg: '#8b5cf6', soft: 'rgba(139,92,246,0.16)', label: 'Evening' },
  night: { bg: '#475569', soft: 'rgba(100,116,139,0.22)', label: 'Night' },
}

export const ROLE_LABELS = { super_admin: 'Super Admin', manager: 'Department Manager', employee: 'Employee' }

export function downloadCsv(filename, csv) {
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
