import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { toast } from 'sonner'
import { notifyApi, tokenStore, wsUrl } from '@/services/api'
import { useAuth } from './AuthContext'

const NotificationContext = createContext(null)

export function NotificationProvider({ children }) {
  const { user } = useAuth()
  const [items, setItems] = useState([])
  const [unread, setUnread] = useState(0)
  const [connected, setConnected] = useState(false)
  const [lastEvent, setLastEvent] = useState(null)
  const wsRef = useRef(null)
  const retry = useRef(0)

  const refresh = useCallback(async () => {
    if (!user) return
    try {
      const r = await notifyApi.get('/notifications', { params: { limit: 50 } })
      setItems(r.data.items)
      setUnread(r.data.unread)
    } catch { /* notification service unavailable; UI shows offline indicator */ }
  }, [user])

  useEffect(() => {
    if (!user) { setItems([]); setUnread(0); return undefined }
    refresh()
    let closed = false
    let timer
    const connect = () => {
      const token = tokenStore.get()
      if (!token || closed) return
      const ws = new WebSocket(wsUrl(token))
      wsRef.current = ws
      ws.onopen = () => { setConnected(true); retry.current = 0 }
      ws.onmessage = (ev) => {
        const msg = JSON.parse(ev.data)
        if (msg.kind === 'notification') {
          const n = msg.notification
          setItems((prev) => [n, ...prev].slice(0, 100))
          setUnread((u) => u + 1)
          setLastEvent(n)
          toast(n.title, { description: n.message })
        }
      }
      ws.onclose = () => {
        setConnected(false)
        if (!closed) {
          const delay = Math.min(15000, 1000 * 2 ** retry.current++)
          timer = setTimeout(connect, delay)
        }
      }
    }
    connect()
    const ping = setInterval(() => { if (wsRef.current?.readyState === 1) wsRef.current.send('ping') }, 25000)
    return () => { closed = true; clearTimeout(timer); clearInterval(ping); wsRef.current?.close() }
  }, [user, refresh])

  const markRead = useCallback(async (id) => {
    await notifyApi.post(`/notifications/${id}/read`)
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
    setUnread((u) => Math.max(0, u - 1))
  }, [])

  const markAll = useCallback(async () => {
    await notifyApi.post('/notifications/read-all')
    setItems((prev) => prev.map((n) => ({ ...n, read: true })))
    setUnread(0)
  }, [])

  return (
    <NotificationContext.Provider value={{ items, unread, connected, refresh, markRead, markAll, lastEvent }}>
      {children}
    </NotificationContext.Provider>
  )
}

export const useNotifications = () => useContext(NotificationContext)
