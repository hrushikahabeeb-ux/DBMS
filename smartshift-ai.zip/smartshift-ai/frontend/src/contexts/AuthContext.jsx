import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'
import { api, tokenStore } from '@/services/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [ready, setReady] = useState(false)

  const logout = useCallback(() => {
    tokenStore.clear()
    setUser(null)
  }, [])

  useEffect(() => {
    const onLogout = () => setUser(null)
    window.addEventListener('smartshift:logout', onLogout)
    if (!tokenStore.get()) { setReady(true); return () => window.removeEventListener('smartshift:logout', onLogout) }
    api.get('/auth/me').then((r) => setUser(r.data)).catch(() => tokenStore.clear()).finally(() => setReady(true))
    return () => window.removeEventListener('smartshift:logout', onLogout)
  }, [])

  const login = useCallback(async (email, password) => {
    const r = await api.post('/auth/login', { email, password })
    tokenStore.set(r.data.access_token)
    setUser(r.data.user)
    return r.data.user
  }, [])

  const value = useMemo(() => ({
    user, ready, login, logout,
    isAdmin: user?.role === 'super_admin',
    isManager: user?.role === 'manager' || user?.role === 'super_admin',
    isEmployee: user?.role === 'employee',
  }), [user, ready, login, logout])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
