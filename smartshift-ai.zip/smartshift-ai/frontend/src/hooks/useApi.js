import { useCallback, useEffect, useRef, useState } from 'react'
import { api } from '@/services/api'

/** Fetch helper with loading/error state. `deps` re-trigger the request. */
export function useApi(url, { params, enabled = true, client = api, deps = [] } = {}) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(Boolean(enabled && url))
  const seq = useRef(0)
  const key = JSON.stringify(params || {})

  const load = useCallback(async ({ silent = false } = {}) => {
    if (!enabled || !url) return
    const id = ++seq.current
    if (!silent) setLoading(true)
    setError(null)
    try {
      const r = await client.get(url, { params })
      if (id === seq.current) setData(r.data)
    } catch (e) {
      if (id === seq.current) setError(e)
    } finally {
      if (id === seq.current) setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, key, enabled, ...deps])

  useEffect(() => { load() }, [load])
  return { data, error, loading, reload: load, setData }
}

export function useDebounce(value, delay = 300) {
  const [v, setV] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setV(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])
  return v
}
