import { forwardRef } from 'react'
import * as LabelPrimitive from '@radix-ui/react-label'
import * as SwitchPrimitive from '@radix-ui/react-switch'
import * as CheckboxPrimitive from '@radix-ui/react-checkbox'
import * as ProgressPrimitive from '@radix-ui/react-progress'
import * as SeparatorPrimitive from '@radix-ui/react-separator'
import * as TooltipPrimitive from '@radix-ui/react-tooltip'
import * as TabsPrimitive from '@radix-ui/react-tabs'
import * as PopoverPrimitive from '@radix-ui/react-popover'
import { cva } from 'class-variance-authority'
import { Check } from 'lucide-react'
import { cn } from '@/utils/cn'

/* ---------- Card ---------- */
export const Card = forwardRef(({ className, ...p }, ref) => (
  <div ref={ref} className={cn('rounded-xl border bg-card text-card-foreground shadow-card', className)} {...p} />
))
export const CardHeader = ({ className, ...p }) => <div className={cn('flex flex-col gap-1 p-5 pb-3', className)} {...p} />
export const CardTitle = ({ className, ...p }) => <h3 className={cn('text-sm font-semibold tracking-tight', className)} {...p} />
export const CardDescription = ({ className, ...p }) => <p className={cn('text-xs text-muted-foreground', className)} {...p} />
export const CardContent = ({ className, ...p }) => <div className={cn('p-5 pt-0', className)} {...p} />

/* ---------- Badge ---------- */
const badgeVariants = cva('inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-medium transition-colors', {
  variants: {
    variant: {
      default: 'border-primary/30 bg-primary/10 text-primary',
      secondary: 'border-transparent bg-secondary text-secondary-foreground',
      success: 'border-success/30 bg-success/10 text-success',
      warning: 'border-warning/30 bg-warning/10 text-warning',
      destructive: 'border-destructive/30 bg-destructive/10 text-destructive',
      info: 'border-info/30 bg-info/10 text-info',
      outline: 'text-muted-foreground',
      violet: 'border-accent/30 bg-accent/10 text-accent',
    },
  },
  defaultVariants: { variant: 'default' },
})
export const Badge = ({ className, variant, ...p }) => <span className={cn(badgeVariants({ variant }), className)} {...p} />

/* ---------- Inputs ---------- */
export const Input = forwardRef(({ className, ...p }, ref) => (
  <input ref={ref} className={cn('flex h-9 w-full rounded-lg border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50 aria-[invalid=true]:border-destructive', className)} {...p} />
))
export const Textarea = forwardRef(({ className, ...p }, ref) => (
  <textarea ref={ref} className={cn('flex min-h-[80px] w-full rounded-lg border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring', className)} {...p} />
))
export const NativeSelect = forwardRef(({ className, children, ...p }, ref) => (
  <select ref={ref} className={cn('flex h-9 w-full rounded-lg border border-input bg-card px-3 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50', className)} {...p}>{children}</select>
))
export const Label = forwardRef(({ className, ...p }, ref) => (
  <LabelPrimitive.Root ref={ref} className={cn('text-xs font-medium text-muted-foreground', className)} {...p} />
))
export function Field({ label, error, hint, children, className }) {
  return (
    <div className={cn('space-y-1.5', className)}>
      {label && <Label>{label}</Label>}
      {children}
      {error ? <p className="text-xs text-destructive">{error}</p> : hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}
    </div>
  )
}

export const Switch = forwardRef(({ className, ...p }, ref) => (
  <SwitchPrimitive.Root ref={ref} className={cn('peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input', className)} {...p}>
    <SwitchPrimitive.Thumb className="pointer-events-none block h-4 w-4 rounded-full bg-white shadow-lg transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0" />
  </SwitchPrimitive.Root>
))

export const Checkbox = forwardRef(({ className, ...p }, ref) => (
  <CheckboxPrimitive.Root ref={ref} className={cn('peer h-4 w-4 shrink-0 rounded border border-input shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring data-[state=checked]:border-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground', className)} {...p}>
    <CheckboxPrimitive.Indicator className="flex items-center justify-center text-current"><Check className="h-3 w-3" /></CheckboxPrimitive.Indicator>
  </CheckboxPrimitive.Root>
))

export const Progress = ({ className, value = 0, indicatorClassName, ...p }) => (
  <ProgressPrimitive.Root className={cn('relative h-2 w-full overflow-hidden rounded-full bg-secondary', className)} value={value} {...p}>
    <ProgressPrimitive.Indicator className={cn('h-full w-full flex-1 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-transform duration-500', indicatorClassName)} style={{ transform: `translateX(-${100 - Math.min(100, Math.max(0, value))}%)` }} />
  </ProgressPrimitive.Root>
)

export const Separator = ({ className, orientation = 'horizontal', ...p }) => (
  <SeparatorPrimitive.Root orientation={orientation} className={cn('shrink-0 bg-border', orientation === 'horizontal' ? 'h-px w-full' : 'h-full w-px', className)} {...p} />
)

export const Skeleton = ({ className, ...p }) => (
  <div className={cn('relative overflow-hidden rounded-md bg-muted before:absolute before:inset-0 before:-translate-x-full before:animate-shimmer before:bg-gradient-to-r before:from-transparent before:via-foreground/5 before:to-transparent', className)} {...p} />
)

/* ---------- Tooltip ---------- */
export const TooltipProvider = TooltipPrimitive.Provider
export function Tooltip({ content, children, side = 'top' }) {
  if (!content) return children
  return (
    <TooltipPrimitive.Root delayDuration={150}>
      <TooltipPrimitive.Trigger asChild>{children}</TooltipPrimitive.Trigger>
      <TooltipPrimitive.Portal>
        <TooltipPrimitive.Content side={side} sideOffset={6} className="z-50 max-w-xs rounded-md border bg-popover px-2.5 py-1.5 text-xs text-popover-foreground shadow-md animate-in fade-in-0 zoom-in-95">
          {content}
        </TooltipPrimitive.Content>
      </TooltipPrimitive.Portal>
    </TooltipPrimitive.Root>
  )
}

/* ---------- Tabs ---------- */
export const Tabs = TabsPrimitive.Root
export const TabsList = ({ className, ...p }) => (
  <TabsPrimitive.List className={cn('inline-flex h-9 items-center gap-1 rounded-lg bg-secondary p-1 text-muted-foreground', className)} {...p} />
)
export const TabsTrigger = ({ className, ...p }) => (
  <TabsPrimitive.Trigger className={cn('inline-flex items-center gap-1.5 whitespace-nowrap rounded-md px-3 py-1 text-xs font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50 data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow [&_svg]:size-3.5', className)} {...p} />
)
export const TabsContent = ({ className, ...p }) => (
  <TabsPrimitive.Content className={cn('mt-4 focus-visible:outline-none', className)} {...p} />
)

/* ---------- Popover ---------- */
export const Popover = PopoverPrimitive.Root
export const PopoverTrigger = PopoverPrimitive.Trigger
export const PopoverContent = ({ className, align = 'end', ...p }) => (
  <PopoverPrimitive.Portal>
    <PopoverPrimitive.Content align={align} sideOffset={8} className={cn('z-50 rounded-xl border bg-popover p-0 text-popover-foreground shadow-xl outline-none animate-in fade-in-0 zoom-in-95', className)} {...p} />
  </PopoverPrimitive.Portal>
)

/* ---------- Table ---------- */
export const Table = ({ className, ...p }) => (
  <div className="relative w-full overflow-auto"><table className={cn('w-full caption-bottom text-sm', className)} {...p} /></div>
)
export const THead = ({ className, ...p }) => <thead className={cn('[&_tr]:border-b', className)} {...p} />
export const TBody = ({ className, ...p }) => <tbody className={cn('[&_tr:last-child]:border-0', className)} {...p} />
export const TR = ({ className, ...p }) => <tr className={cn('border-b transition-colors hover:bg-muted/40', className)} {...p} />
export const TH = ({ className, ...p }) => <th className={cn('h-10 px-3 text-left align-middle text-[11px] font-semibold uppercase tracking-wider text-muted-foreground', className)} {...p} />
export const TD = ({ className, ...p }) => <td className={cn('px-3 py-2.5 align-middle', className)} {...p} />
