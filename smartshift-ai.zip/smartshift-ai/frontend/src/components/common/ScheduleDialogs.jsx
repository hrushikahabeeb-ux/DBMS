import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { BrainCircuit, Lock, Siren, Sparkles, Trash2, Unlock, UserPlus, Wand2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Separator, Skeleton } from '@/components/ui/primitives'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/overlay'
import { Avatar, CheckList, StatusBadge } from '@/components/common'
import { api, errorMessage } from '@/services/api'
import { fmtDate, fmtMoney, fmtTime } from '@/utils/format'

export function ExplainPanel({ assignmentId }) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  useEffect(() => {
    setData(null); setError(null)
    api.get(`/assignments/${assignmentId}/explain`).then((r) => setData(r.data)).catch(setError)
  }, [assignmentId])
  if (error) return <p className="text-xs text-destructive">{error.message}</p>
  if (!data) return <Skeleton className="h-40" />
  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-primary/25 bg-primary/5 p-3">
        <p className="mb-1 flex items-center gap-1.5 text-xs font-semibold text-primary"><BrainCircuit className="h-3.5 w-3.5" /> Why was this employee assigned?</p>
        <p className="text-[13px] leading-relaxed">{data.summary}</p>
        <p className="mt-2 text-[11px] text-muted-foreground">Source: <span className="capitalize">{data.source}</span>{data.run?.preset ? ` · ${data.run.preset} preset` : ''}{data.run?.solver_status ? ` · solver ${data.run.solver_status}` : ''}</p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Hard constraint checks</p><CheckList checks={data.checks} /></div>
        <div>
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Preferences</p>
          <CheckList checks={data.preferences} />
          <p className="mb-2 mt-4 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Objective factors weighed</p>
          <ul className="space-y-1.5 text-xs">{data.objective_factors.map((f) => <li key={f.term}><Badge variant="outline" className="mr-1.5 capitalize">{f.term}</Badge>{f.detail}</li>)}</ul>
        </div>
      </div>
      <p className="text-[11px] text-muted-foreground">{data.note}</p>
    </div>
  )
}

export function AssignmentDialog({ assignment, shift, open, onOpenChange, onChanged, canManage }) {
  const navigate = useNavigate()
  const [busy, setBusy] = useState('')
  if (!assignment) return null
  const act = async (key, fn, msg) => {
    setBusy(key)
    try { await fn(); toast.success(msg); onChanged?.(); onOpenChange(false) } catch (e) { toast.error(errorMessage(e)) } finally { setBusy('') }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="lg">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <Avatar name={assignment.employee?.full_name} className="h-10 w-10" />
            <div>
              <DialogTitle>{assignment.employee?.full_name}</DialogTitle>
              <DialogDescription>{shift?.department?.name} · {shift?.name} · {fmtDate(assignment.start, { weekday: 'long', day: 'numeric', month: 'short' })} · {fmtTime(assignment.start)}–{fmtTime(assignment.end)}</DialogDescription>
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5 pt-1"><StatusBadge status={assignment.status} /><Badge variant="secondary" className="capitalize">{assignment.source}</Badge>{assignment.locked && <Badge variant="warning"><Lock className="h-3 w-3" /> Locked</Badge>}<StatusBadge status={shift?.schedule?.status} /></div>
        </DialogHeader>
        {assignment.status === 'active' && canManage ? <ExplainPanel assignmentId={assignment.id} /> : assignment.status === 'absent' && <p className="text-sm text-destructive">Marked absent{assignment.absence_reason ? `: ${assignment.absence_reason}` : ''}. Assign cover from Emergency Replacement.</p>}
        {canManage && (
          <DialogFooter className="flex-wrap">
            {assignment.status === 'active' && <>
              <Button variant="outline" size="sm" loading={busy === 'lock'} onClick={() => act('lock', () => api.patch(`/assignments/${assignment.id}`, { locked: !assignment.locked }), assignment.locked ? 'Assignment unlocked' : 'Assignment locked; the optimizer will preserve it')}>{assignment.locked ? <><Unlock /> Unlock</> : <><Lock /> Lock</>}</Button>
              <Button variant="outline" size="sm" loading={busy === 'del'} onClick={() => act('del', () => api.delete(`/assignments/${assignment.id}`), 'Assignment removed')}><Trash2 /> Remove</Button>
              <Button variant="destructive" size="sm" onClick={() => navigate(`/emergency?assignment=${assignment.id}`)}><Siren /> Mark absent</Button>
            </>}
            {assignment.status === 'absent' && <Button size="sm" onClick={() => navigate(`/emergency?assignment=${assignment.id}`)}><Siren /> Find replacement</Button>}
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  )
}

export function ShiftDialog({ shift, assignments = [], open, onOpenChange, onChanged }) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [busy, setBusy] = useState('')
  const [showRejected, setShowRejected] = useState(false)
  const load = () => { setData(null); setError(null); api.get(`/shifts/${shift.id}/candidates`).then((r) => setData(r.data)).catch(setError) }
  useEffect(() => { if (open && shift) load() }, [open, shift?.id, shift?.assigned_count]) // eslint-disable-line react-hooks/exhaustive-deps
  if (!shift) return null
  const assigned = assignments.filter((a) => a.shift_id === shift.id && a.status === 'active')
  const full = assigned.length >= shift.required_staff
  const assign = async (employeeId, label) => {
    setBusy(employeeId)
    try {
      await api.post('/assignments', { shift_id: shift.id, employee_id: employeeId })
      toast.success(`${label} assigned`, { description: 'Validated against every hard constraint.' })
      onChanged?.()
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy('') }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="xl">
        <DialogHeader>
          <DialogTitle>{shift.department?.name} · {shift.name} shift</DialogTitle>
          <DialogDescription>{fmtDate(shift.start, { weekday: 'long', day: 'numeric', month: 'long' })} · {fmtTime(shift.start)}–{fmtTime(shift.end)} · <span className="num">{assigned.length}/{shift.required_staff}</span> staff</DialogDescription>
          <div className="flex flex-wrap gap-1.5 pt-1">
            <StatusBadge status={shift.schedule?.status} />
            {shift.required_skills?.map((s) => <Badge key={s} variant="outline">requires {s}</Badge>)}
            {shift.skill_mix?.map((m) => <Badge key={m.skill} variant="violet">at least {m.min} x {m.skill}</Badge>)}
          </div>
        </DialogHeader>
        <div className="grid gap-5 lg:grid-cols-[1fr_1.4fr]">
          <div>
            <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Assigned</p>
            {assigned.length === 0 ? <p className="text-xs text-muted-foreground">Nobody assigned yet.</p> : (
              <div className="space-y-1.5">{assigned.map((a) => (
                <div key={a.id} className="flex items-center gap-2 rounded-lg border px-3 py-2"><Avatar name={a.employee?.full_name} className="h-7 w-7 text-[10px]" /><div className="text-xs"><p className="font-medium">{a.employee?.full_name}</p><p className="text-muted-foreground">{a.employee?.job_role}</p></div>{a.locked && <Lock className="ml-auto h-3.5 w-3.5 text-warning" />}</div>
              ))}</div>
            )}
          </div>
          <div>
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Eligible employees (ranked)</p>
              {data?.candidates?.length > 0 && !full && <Button size="sm" variant="gradient" loading={busy === 'auto'} onClick={async () => { setBusy('auto'); await assign(data.candidates[0].employee_id, data.candidates[0].name) }}><Wand2 /> Auto-assign best</Button>}
            </div>
            {error && <p className="text-xs text-destructive">{error.message}</p>}
            {!data && !error && <Skeleton className="h-40" />}
            {data && (
              <div className="max-h-80 space-y-1.5 overflow-y-auto pr-1">
                {data.candidates.length === 0 && <p className="rounded-lg border border-warning/30 bg-warning/5 p-3 text-xs text-warning">No additional employee satisfies every hard constraint for this shift.</p>}
                {data.candidates.map((c) => (
                  <div key={c.employee_id} className="flex items-center justify-between gap-2 rounded-lg border px-3 py-2">
                    <div className="min-w-0 text-xs">
                      <p className="font-medium">#{c.rank} {c.name} <span className="num text-muted-foreground">· score {c.score}</span></p>
                      <p className="num text-muted-foreground">{c.week_hours_after}h / {c.max_weekly_hours}h after · {fmtMoney(c.hourly_wage)}/h</p>
                    </div>
                    <Button size="sm" variant="outline" disabled={full} loading={busy === c.employee_id} onClick={() => assign(c.employee_id, c.name)}><UserPlus /> Assign</Button>
                  </div>
                ))}
                {data.rejected.length > 0 && (
                  <div className="pt-2">
                    <button className="text-xs text-muted-foreground underline-offset-2 hover:underline" onClick={() => setShowRejected((s) => !s)}>{showRejected ? 'Hide' : 'Show'} {data.rejected.length} ineligible employee(s) and why</button>
                    {showRejected && data.rejected.map((r) => (
                      <div key={r.employee_id} className="mt-1.5 rounded-lg bg-secondary/60 px-3 py-2 text-xs"><p className="font-medium">{r.name}</p><p className="text-destructive">{r.reasons.join('; ')}</p></div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        {full && <><Separator /><p className="flex items-center gap-1.5 text-xs text-success"><Sparkles className="h-3.5 w-3.5" /> This shift meets its staffing requirement.</p></>}
      </DialogContent>
    </Dialog>
  )
}
