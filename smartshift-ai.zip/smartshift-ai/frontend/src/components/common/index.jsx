import { useState } from 'react'
import { motion } from 'framer-motion'
import { AlertTriangle, Check, ChevronLeft, ChevronRight, Inbox, Minus, RefreshCw, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, Skeleton } from '@/components/ui/primitives'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/overlay'
import { cn } from '@/utils/cn'
import { initials } from '@/utils/format'

export function PageHeader({ title, description, icon: Icon, actions, eyebrow }) {
  return (
    <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="flex items-start gap-3">
        {Icon && (
          <div className="mt-0.5 flex h-10 w-10 items-center justify-center rounded-xl border border-primary/20 bg-gradient-to-br from-indigo-500/20 to-violet-500/10 text-primary">
            <Icon className="h-5 w-5" />
          </div>
        )}
        <div>
          {eyebrow && <p className="mb-0.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">{eyebrow}</p>}
          <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">{title}</h1>
          {description && <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{description}</p>}
        </div>
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function StatCard({ label, value, icon: Icon, hint, tone = 'primary', loading, delay = 0 }) {
  const tones = {
    primary: 'from-indigo-500/20 to-indigo-500/0 text-indigo-400',
    violet: 'from-violet-500/20 to-violet-500/0 text-violet-400',
    success: 'from-emerald-500/20 to-emerald-500/0 text-emerald-400',
    warning: 'from-amber-500/20 to-amber-500/0 text-amber-400',
    danger: 'from-rose-500/20 to-rose-500/0 text-rose-400',
    info: 'from-sky-500/20 to-sky-500/0 text-sky-400',
  }
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay, duration: 0.3 }}>
      <Card className="group relative overflow-hidden p-4 transition-colors hover:border-primary/30">
        <div className={cn('pointer-events-none absolute -right-6 -top-6 h-24 w-24 rounded-full bg-gradient-to-br blur-2xl', tones[tone])} />
        <div className="flex items-start justify-between">
          <p className="text-xs font-medium text-muted-foreground">{label}</p>
          {Icon && <Icon className={cn('h-4 w-4', tones[tone].split(' ').pop())} />}
        </div>
        {loading ? <Skeleton className="mt-3 h-7 w-20" /> : <p className="num mt-2 text-2xl font-semibold">{value ?? '—'}</p>}
        {hint && <p className="mt-1 text-[11px] text-muted-foreground">{hint}</p>}
      </Card>
    </motion.div>
  )
}

export function EmptyState({ icon: Icon = Inbox, title, description, action, className }) {
  return (
    <div className={cn('flex flex-col items-center justify-center rounded-xl border border-dashed px-6 py-12 text-center', className)}>
      <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-full bg-secondary text-muted-foreground"><Icon className="h-5 w-5" /></div>
      <p className="text-sm font-medium">{title}</p>
      {description && <p className="mt-1 max-w-sm text-xs text-muted-foreground">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function ErrorState({ error, onRetry, className }) {
  return (
    <div className={cn('flex flex-col items-center justify-center rounded-xl border border-destructive/30 bg-destructive/5 px-6 py-10 text-center', className)}>
      <AlertTriangle className="mb-2 h-6 w-6 text-destructive" />
      <p className="text-sm font-medium">Something went wrong</p>
      <p className="mt-1 max-w-md text-xs text-muted-foreground">{error?.message || 'Unknown error'}</p>
      {error?.correlationId && <p className="num mt-1 text-[10px] text-muted-foreground">ref {error.correlationId}</p>}
      {onRetry && <Button variant="outline" size="sm" className="mt-4" onClick={() => onRetry()}><RefreshCw /> Retry</Button>}
    </div>
  )
}

export function LoadingRows({ rows = 6, className }) {
  return (
    <div className={cn('space-y-2', className)}>
      {Array.from({ length: rows }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
    </div>
  )
}

export function Pagination({ page, pages, total, onPage }) {
  if (!pages || pages <= 1) return <p className="text-xs text-muted-foreground">{total ?? 0} records</p>
  return (
    <div className="flex items-center justify-between gap-2">
      <p className="text-xs text-muted-foreground">{total} records · page {page} of {pages}</p>
      <div className="flex gap-1">
        <Button variant="outline" size="icon-sm" disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label="Previous page"><ChevronLeft /></Button>
        <Button variant="outline" size="icon-sm" disabled={page >= pages} onClick={() => onPage(page + 1)} aria-label="Next page"><ChevronRight /></Button>
      </div>
    </div>
  )
}

const STATUS = {
  active: 'success', inactive: 'secondary', draft: 'warning', published: 'success', archived: 'secondary',
  pending: 'warning', approved: 'success', rejected: 'destructive', cancelled: 'secondary', declined: 'destructive',
  pending_peer: 'warning', peer_accepted: 'info', absent: 'destructive', replaced: 'violet', queued: 'secondary',
  running: 'info', completed: 'success', failed: 'destructive', high: 'destructive', medium: 'warning', low: 'secondary',
  SUCCESS: 'success', PARTIAL: 'warning', INFEASIBLE: 'destructive', OPTIMAL: 'success', FEASIBLE: 'info',
}
export function StatusBadge({ status, className }) {
  if (!status) return null
  return <Badge variant={STATUS[status] || 'outline'} className={className}>{String(status).replace(/_/g, ' ')}</Badge>
}

export function Avatar({ name, className }) {
  const hue = [...(name || '')].reduce((a, c) => a + c.charCodeAt(0), 0) % 360
  return (
    <div className={cn('flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[11px] font-semibold text-white', className)}
      style={{ background: `linear-gradient(135deg, hsl(${hue} 70% 55%), hsl(${(hue + 40) % 360} 70% 45%))` }} aria-hidden>
      {initials(name)}
    </div>
  )
}

export function ConfirmDialog({ open, onOpenChange, title, description, confirmLabel = 'Confirm', variant = 'default', onConfirm, children }) {
  const [busy, setBusy] = useState(false)
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="sm">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        {children}
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button variant={variant} loading={busy} onClick={async () => {
            setBusy(true)
            try { await onConfirm() ; onOpenChange(false) } finally { setBusy(false) }
          }}>{confirmLabel}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

export function ChartCard({ title, description, children, actions, className }) {
  return (
    <Card className={cn('flex flex-col', className)}>
      <div className="flex items-start justify-between gap-2 p-5 pb-2">
        <div>
          <h3 className="text-sm font-semibold tracking-tight">{title}</h3>
          {description && <p className="mt-0.5 text-xs text-muted-foreground">{description}</p>}
        </div>
        {actions}
      </div>
      <div className="flex-1 px-3 pb-4">{children}</div>
    </Card>
  )
}

export function CheckList({ checks = [] }) {
  return (
    <ul className="space-y-1.5">
      {checks.map((c) => (
        <li key={c.code} className="flex items-start gap-2 text-xs">
          <span className={cn('mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[10px] font-bold',
            c.passed ? 'bg-success/15 text-success' : c.severity === 'info' ? 'bg-warning/15 text-warning' : 'bg-destructive/15 text-destructive')}>
            {c.passed ? <Check className="h-3 w-3" /> : c.severity === 'info' ? <Minus className="h-3 w-3" /> : <X className="h-3 w-3" />}
          </span>
          <span className={cn(!c.passed && c.severity !== 'info' && 'text-destructive')}>{c.message}</span>
        </li>
      ))}
    </ul>
  )
}
