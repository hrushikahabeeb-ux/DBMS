import { useTheme } from '@/contexts/ThemeContext'

export const PALETTE = ['#818cf8', '#a78bfa', '#38bdf8', '#34d399', '#fbbf24', '#f472b6', '#fb7185', '#2dd4bf']

export function useChartTheme() {
  const { theme } = useTheme()
  const dark = theme === 'dark'
  return {
    grid: dark ? 'rgba(148,163,184,0.12)' : 'rgba(15,23,42,0.08)',
    axis: dark ? '#94a3b8' : '#64748b',
    tooltip: {
      contentStyle: {
        background: dark ? '#111827' : '#ffffff',
        border: `1px solid ${dark ? '#1f2a44' : '#e2e8f0'}`,
        borderRadius: 10,
        fontSize: 12,
        boxShadow: '0 10px 30px -10px rgba(0,0,0,0.5)',
      },
      labelStyle: { color: dark ? '#e2e8f0' : '#0f172a', fontWeight: 600 },
      itemStyle: { color: dark ? '#cbd5e1' : '#334155' },
      cursor: { fill: dark ? 'rgba(129,140,248,0.08)' : 'rgba(99,102,241,0.06)' },
    },
  }
}

export const axisProps = (t) => ({ stroke: t.axis, tick: { fontSize: 11, fill: t.axis }, tickLine: false, axisLine: false })
