import { Tooltip } from '@/components/ui/primitives'
import { fmtDate } from '@/utils/format'

function color(pct) {
  if (pct == null) return 'hsl(var(--muted))'
  if (pct >= 100) return 'hsl(158 64% 42% / 0.85)'
  if (pct >= 85) return 'hsl(158 64% 42% / 0.45)'
  if (pct >= 60) return 'hsl(38 92% 50% / 0.65)'
  if (pct > 0) return 'hsl(350 80% 58% / 0.7)'
  return 'hsl(350 80% 58% / 0.9)'
}

/** cells: [{date, template_code, required, filled, coverage_pct}] */
export default function CoverageHeatmap({ cells = [], codes = ['morning', 'evening', 'night'] }) {
  const dates = [...new Set(cells.map((c) => c.date))].sort()
  const map = new Map(cells.map((c) => [`${c.date}|${c.template_code}`, c]))
  const allCodes = [...new Set([...codes, ...cells.map((c) => c.template_code)])].filter((c) => cells.some((x) => x.template_code === c))
  if (!dates.length) return <p className="py-8 text-center text-xs text-muted-foreground">No shifts in this range.</p>
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-separate" style={{ borderSpacing: 4 }}>
        <thead>
          <tr>
            <th className="w-20" />
            {dates.map((d) => (
              <th key={d} className="text-center text-[10px] font-medium text-muted-foreground">
                {fmtDate(d, { weekday: 'short' })}<br /><span className="num">{fmtDate(d, { day: 'numeric', month: 'short' })}</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {allCodes.map((code) => (
            <tr key={code}>
              <td className="pr-2 text-right text-[11px] font-medium capitalize text-muted-foreground">{code}</td>
              {dates.map((d) => {
                const c = map.get(`${d}|${code}`)
                return (
                  <td key={d}>
                    <Tooltip content={c ? `${c.filled}/${c.required} staff · ${c.coverage_pct}%` : 'No shift'}>
                      <div className="num flex h-9 min-w-[44px] items-center justify-center rounded-md text-[11px] font-semibold text-white transition hover:scale-[1.04]" style={{ background: color(c?.coverage_pct) }}>
                        {c ? `${c.filled}/${c.required}` : ''}
                      </div>
                    </Tooltip>
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-2 flex flex-wrap items-center gap-3 px-1 text-[10px] text-muted-foreground">
        {[['Full', 100], ['85%+', 90], ['60%+', 70], ['Under 60%', 30]].map(([l, v]) => (
          <span key={l} className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: color(v) }} />{l}</span>
        ))}
      </div>
    </div>
  )
}
