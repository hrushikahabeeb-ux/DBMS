import { useEffect, useState } from 'react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Checkbox, Field, Input, Label, NativeSelect } from '@/components/ui/primitives'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/overlay'
import { api, errorMessage, fieldErrors } from '@/services/api'

const EMPTY = {
  employee_code: '', full_name: '', email: '', primary_department_id: '', department_ids: [], job_role: '', skills: '',
  max_weekly_hours: 40, preferred_shifts: [], hourly_wage: 500, joining_date: new Date().toISOString().slice(0, 10), create_login: true,
}

export default function EmployeeForm({ open, onOpenChange, employee, departments = [], onSaved }) {
  const editing = Boolean(employee)
  const [form, setForm] = useState(EMPTY)
  const [errors, setErrors] = useState({})
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!open) return
    setErrors({})
    setForm(employee ? { ...EMPTY, ...employee, skills: employee.skills.join(', ') } : { ...EMPTY, primary_department_id: departments[0]?.id || '' })
  }, [open, employee, departments.length]) // eslint-disable-line react-hooks/exhaustive-deps

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))
  const toggle = (k, v) => setForm((f) => ({ ...f, [k]: f[k].includes(v) ? f[k].filter((x) => x !== v) : [...f[k], v] }))

  const validate = () => {
    const e = {}
    if (!editing && !/^[A-Z]{2,4}-\d{3,5}$/.test(form.employee_code)) e.employee_code = 'Format: ABC-123'
    if (form.full_name.trim().length < 2) e.full_name = 'Enter the full name'
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) e.email = 'Enter a valid email'
    if (!form.primary_department_id) e.primary_department_id = 'Select a department'
    if (form.job_role.trim().length < 2) e.job_role = 'Enter a job role'
    if (form.max_weekly_hours < 4 || form.max_weekly_hours > 80) e.max_weekly_hours = 'Between 4 and 80 hours'
    if (form.hourly_wage < 0) e.hourly_wage = 'Cannot be negative'
    setErrors(e)
    return !Object.keys(e).length
  }

  const submit = async (ev) => {
    ev.preventDefault()
    if (!validate()) return
    setBusy(true)
    const payload = {
      full_name: form.full_name.trim(), email: form.email.trim(), primary_department_id: form.primary_department_id,
      department_ids: form.department_ids, job_role: form.job_role.trim(),
      skills: form.skills.split(',').map((s) => s.trim()).filter(Boolean),
      max_weekly_hours: Number(form.max_weekly_hours), preferred_shifts: form.preferred_shifts,
      hourly_wage: Number(form.hourly_wage), joining_date: form.joining_date,
    }
    try {
      if (editing) {
        await api.patch(`/employees/${employee.id}`, payload)
        toast.success('Employee updated')
      } else {
        const r = await api.post('/employees', { ...payload, employee_code: form.employee_code, create_login: form.create_login })
        toast.success('Employee created', { description: r.data.initial_password ? `Login created. Initial password: ${r.data.initial_password}` : undefined, duration: 10000 })
      }
      onSaved?.()
      onOpenChange(false)
    } catch (err) {
      setErrors(fieldErrors(err))
      toast.error(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="lg">
        <DialogHeader>
          <DialogTitle>{editing ? `Edit ${employee.full_name}` : 'Add employee'}</DialogTitle>
          <DialogDescription>Qualifications, eligibility and contract limits are enforced by the scheduler.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2" noValidate>
          {!editing && <Field label="Employee ID" error={errors.employee_code}><Input value={form.employee_code} onChange={(e) => set('employee_code', e.target.value.toUpperCase())} placeholder="EMP-031" aria-invalid={!!errors.employee_code} /></Field>}
          <Field label="Full name" error={errors.full_name}><Input value={form.full_name} onChange={(e) => set('full_name', e.target.value)} aria-invalid={!!errors.full_name} /></Field>
          <Field label="Email" error={errors.email}><Input type="email" value={form.email} onChange={(e) => set('email', e.target.value)} aria-invalid={!!errors.email} /></Field>
          <Field label="Job role" error={errors.job_role}><Input value={form.job_role} onChange={(e) => set('job_role', e.target.value)} placeholder="Registered Nurse" aria-invalid={!!errors.job_role} /></Field>
          <Field label="Primary department" error={errors.primary_department_id}>
            <NativeSelect value={form.primary_department_id} onChange={(e) => set('primary_department_id', e.target.value)}>
              <option value="">Select...</option>
              {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </NativeSelect>
          </Field>
          <Field label="Also eligible for" hint="Cross-trained departments">
            <div className="flex flex-wrap gap-3 pt-1.5">
              {departments.filter((d) => d.id !== form.primary_department_id).map((d) => (
                <label key={d.id} className="flex items-center gap-1.5 text-xs"><Checkbox checked={form.department_ids.includes(d.id)} onCheckedChange={() => toggle('department_ids', d.id)} /> {d.name}</label>
              ))}
            </div>
          </Field>
          <Field label="Skills and qualifications" hint="Comma separated, e.g. BLS, ACLS, Triage" className="sm:col-span-2"><Input value={form.skills} onChange={(e) => set('skills', e.target.value)} /></Field>
          <Field label="Max weekly hours" error={errors.max_weekly_hours}><Input type="number" min={4} max={80} value={form.max_weekly_hours} onChange={(e) => set('max_weekly_hours', e.target.value)} /></Field>
          <Field label="Hourly wage (INR)" error={errors.hourly_wage}><Input type="number" min={0} value={form.hourly_wage} onChange={(e) => set('hourly_wage', e.target.value)} /></Field>
          <Field label="Joining date"><Input type="date" value={form.joining_date} onChange={(e) => set('joining_date', e.target.value)} /></Field>
          <Field label="Preferred shifts">
            <div className="flex gap-3 pt-1.5">
              {['morning', 'evening', 'night'].map((c) => (
                <label key={c} className="flex items-center gap-1.5 text-xs capitalize"><Checkbox checked={form.preferred_shifts.includes(c)} onCheckedChange={() => toggle('preferred_shifts', c)} /> {c}</label>
              ))}
            </div>
          </Field>
          {!editing && (
            <div className="flex items-center gap-2 sm:col-span-2">
              <Checkbox id="login" checked={form.create_login} onCheckedChange={(v) => set('create_login', Boolean(v))} />
              <Label htmlFor="login" className="text-foreground">Create an employee login (initial password is shown once)</Label>
            </div>
          )}
          <DialogFooter className="sm:col-span-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" loading={busy}>{editing ? 'Save changes' : 'Create employee'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
