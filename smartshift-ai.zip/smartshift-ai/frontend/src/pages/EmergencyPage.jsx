import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { toast } from 'sonner'
import { AlertOctagon, CheckCircle2, ChevronDown, Medal, Search, ShieldCheck, Siren, UserCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, CardContent, CardHeader, CardTitle, Field, Input, NativeSelect, Progress, Skeleton, Textarea } from '@/components/ui/primitives'
import { Avatar, CheckList, EmptyState, ErrorState, PageHeader } from '@/components/common'
import { useApi } from '@/hooks/useApi'
import { useNotifications } from '@/contexts/NotificationContext'
import { api, errorMessage } from '@/services/api'
import { addDays, fmtDate, fmtMoney, fmtTime, isoDate } from '@/utils/format'
import { cn } from '@/utils/cn'

export default function EmergencyPage() {
  const [params] = useSearchParams()
  const { lastEvent } = useNotifications()
  const vacancies = useApi('/emergency/vacancies')
  const [selected, setSelected] = useState(params.get('assignment'))
  useEffect(() => { if (lastEvent) vacancies.reload({ silent: true }) }, [lastEvent]) // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <>
      <PageHeader icon={Siren} eyebrow="Workforce recovery" title="Emergency Replacement"
        description="When someone becomes unavailable, SmartShift checks every colleague against availability, qualifications, existing assignments, weekly limits and rest periods, then ranks valid replacements with a transparent, deterministic score." />
      <div className="grid gap-4 xl:grid-cols-[380px_1fr]">
        <div className="space-y-4">
          <MarkAbsent preselect={params.get('assignment')} onMarked={(id) => { setSelected(id); vacancies.reload({ silent: true }) }} />
          <Card>
            <CardHeader><CardTitle>Open absences</CardTitle><p className="text-xs text-muted-foreground">Upcoming shifts that still need cover</p></CardHeader>
            <CardContent className="space-y-2">
              {vacancies.error && <ErrorState error={vacancies.error} onRetry={vacancies.reload} />}
              {vacancies.loading && !vacancies.data && <Skeleton className="h-24" />}
              {vacancies.data?.length === 0 && <EmptyState icon={CheckCircle2} title="No open absences" description="Every absence has been covered." className="py-6" />}
              {vacancies.data?.map((v) => (
                <button key={v.id} onClick={() => setSelected(v.id)} className={cn('w-full rounded-lg border p-3 text-left transition hover:border-destructive/40', selected === v.id && 'border-destructive/50 bg-destructive/5')}>
                  <div className="flex items-center justify-between"><p className="text-sm font-medium">{v.department.name} · {v.shift.name}</p><Badge variant="destructive">Uncovered</Badge></div>
                  <p className="num text-xs text-muted-foreground">{fmtDate(v.start, { weekday: 'short', day: 'numeric', month: 'short' })} · {fmtTime(v.start)}–{fmtTime(v.end)}</p>
                  <p className="mt-1 text-xs">Absent: {v.employee.full_name} <span className="text-muted-foreground">({v.absence_reason})</span></p>
                </button>
              ))}
            </CardContent>
          </Card>
        </div>
        <div>
          {selected ? <Candidates assignmentId={selected} onResolved={() => { vacancies.reload({ silent: true }) }} /> : (
            <EmptyState icon={Siren} title="Select an absence" description="Mark an employee absent or pick an open absence to see ranked replacement candidates." className="h-full min-h-[400px]" />
          )}
        </div>
      </div>
    </>
  )
}

function MarkAbsent({ preselect, onMarked }) {
  const depts = useApi('/departments')
  const [dept, setDept] = useState('')
  const [q, setQ] = useState('')
  const [assignment, setAssignment] = useState(preselect || '')
  const [reason, setReason] = useState('Called in sick')
  const [busy, setBusy] = useState(false)
  useEffect(() => { if (!dept && depts.data?.length) setDept(depts.data[0].id) }, [depts.data, dept])
  const today = new Date()
  const cal = useApi('/calendar', { params: { start: isoDate(today), end: isoDate(addDays(today, 7)), department_id: dept }, enabled: Boolean(dept) })
  const shifts = useMemo(() => Object.fromEntries((cal.data?.shifts || []).map((s) => [s.id, s])), [cal.data])
  const list = useMemo(() => (cal.data?.assignments || [])
    .filter((a) => a.status === 'active' && new Date(a.start) > new Date() && shifts[a.shift_id]?.schedule?.status === 'published')
    .filter((a) => !q || a.employee?.full_name.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => new Date(a.start) - new Date(b.start)), [cal.data, shifts, q])
  const submit = async () => {
    setBusy(true)
    try {
      await api.post(`/assignments/${assignment}/absence`, { reason })
      toast.warning('Employee marked absent', { description: 'Their slot is open and replacement candidates are ranked.' })
      onMarked(assignment); setAssignment('')
      cal.reload({ silent: true })
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy(false) }
  }
  return (
    <Card className="border-destructive/30">
      <CardHeader><CardTitle className="flex items-center gap-2"><AlertOctagon className="h-4 w-4 text-destructive" /> Mark an employee absent</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <NativeSelect value={dept} onChange={(e) => setDept(e.target.value)} aria-label="Department">{(depts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</NativeSelect>
          <div className="relative"><Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" /><Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Employee" className="pl-8" /></div>
        </div>
        <Field label="Upcoming published assignment">
          <NativeSelect value={assignment} onChange={(e) => setAssignment(e.target.value)}>
            <option value="">Select an assignment</option>
            {list.map((a) => <option key={a.id} value={a.id}>{a.employee?.full_name} · {shifts[a.shift_id]?.name} {fmtDate(a.start, { weekday: 'short', day: 'numeric' })} {fmtTime(a.start)}</option>)}
          </NativeSelect>
        </Field>
        <Field label="Reason"><Textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} /></Field>
        <Button variant="destructive" className="w-full" disabled={!assignment || reason.trim().length < 3} loading={busy} onClick={submit}><Siren /> Mark absent and find cover</Button>
      </CardContent>
    </Card>
  )
}

function Candidates({ assignmentId, onResolved }) {
  const { data, error, loading, reload } = useApi(`/assignments/${assignmentId}/replacements`)
  const [open, setOpen] = useState(null)
  const [busy, setBusy] = useState(null)
  const [done, setDone] = useState(null)
  const [showRejected, setShowRejected] = useState(false)
  useEffect(() => { setDone(null); setOpen(null) }, [assignmentId])
  const approve = async (c) => {
    setBusy(c.employee_id)
    try {
      await api.post(`/assignments/${assignmentId}/replace`, { employee_id: c.employee_id })
      toast.success(`${c.name} assigned as replacement`, { description: 'Both employees have been notified.' })
      setDone(c); onResolved()
    } catch (e) { toast.error(errorMessage(e)); reload({ silent: true }) } finally { setBusy(null) }
  }
  if (error) return <ErrorState error={error} onRetry={reload} />
  if (loading || !data) return <Skeleton className="h-[480px]" />
  const s = data.shift
  return (
    <Card>
      <CardHeader>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div><CardTitle className="text-base">Replacement candidates · {s.name} shift</CardTitle><p className="num text-xs text-muted-foreground">{fmtDate(s.start, { weekday: 'long', day: 'numeric', month: 'long' })} · {fmtTime(s.start)}–{fmtTime(s.end)}</p></div>
          <div className="flex gap-1.5"><Badge variant="success">{data.candidates.length} eligible</Badge><Badge variant="secondary">{data.rejected.length} ruled out</Badge></div>
        </div>
        <p className="mt-2 rounded-lg bg-secondary/60 p-2 font-mono text-[11px] text-muted-foreground">{data.ranking_formula}</p>
      </CardHeader>
      <CardContent className="space-y-3">
        {done && <div className="flex items-center gap-2 rounded-lg border border-success/40 bg-success/10 p-3 text-sm text-success"><UserCheck className="h-5 w-5" /> {done.name} now covers this shift. The schedule is updated and both employees were notified.</div>}
        {data.shortage && !done && (
          <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-4"><p className="flex items-center gap-2 font-semibold text-destructive"><AlertOctagon className="h-4 w-4" /> Staffing shortage</p><p className="mt-1 text-sm text-muted-foreground">No employee satisfies every hard constraint for this shift. Consider calling in agency staff, approving overtime by raising a contract limit, or reducing the shift requirement.</p></div>
        )}
        {!done && data.candidates.map((c, i) => (
          <motion.div key={c.employee_id} initial={{ opacity: 0, x: 8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }} className={cn('rounded-xl border', i === 0 && 'border-primary/40 shadow-glow')}>
            <div className="flex flex-wrap items-center gap-3 p-3">
              <div className={cn('num flex h-8 w-8 items-center justify-center rounded-lg text-sm font-bold', i === 0 ? 'bg-gradient-to-br from-amber-400 to-orange-500 text-white' : 'bg-secondary')}>{i === 0 ? <Medal className="h-4 w-4" /> : c.rank}</div>
              <Avatar name={c.name} />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">{c.name} <span className="num text-xs font-normal text-muted-foreground">{c.code}</span></p>
                <p className="num text-xs text-muted-foreground">{c.week_hours_after}h / {c.max_weekly_hours}h this week after · rest gap {c.nearest_gap_hours != null ? `${c.nearest_gap_hours.toFixed(0)}h` : 'none adjacent'} · {fmtMoney(c.hourly_wage)}/h</p>
              </div>
              <div className="w-28"><p className="num text-right text-lg font-semibold">{c.score}</p><Progress value={c.score} className="h-1.5" /></div>
              <Button variant="ghost" size="icon-sm" onClick={() => setOpen(open === c.employee_id ? null : c.employee_id)} aria-label="Explain"><ChevronDown className={cn('transition', open === c.employee_id && 'rotate-180')} /></Button>
              <Button size="sm" variant={i === 0 ? 'gradient' : 'outline'} loading={busy === c.employee_id} onClick={() => approve(c)}><ShieldCheck /> Approve</Button>
            </div>
            <AnimatePresence>
              {open === c.employee_id && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden border-t">
                  <div className="grid gap-4 p-4 md:grid-cols-2">
                    <div><p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Validation</p><CheckList checks={c.checks} /></div>
                    <div>
                      <p className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Score breakdown</p>
                      {Object.entries(c.breakdown).map(([k, v]) => <div key={k} className="flex justify-between text-xs"><span className="capitalize text-muted-foreground">{k.replace(/_/g, ' ')}</span><span className="num">{v}</span></div>)}
                      <p className="mb-2 mt-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Preferences</p><CheckList checks={c.preferences} />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
        {data.rejected.length > 0 && (
          <div>
            <button className="text-xs text-muted-foreground hover:underline" onClick={() => setShowRejected((v) => !v)}>{showRejected ? 'Hide' : 'Show'} why {data.rejected.length} colleague(s) were ruled out</button>
            {showRejected && <div className="mt-2 grid gap-2 md:grid-cols-2">{data.rejected.map((r) => <div key={r.employee_id} className="rounded-lg bg-secondary/50 p-2.5 text-xs"><p className="font-medium">{r.name}</p><p className="text-destructive">{r.reasons.join('; ')}</p></div>)}</div>}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
