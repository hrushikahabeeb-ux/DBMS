import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { toast } from 'sonner'
import { ArrowRightLeft, Check, Plus, Repeat2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, Field, NativeSelect, Textarea } from '@/components/ui/primitives'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/overlay'
import { Avatar, EmptyState, ErrorState, LoadingRows, PageHeader, StatusBadge } from '@/components/common'
import { useApi } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { useNotifications } from '@/contexts/NotificationContext'
import { api, errorMessage } from '@/services/api'
import { fmtDate, fmtTime, relativeTime } from '@/utils/format'

const FLOW = ['pending_peer', 'peer_accepted', 'approved']

export default function SwapsPage() {
  const { user, isManager, isEmployee } = useAuth()
  const { lastEvent } = useNotifications()
  const [params, setParams] = useSearchParams()
  const [status, setStatus] = useState('')
  const [createFor, setCreateFor] = useState(params.get('assignment'))
  const { data, error, loading, reload } = useApi('/swaps', { params: { status: status || undefined } })
  useEffect(() => { if (lastEvent?.type?.startsWith('swap')) reload({ silent: true }) }, [lastEvent]) // eslint-disable-line react-hooks/exhaustive-deps

  const act = async (fn, msg) => { try { await fn(); toast.success(msg); reload({ silent: true }) } catch (e) { toast.error(errorMessage(e)) } }

  return (
    <>
      <PageHeader icon={Repeat2} eyebrow="Workflows" title="Shift Swaps"
        description="Request a colleague to swap or cover a shift. The backend validates skills, availability, weekly hours and rest at every step, and the manager's approval applies the exchange atomically."
        actions={isEmployee && <Button onClick={() => setCreateFor('')}><Plus /> New swap request</Button>} />
      <Card className="p-4">
        <div className="mb-4 flex flex-wrap gap-1 rounded-lg bg-secondary p-1 sm:w-fit">
          {['', 'pending_peer', 'peer_accepted', 'approved', 'rejected', 'declined'].map((s) => <Button key={s || 'all'} size="sm" variant={status === s ? 'default' : 'ghost'} onClick={() => setStatus(s)} className="capitalize">{s ? s.replace('_', ' ') : 'All'}</Button>)}
        </div>
        {error ? <ErrorState error={error} onRetry={reload} /> : loading && !data ? <LoadingRows /> : data.length === 0 ? <EmptyState icon={Repeat2} title="No swap requests" /> : (
          <div className="space-y-3">
            {data.map((s) => {
              const mineIncoming = s.target_employee_id === user.employee_id
              const mineOutgoing = s.requester_employee_id === user.employee_id
              const step = FLOW.indexOf(s.status)
              return (
                <div key={s.id} className="rounded-xl border p-4">
                  <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex -space-x-2"><Avatar name={s.requester?.full_name} className="ring-2 ring-card" /><Avatar name={s.target?.full_name} className="ring-2 ring-card" /></div>
                      <div>
                        <p className="text-sm font-medium">{s.requester?.full_name} <ArrowRightLeft className="mx-1 inline h-3.5 w-3.5 text-muted-foreground" /> {s.target?.full_name} <Badge variant="secondary" className="ml-1 capitalize">{s.kind}</Badge></p>
                        <p className="text-xs text-muted-foreground">
                          Gives: {s.requester_assignment?.shift?.name} {fmtDate(s.requester_assignment?.start, { weekday: 'short', day: 'numeric', month: 'short' })} {fmtTime(s.requester_assignment?.start)}
                          {s.target_assignment && <> · Takes: {s.target_assignment.shift?.name} {fmtDate(s.target_assignment.start, { weekday: 'short', day: 'numeric', month: 'short' })} {fmtTime(s.target_assignment.start)}</>}
                        </p>
                        {s.message && <p className="mt-1 text-xs italic text-muted-foreground">"{s.message}"</p>}
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <StatusBadge status={s.status} />
                      <span className="text-[11px] text-muted-foreground">{relativeTime(s.updated_at)}</span>
                      {mineIncoming && s.status === 'pending_peer' && <>
                        <Button size="sm" variant="outline" onClick={() => act(() => api.post(`/swaps/${s.id}/respond`, { accept: false }), 'Swap declined')}><X /> Decline</Button>
                        <Button size="sm" onClick={() => act(() => api.post(`/swaps/${s.id}/respond`, { accept: true }), 'Accepted; sent to the manager for approval')}><Check /> Accept</Button>
                      </>}
                      {mineOutgoing && s.is_open && <Button size="sm" variant="ghost" onClick={() => act(() => api.post(`/swaps/${s.id}/cancel`), 'Request cancelled')}>Cancel</Button>}
                      {isManager && s.status === 'peer_accepted' && <>
                        <Button size="sm" variant="outline" onClick={() => act(() => api.post(`/swaps/${s.id}/decision`, { approve: false }), 'Swap rejected')}><X /> Reject</Button>
                        <Button size="sm" variant="success" onClick={() => act(() => api.post(`/swaps/${s.id}/decision`, { approve: true }), 'Swap approved; assignments updated atomically')}><Check /> Approve</Button>
                      </>}
                    </div>
                  </div>
                  {step >= 0 && (
                    <div className="mt-3 flex items-center gap-2 text-[11px]">
                      {['Requested', 'Colleague accepted', 'Manager approved'].map((l, i) => (
                        <div key={l} className="flex items-center gap-2"><span className={`h-1.5 w-10 rounded-full ${i <= step ? 'bg-primary' : 'bg-secondary'}`} /><span className={i <= step ? '' : 'text-muted-foreground'}>{l}</span></div>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </Card>
      {isEmployee && <CreateSwap open={createFor !== null} assignmentId={createFor} onOpenChange={(o) => { if (!o) { setCreateFor(null); setParams({}) } }} onSaved={() => reload({ silent: true })} />}
    </>
  )
}

function CreateSwap({ open, assignmentId, onOpenChange, onSaved }) {
  const mine = useApi('/me/overview', { enabled: open })
  const [assignment, setAssignment] = useState(assignmentId || '')
  const [target, setTarget] = useState('')
  const [targetAssignment, setTargetAssignment] = useState('')
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  useEffect(() => { if (open) { setAssignment(assignmentId || ''); setTarget(''); setTargetAssignment(''); setErr('') } }, [open, assignmentId])
  const options = useApi(assignment ? '/me/swap-options' : null, { params: { assignment_id: assignment }, enabled: Boolean(open && assignment) })
  const theirShifts = useMemo(() => (options.data?.colleague_assignments || []).filter((a) => a.employee_id === target), [options.data, target])
  const upcoming = (mine.data?.upcoming || []).filter((a) => new Date(a.start) > new Date())
  const submit = async () => {
    setBusy(true); setErr('')
    try {
      await api.post('/swaps', { assignment_id: assignment, target_employee_id: target, target_assignment_id: targetAssignment || null, message: message || null })
      toast.success('Swap request sent', { description: 'Your colleague has been notified.' })
      onSaved(); onOpenChange(false)
    } catch (e) { setErr(errorMessage(e)) } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="md">
        <DialogHeader><DialogTitle>Request a shift swap</DialogTitle><DialogDescription>Leave "their shift" empty to ask a colleague to cover your shift.</DialogDescription></DialogHeader>
        <div className="space-y-3">
          <Field label="Your shift">
            <NativeSelect value={assignment} onChange={(e) => { setAssignment(e.target.value); setTarget(''); setTargetAssignment('') }}>
              <option value="">Select one of your upcoming shifts</option>
              {upcoming.map((a) => <option key={a.id} value={a.id}>{fmtDate(a.start, { weekday: 'short', day: 'numeric', month: 'short' })} · {a.shift?.name} {fmtTime(a.start)}–{fmtTime(a.end)} · {a.department?.name}</option>)}
            </NativeSelect>
          </Field>
          <Field label="Colleague">
            <NativeSelect value={target} onChange={(e) => { setTarget(e.target.value); setTargetAssignment('') }} disabled={!assignment}>
              <option value="">Select a colleague</option>
              {(options.data?.colleagues || []).map((c) => <option key={c.id} value={c.id}>{c.full_name} · {c.job_role}</option>)}
            </NativeSelect>
          </Field>
          <Field label="Their shift (optional, for a two-way swap)">
            <NativeSelect value={targetAssignment} onChange={(e) => setTargetAssignment(e.target.value)} disabled={!target}>
              <option value="">Cover only (no exchange)</option>
              {theirShifts.map((a) => <option key={a.id} value={a.id}>{fmtDate(a.start, { weekday: 'short', day: 'numeric', month: 'short' })} · {a.shift?.name} {fmtTime(a.start)}</option>)}
            </NativeSelect>
          </Field>
          <Field label="Message"><Textarea rows={2} value={message} onChange={(e) => setMessage(e.target.value)} /></Field>
          {err && <p className="rounded-lg border border-destructive/30 bg-destructive/10 p-2 text-xs text-destructive" role="alert">{err}</p>}
        </div>
        <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button disabled={!assignment || !target} loading={busy} onClick={submit}>Send request</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
