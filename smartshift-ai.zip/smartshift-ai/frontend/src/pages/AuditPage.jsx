import { useState } from 'react'
import { ClipboardList, Search } from 'lucide-react'
import { Badge, Card, Input, NativeSelect, Table, TBody, TD, TH, THead, TR } from '@/components/ui/primitives'
import { EmptyState, ErrorState, LoadingRows, PageHeader, Pagination } from '@/components/common'
import { useApi, useDebounce } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { fmtDateTime } from '@/utils/format'

const ENTITIES = ['', 'assignment', 'schedule', 'employee', 'department', 'leave_request', 'swap_request', 'scheduling_rules', 'user', 'system']

export default function AuditPage() {
  const { isAdmin } = useAuth()
  const [action, setAction] = useState('')
  const [entity, setEntity] = useState('')
  const [actor, setActor] = useState('')
  const [page, setPage] = useState(1)
  const a = useDebounce(action)
  const ac = useDebounce(actor)
  const { data, error, loading, reload } = useApi('/audit-logs', { params: { action: a || undefined, entity_type: entity || undefined, actor: ac || undefined, page, page_size: 25 } })
  return (
    <>
      <PageHeader icon={ClipboardList} eyebrow="Compliance" title="Audit Logs" description={isAdmin ? 'Every state-changing action across the organization, with actor, entity and correlation ID.' : 'Actions you have performed.'} />
      <Card className="p-4">
        <div className="mb-4 grid gap-2 md:grid-cols-3">
          <div className="relative"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input value={action} onChange={(e) => { setAction(e.target.value); setPage(1) }} placeholder="Action prefix, e.g. assignment" className="pl-9" /></div>
          <NativeSelect value={entity} onChange={(e) => { setEntity(e.target.value); setPage(1) }}>{ENTITIES.map((x) => <option key={x} value={x}>{x ? x.replace('_', ' ') : 'All entities'}</option>)}</NativeSelect>
          {isAdmin && <Input value={actor} onChange={(e) => { setActor(e.target.value); setPage(1) }} placeholder="Actor email" />}
        </div>
        {error ? <ErrorState error={error} onRetry={reload} /> : loading && !data ? <LoadingRows rows={10} /> : data.items.length === 0 ? <EmptyState icon={ClipboardList} title="No audit entries match" /> : (
          <Table>
            <THead><TR><TH>Time</TH><TH>Actor</TH><TH>Action</TH><TH>Entity</TH><TH>Details</TH><TH>Correlation</TH></TR></THead>
            <TBody>
              {data.items.map((l) => (
                <TR key={l.id}>
                  <TD className="num whitespace-nowrap text-xs">{fmtDateTime(l.created_at)}</TD>
                  <TD className="text-xs"><p>{l.actor_email}</p><p className="text-[10px] text-muted-foreground">{l.actor_role}</p></TD>
                  <TD><Badge variant="secondary">{l.action}</Badge></TD>
                  <TD className="text-xs">{l.entity_type}<p className="num text-[10px] text-muted-foreground">{l.entity_id?.slice(-8)}</p></TD>
                  <TD className="max-w-sm truncate font-mono text-[10px] text-muted-foreground" title={JSON.stringify(l.details)}>{JSON.stringify(l.details)}</TD>
                  <TD className="num text-[10px] text-muted-foreground">{l.correlation_id?.slice(0, 10)}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
        {data && <div className="mt-4"><Pagination page={data.page} pages={data.pages} total={data.total} onPage={setPage} /></div>}
      </Card>
    </>
  )
}
