import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { toast } from 'sonner'
import { Building2, Clock, Pencil, Plus, Trash2, UserCog, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, Field, Input, NativeSelect, Textarea } from '@/components/ui/primitives'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/overlay'
import { EmptyState, ErrorState, LoadingRows, PageHeader } from '@/components/common'
import { useApi } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { api, errorMessage } from '@/services/api'
import { SHIFT_COLORS } from '@/utils/format'

const NEW_SHIFT = { code: '', name: '', start_time: '08:00', duration_hours: 8, required_staff: 1, required_skills: [], skill_mix: [] }

export default function DepartmentsPage() {
  const { isAdmin } = useAuth()
  const { data, error, loading, reload } = useApi('/departments')
  const managers = useApi('/users', { params: { role: 'manager', page_size: 100 }, enabled: isAdmin })
  const [editing, setEditing] = useState(null)
  const [open, setOpen] = useState(false)

  return (
    <>
      <PageHeader icon={Building2} eyebrow="Organization" title="Departments" description="Configure operating hours, staffing requirements, required qualifications and shift templates. Nothing here is hard-coded to hospitals."
        actions={isAdmin && <Button onClick={() => { setEditing(null); setOpen(true) }}><Plus /> New department</Button>} />
      {error ? <ErrorState error={error} onRetry={reload} /> : loading ? <LoadingRows rows={4} /> : data.length === 0 ? <EmptyState icon={Building2} title="No departments yet" /> : (
        <div className="grid gap-4 lg:grid-cols-2 2xl:grid-cols-3">
          {data.map((d, i) => (
            <motion.div key={d.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="relative h-full overflow-hidden p-5">
                <div className="absolute inset-x-0 top-0 h-1" style={{ background: `linear-gradient(90deg, ${d.color || '#6366f1'}, transparent)` }} />
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2"><h3 className="font-semibold">{d.name}</h3><Badge variant="secondary" className="num">{d.code}</Badge></div>
                    <p className="mt-1 text-xs text-muted-foreground">{d.description}</p>
                  </div>
                  <Button variant="ghost" size="icon-sm" onClick={() => { setEditing(d); setOpen(true) }} aria-label={`Edit ${d.name}`}><Pencil /></Button>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <Metric icon={Users} label="Eligible staff" value={d.employee_count} />
                  <Metric icon={UserCog} label="Daily slots" value={d.daily_required_staff} />
                  <Metric icon={Clock} label="Hours" value={`${d.operating_hours?.start}–${d.operating_hours?.end}`} />
                </div>
                <p className="mt-4 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Shift configurations</p>
                <div className="mt-2 space-y-1.5">
                  {d.shift_configurations.map((s) => (
                    <div key={s.code} className="flex items-center justify-between rounded-lg border px-3 py-2 text-xs">
                      <span className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ background: SHIFT_COLORS[s.code]?.bg || s.color || '#818cf8' }} /><span className="font-medium">{s.name}</span><span className="num text-muted-foreground">{s.start_time} · {s.duration_hours}h</span></span>
                      <span className="flex items-center gap-1.5">
                        {s.skill_mix?.map((m) => <Badge key={m.skill} variant="violet">{m.min}x {m.skill}</Badge>)}
                        <Badge className="num">{s.required_staff} staff</Badge>
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-1.5 text-xs">
                  <span className="text-muted-foreground">Required for all:</span>
                  {(d.required_skills || []).length ? d.required_skills.map((s) => <Badge key={s} variant="outline">{s}</Badge>) : <span className="text-muted-foreground">None</span>}
                </div>
                <p className="mt-3 text-xs text-muted-foreground">Manager: <span className="text-foreground">{d.manager?.full_name || 'Unassigned'}</span></p>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
      <DepartmentDialog open={open} onOpenChange={setOpen} department={editing} isAdmin={isAdmin} managers={managers.data?.items || []} onSaved={reload} />
    </>
  )
}

function Metric({ icon: Icon, label, value }) {
  return (
    <div className="rounded-lg bg-secondary/60 px-2 py-2.5">
      <Icon className="mx-auto mb-1 h-3.5 w-3.5 text-muted-foreground" />
      <p className="num text-sm font-semibold">{value}</p>
      <p className="text-[10px] text-muted-foreground">{label}</p>
    </div>
  )
}

function DepartmentDialog({ open, onOpenChange, department, isAdmin, managers, onSaved }) {
  const [form, setForm] = useState(null)
  const [busy, setBusy] = useState(false)
  useEffect(() => {
    if (!open) return
    setForm(department ? {
      ...department, required_skills: (department.required_skills || []).join(', '),
      shift_configurations: department.shift_configurations.map((s) => ({ ...s, required_skills: (s.required_skills || []).join(', '), skill_mix: (s.skill_mix || []).map((m) => `${m.min}x ${m.skill}`).join(', ') })),
    } : { code: '', name: '', description: '', manager_user_id: '', operating_hours: { start: '00:00', end: '23:59', days: [0, 1, 2, 3, 4, 5, 6] }, required_skills: '', shift_configurations: [{ ...NEW_SHIFT, code: 'day', name: 'Day', required_skills: '', skill_mix: '' }] })
  }, [open, department])
  if (!form) return null
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))
  const setShift = (i, k, v) => setForm((f) => ({ ...f, shift_configurations: f.shift_configurations.map((s, j) => (j === i ? { ...s, [k]: v } : s)) }))
  const list = (s) => s.split(',').map((x) => x.trim()).filter(Boolean)
  const mix = (s) => list(s).map((x) => { const m = x.match(/^(\d+)\s*x\s*(.+)$/i); return m ? { min: Number(m[1]), skill: m[2].trim() } : { min: 1, skill: x } })

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true)
    const payload = {
      name: form.name, description: form.description, operating_hours: form.operating_hours, required_skills: list(form.required_skills),
      shift_configurations: form.shift_configurations.map((s) => ({ code: s.code, name: s.name, start_time: s.start_time, duration_hours: Number(s.duration_hours), required_staff: Number(s.required_staff), required_skills: list(s.required_skills), skill_mix: mix(s.skill_mix), color: s.color })),
    }
    if (isAdmin) payload.manager_user_id = form.manager_user_id || null
    try {
      if (department) await api.patch(`/departments/${department.id}`, payload)
      else await api.post('/departments', { ...payload, code: form.code })
      toast.success(department ? 'Department updated' : 'Department created', { description: 'New schedules will use this configuration.' })
      onSaved(); onOpenChange(false)
    } catch (err) { toast.error(errorMessage(err)) } finally { setBusy(false) }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="xl">
        <DialogHeader>
          <DialogTitle>{department ? `Configure ${department.name}` : 'New department'}</DialogTitle>
          <DialogDescription>Changes apply to schedules created after saving. Existing schedules keep their shifts.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-4">
            {!department && <Field label="Code"><Input value={form.code} onChange={(e) => set('code', e.target.value.toUpperCase())} placeholder="LAB" required /></Field>}
            <Field label="Name" className={department ? 'sm:col-span-2' : ''}><Input value={form.name} onChange={(e) => set('name', e.target.value)} required /></Field>
            <Field label="Opens"><Input type="time" value={form.operating_hours.start} onChange={(e) => set('operating_hours', { ...form.operating_hours, start: e.target.value })} /></Field>
            <Field label="Closes"><Input type="time" value={form.operating_hours.end} onChange={(e) => set('operating_hours', { ...form.operating_hours, end: e.target.value })} /></Field>
          </div>
          <Field label="Description"><Textarea value={form.description} onChange={(e) => set('description', e.target.value)} rows={2} /></Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Qualifications required for every shift" hint="Comma separated"><Input value={form.required_skills} onChange={(e) => set('required_skills', e.target.value)} /></Field>
            {isAdmin && (
              <Field label="Department manager">
                <NativeSelect value={form.manager_user_id || ''} onChange={(e) => set('manager_user_id', e.target.value)}>
                  <option value="">Unassigned</option>
                  {managers.map((m) => <option key={m.id} value={m.id}>{m.full_name}</option>)}
                </NativeSelect>
              </Field>
            )}
          </div>
          <div>
            <div className="mb-2 flex items-center justify-between">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Shift templates and staffing</p>
              <Button type="button" size="sm" variant="outline" onClick={() => set('shift_configurations', [...form.shift_configurations, { ...NEW_SHIFT, required_skills: '', skill_mix: '' }])}><Plus /> Add shift</Button>
            </div>
            <div className="space-y-2">
              {form.shift_configurations.map((s, i) => (
                <div key={i} className="grid items-end gap-2 rounded-lg border p-3 sm:grid-cols-[90px_1fr_100px_80px_80px_1fr_1fr_36px]">
                  <Field label="Code"><Input value={s.code} onChange={(e) => setShift(i, 'code', e.target.value.toLowerCase())} required /></Field>
                  <Field label="Name"><Input value={s.name} onChange={(e) => setShift(i, 'name', e.target.value)} required /></Field>
                  <Field label="Start"><Input type="time" value={s.start_time} onChange={(e) => setShift(i, 'start_time', e.target.value)} /></Field>
                  <Field label="Hours"><Input type="number" min={1} max={16} step={0.5} value={s.duration_hours} onChange={(e) => setShift(i, 'duration_hours', e.target.value)} /></Field>
                  <Field label="Staff"><Input type="number" min={0} value={s.required_staff} onChange={(e) => setShift(i, 'required_staff', e.target.value)} /></Field>
                  <Field label="All must have"><Input value={s.required_skills} onChange={(e) => setShift(i, 'required_skills', e.target.value)} placeholder="Critical Care" /></Field>
                  <Field label="Skill mix (min x skill)"><Input value={s.skill_mix} onChange={(e) => setShift(i, 'skill_mix', e.target.value)} placeholder="1x ACLS" /></Field>
                  <Button type="button" variant="ghost" size="icon" disabled={form.shift_configurations.length === 1} onClick={() => set('shift_configurations', form.shift_configurations.filter((_, j) => j !== i))} aria-label="Remove shift"><Trash2 /></Button>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" loading={busy}>Save department</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
