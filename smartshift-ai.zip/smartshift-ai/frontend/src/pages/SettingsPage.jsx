import { useEffect, useState } from 'react'
import { toast } from 'sonner'
import { Activity, Database, Moon, RefreshCcw, Save, Server, Settings, SlidersHorizontal, Sun } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, CardContent, CardHeader, CardTitle, Field, Input, Skeleton, Switch, Table, TBody, TD, TH, THead, TR } from '@/components/ui/primitives'
import { ConfirmDialog, ErrorState, PageHeader } from '@/components/common'
import { useApi } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { useTheme } from '@/contexts/ThemeContext'
import { api, errorMessage } from '@/services/api'
import { relativeTime } from '@/utils/format'

const WEIGHT_KEYS = ['unfilled', 'cost', 'preference', 'fairness', 'night_balance', 'weekend_balance', 'overtime', 'stability']

export default function SettingsPage() {
  const { isAdmin, isManager } = useAuth()
  const { theme, toggle } = useTheme()
  return (
    <>
      <PageHeader icon={Settings} eyebrow="Configuration" title="Settings" description="Appearance, scheduling rules, optimization weights and system health." />
      <div className="grid gap-4 xl:grid-cols-[1fr_420px]">
        <div className="space-y-4">
          {isManager && <RulesCard editable={isAdmin} />}
          {!isManager && <Card className="p-5 text-sm text-muted-foreground">Your scheduling rules are managed by your organization administrator.</Card>}
        </div>
        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Appearance</CardTitle></CardHeader>
            <CardContent className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-sm">{theme === 'dark' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />} {theme === 'dark' ? 'Dark' : 'Light'} theme</span>
              <Switch checked={theme === 'dark'} onCheckedChange={toggle} aria-label="Dark theme" />
            </CardContent>
          </Card>
          <HealthCard />
          {isAdmin && <DemoCard />}
        </div>
      </div>
    </>
  )
}

function RulesCard({ editable }) {
  const { data, error, loading, reload } = useApi('/rules')
  const [form, setForm] = useState(null)
  const [busy, setBusy] = useState(false)
  useEffect(() => { if (data) setForm(JSON.parse(JSON.stringify(data))) }, [data])
  if (error) return <ErrorState error={error} onRetry={reload} />
  if (loading || !form) return <Skeleton className="h-96" />
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))
  const setW = (p, k, v) => setForm((f) => ({ ...f, weights: { ...f.weights, [p]: { ...f.weights[p], [k]: Number(v) } } }))
  const save = async () => {
    setBusy(true)
    try {
      await api.put('/rules', {
        organization_name: form.organization_name, timezone: form.timezone, min_rest_hours: Number(form.min_rest_hours),
        max_consecutive_days: Number(form.max_consecutive_days), overtime_threshold_hours: Number(form.overtime_threshold_hours),
        overtime_multiplier: Number(form.overtime_multiplier), allow_understaffing: form.allow_understaffing,
        solver_time_limit_seconds: Number(form.solver_time_limit_seconds), weights: form.weights,
      })
      toast.success('Rules saved', { description: 'They apply to the next optimization and validation.' })
      reload({ silent: true })
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy(false) }
  }
  return (
    <>
      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><SlidersHorizontal className="h-4 w-4" /> Scheduling rules</CardTitle><p className="text-xs text-muted-foreground">Hard constraints enforced by the optimizer, the validator and every workflow.{!editable && ' Only a super admin can change them.'}</p></CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-3">
          <Field label="Organization"><Input value={form.organization_name || ''} disabled={!editable} onChange={(e) => set('organization_name', e.target.value)} /></Field>
          <Field label="Timezone"><Input value={form.timezone} disabled={!editable} onChange={(e) => set('timezone', e.target.value)} /></Field>
          <Field label="Minimum rest between shifts (h)"><Input type="number" min={0} max={48} value={form.min_rest_hours} disabled={!editable} onChange={(e) => set('min_rest_hours', e.target.value)} /></Field>
          <Field label="Max consecutive working days"><Input type="number" min={1} max={14} value={form.max_consecutive_days} disabled={!editable} onChange={(e) => set('max_consecutive_days', e.target.value)} /></Field>
          <Field label="Overtime threshold (h/week)"><Input type="number" min={0} max={80} value={form.overtime_threshold_hours} disabled={!editable} onChange={(e) => set('overtime_threshold_hours', e.target.value)} /></Field>
          <Field label="Overtime pay multiplier"><Input type="number" step={0.1} min={1} max={3} value={form.overtime_multiplier} disabled={!editable} onChange={(e) => set('overtime_multiplier', e.target.value)} /></Field>
          <Field label="Solver time limit (s)"><Input type="number" min={1} max={120} value={form.solver_time_limit_seconds} disabled={!editable} onChange={(e) => set('solver_time_limit_seconds', e.target.value)} /></Field>
          <Field label="Allow understaffing" hint="Off: generation fails (with a diagnosis) unless every slot can be filled" className="sm:col-span-2">
            <Switch checked={form.allow_understaffing} disabled={!editable} onCheckedChange={(v) => set('allow_understaffing', v)} />
          </Field>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Optimization weights by preset</CardTitle><p className="text-xs text-muted-foreground">Each weight multiplies a normalized penalty term in the CP-SAT objective. "Unfilled" should stay much larger than the others so coverage is always prioritized.</p></CardHeader>
        <CardContent>
          <Table>
            <THead><TR><TH>Term</TH>{Object.keys(form.weights).map((p) => <TH key={p} className="text-center">{form.preset_labels?.[p] || p}</TH>)}</TR></THead>
            <TBody>
              {WEIGHT_KEYS.map((k) => (
                <TR key={k}>
                  <TD className="text-xs capitalize">{k.replace('_', ' ')}</TD>
                  {Object.keys(form.weights).map((p) => (
                    <TD key={p}><Input type="number" min={0} className="mx-auto h-8 w-24 text-center" value={form.weights[p][k]} disabled={!editable} onChange={(e) => setW(p, k, e.target.value)} aria-label={`${p} ${k}`} /></TD>
                  ))}
                </TR>
              ))}
            </TBody>
          </Table>
          {editable && <div className="mt-4 flex justify-end gap-2"><Button variant="outline" onClick={() => setForm((f) => ({ ...f, weights: JSON.parse(JSON.stringify(f.default_weights)) }))}>Restore defaults</Button><Button onClick={save} loading={busy}><Save /> Save rules</Button></div>}
        </CardContent>
      </Card>
    </>
  )
}

function HealthCard() {
  const { data, error, loading, reload } = useApi('/system/health')
  const rows = data ? [
    ['Main API', data.api?.status, data.api?.mongodb ? 'MongoDB connected' : 'MongoDB down'],
    ['Optimizer', data.optimizer?.status, data.optimizer?.ortools ? `OR-Tools ${data.optimizer.ortools} · ${data.optimizer.runs_served} runs` : data.optimizer?.error],
    ['Worker', data.worker?.status, data.worker?.last_heartbeat ? `heartbeat ${relativeTime(data.worker.last_heartbeat)}` : 'no heartbeat'],
    ['Notifications', data.notification?.status, data.notification?.websocket_connections != null ? `${data.notification.websocket_connections} sockets · ${data.notification.processed} events` : data.notification?.error],
    ['Analytics', data.analytics?.status, data.analytics?.error || 'aggregation pipelines'],
    ['Redis queue', data.api?.redis ? 'ok' : 'down', `depth ${data.api?.queue_depth ?? '—'}`],
  ] : []
  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between"><CardTitle className="flex items-center gap-2"><Server className="h-4 w-4" /> Distributed services</CardTitle><Button size="icon-sm" variant="ghost" onClick={reload} aria-label="Refresh health"><RefreshCcw /></Button></CardHeader>
      <CardContent className="space-y-2">
        {error && <ErrorState error={error} onRetry={reload} />}
        {loading && !data && <Skeleton className="h-40" />}
        {rows.map(([name, status, detail]) => (
          <div key={name} className="flex items-center justify-between rounded-lg border px-3 py-2">
            <div className="flex items-center gap-2"><span className={`h-2 w-2 rounded-full ${status === 'ok' ? 'bg-success' : 'bg-destructive'}`} /><div><p className="text-sm font-medium">{name}</p><p className="text-[11px] text-muted-foreground">{detail}</p></div></div>
            <Badge variant={status === 'ok' ? 'success' : 'destructive'}>{status || 'unknown'}</Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function DemoCard() {
  const [open, setOpen] = useState(false)
  const reset = async () => {
    try {
      const r = (await api.post('/demo/reset', {}, { timeout: 180000 })).data
      toast.success('Demo data restored', { description: `${r.employees} employees, ${r.departments} departments, ${r.schedules.length} schedules in ${r.seconds}s.` })
    } catch (e) { toast.error(errorMessage(e)) }
  }
  return (
    <Card className="border-warning/30">
      <CardHeader><CardTitle className="flex items-center gap-2"><Activity className="h-4 w-4 text-warning" /> Expo demo mode</CardTitle></CardHeader>
      <CardContent className="space-y-3 text-xs text-muted-foreground">
        <p>Restores the repeatable demonstration dataset: 30 employees across Emergency, ICU and General Ward, availability patterns, leave, four weeks of schedules produced by the real optimizer, and an empty Emergency draft for next week.</p>
        <Button variant="outline" className="w-full" onClick={() => setOpen(true)}><Database /> Reset demo data</Button>
      </CardContent>
      <ConfirmDialog open={open} onOpenChange={setOpen} title="Reset all data to the demo dataset?" description="This deletes every record in the database and re-seeds it. You will need to sign in again." variant="destructive" confirmLabel="Reset" onConfirm={reset} />
    </Card>
  )
}
