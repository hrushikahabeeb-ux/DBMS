import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { Bar, BarChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis } from 'recharts'
import { ArrowLeft, Briefcase, CalendarDays, Clock, IndianRupee, Mail, Pencil, Plane } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, CardContent, CardHeader, CardTitle, Skeleton, Table, TBody, TD, TH, THead, TR } from '@/components/ui/primitives'
import { Avatar, ChartCard, EmptyState, ErrorState, StatusBadge } from '@/components/common'
import EmployeeForm from '@/components/common/EmployeeForm'
import { axisProps, useChartTheme } from '@/components/common/charts'
import { useApi } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { fmtDate, fmtMoney, fmtTime, SHIFT_COLORS, WEEKDAYS } from '@/utils/format'

export default function EmployeeProfilePage() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { isManager } = useAuth()
  const t = useChartTheme()
  const [edit, setEdit] = useState(false)
  const { data, error, loading, reload } = useApi(`/employees/${id}/profile`)
  const depts = useApi('/departments', { enabled: isManager })
  if (error) return <ErrorState error={error} onRetry={reload} />
  if (loading || !data) return <div className="space-y-4"><Skeleton className="h-32" /><Skeleton className="h-64" /></div>
  const e = data.employee
  const av = data.availability || {}
  return (
    <>
      <Button variant="ghost" size="sm" className="mb-4" onClick={() => navigate(-1)}><ArrowLeft /> Back</Button>
      <Card className="relative overflow-hidden p-6">
        <div className="absolute inset-x-0 top-0 h-20 bg-gradient-to-r from-indigo-500/20 via-violet-500/15 to-fuchsia-500/10" />
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div className="flex items-end gap-4">
            <Avatar name={e.full_name} className="h-16 w-16 text-lg ring-4 ring-card" />
            <div>
              <div className="flex items-center gap-2"><h1 className="text-xl font-semibold">{e.full_name}</h1><StatusBadge status={e.status} /></div>
              <p className="text-sm text-muted-foreground">{e.job_role} · <span className="num">{e.employee_code}</span></p>
            </div>
          </div>
          {isManager && <Button variant="outline" onClick={() => setEdit(true)}><Pencil /> Edit profile</Button>}
        </div>
        <div className="relative mt-6 grid gap-4 text-sm sm:grid-cols-2 lg:grid-cols-5">
          <Info icon={Mail} label="Email" value={e.email} />
          <Info icon={Briefcase} label="Departments" value={data.departments.map((d) => d.name).join(', ')} />
          <Info icon={Clock} label="Max weekly hours" value={`${e.max_weekly_hours}h`} />
          <Info icon={IndianRupee} label="Hourly wage" value={fmtMoney(e.hourly_wage)} />
          <Info icon={CalendarDays} label="Joined" value={fmtDate(e.joining_date, { day: 'numeric', month: 'short', year: 'numeric' })} />
        </div>
        <div className="relative mt-4 flex flex-wrap gap-1.5">{e.skills.map((s) => <Badge key={s} variant="violet">{s}</Badge>)}</div>
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <ChartCard className="lg:col-span-2" title="Working-hour history" description="Active assignments per ISO week (last 12 weeks)">
          {data.hours_history.length === 0 ? <EmptyState title="No worked hours yet" /> : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={data.hours_history}>
                <CartesianGrid vertical={false} stroke={t.grid} />
                <XAxis dataKey="week" {...axisProps(t)} tickFormatter={(w) => w.split('-')[1]} />
                <YAxis {...axisProps(t)} width={28} />
                <RTooltip {...t.tooltip} />
                <ReferenceLine y={e.max_weekly_hours} stroke="#fb7185" strokeDasharray="4 4" label={{ value: 'limit', fill: '#fb7185', fontSize: 10, position: 'insideTopRight' }} />
                <Bar dataKey="hours" name="Hours" fill="#818cf8" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
        <Card>
          <CardHeader><CardTitle>Availability and preferences</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-xs">
            <div className="grid grid-cols-7 gap-1">
              {WEEKDAYS.map((d, i) => {
                const w = (av.recurring || []).filter((r) => r.weekday === i)
                return (
                  <div key={d} className="text-center">
                    <p className="mb-1 text-[10px] text-muted-foreground">{d}</p>
                    <div className={`rounded-md py-2 text-[10px] font-medium ${w.length ? 'bg-success/15 text-success' : 'bg-muted text-muted-foreground'}`}>{w.length ? (w.some((x) => x.start === '23:00') ? '24h' : 'Day') : 'Off'}</div>
                  </div>
                )
              })}
            </div>
            <p><span className="text-muted-foreground">Preferred shifts:</span> {(av.preferred_shifts || []).join(', ') || 'No preference'}</p>
            <p><span className="text-muted-foreground">Preferred days off:</span> {(av.preferred_days_off || []).map((d) => WEEKDAYS[d]).join(', ') || 'None'}</p>
            <p><span className="text-muted-foreground">Unavailable dates:</span> {(av.unavailable_dates || []).map((d) => fmtDate(d)).join(', ') || 'None'}</p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Assigned shifts</CardTitle></CardHeader>
          <CardContent>
            {data.assignments.length === 0 ? <EmptyState title="No current or upcoming shifts" /> : (
              <Table>
                <THead><TR><TH>Date</TH><TH>Shift</TH><TH>Department</TH><TH>Schedule</TH><TH>Source</TH></TR></THead>
                <TBody>
                  {data.assignments.map((a) => (
                    <TR key={a.id}>
                      <TD className="num text-xs">{fmtDate(a.start, { weekday: 'short', day: 'numeric', month: 'short' })}</TD>
                      <TD><span className="flex items-center gap-2 text-xs"><span className="h-2 w-2 rounded-full" style={{ background: SHIFT_COLORS[a.shift.template_code]?.bg }} />{a.shift.name} <span className="num text-muted-foreground">{fmtTime(a.start)}–{fmtTime(a.end)}</span></span></TD>
                      <TD className="text-xs">{a.department.name}</TD>
                      <TD><StatusBadge status={a.schedule.status} /></TD>
                      <TD className="text-xs capitalize text-muted-foreground">{a.source}</TD>
                    </TR>
                  ))}
                </TBody>
              </Table>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Plane className="h-4 w-4" /> Leave records</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {data.leave.length === 0 ? <p className="text-xs text-muted-foreground">No leave requests.</p> : data.leave.map((l) => (
              <div key={l.id} className="flex items-center justify-between rounded-lg border px-3 py-2 text-xs">
                <div><p className="font-medium capitalize">{l.leave_type}</p><p className="num text-muted-foreground">{fmtDate(l.start_date)} – {fmtDate(l.end_date)}</p></div>
                <StatusBadge status={l.status} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
      {isManager && <EmployeeForm open={edit} onOpenChange={setEdit} employee={e} departments={depts.data || []} onSaved={reload} />}
    </>
  )
}

function Info({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-2.5">
      <Icon className="mt-0.5 h-4 w-4 text-muted-foreground" />
      <div className="min-w-0"><p className="text-[11px] text-muted-foreground">{label}</p><p className="truncate text-[13px] font-medium">{value}</p></div>
    </div>
  )
}
