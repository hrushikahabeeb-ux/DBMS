import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis } from 'recharts'
import { BarChart3, Download, FileText, Scale, Sparkles } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, CardContent, CardHeader, CardTitle, Input, NativeSelect, Progress, Skeleton, Table, TBody, TD, TH, THead, TR } from '@/components/ui/primitives'
import { ChartCard, EmptyState, ErrorState, PageHeader } from '@/components/common'
import CoverageHeatmap from '@/components/common/CoverageHeatmap'
import { axisProps, PALETTE, useChartTheme } from '@/components/common/charts'
import { useApi } from '@/hooks/useApi'
import { api, errorMessage } from '@/services/api'
import { addDays, downloadCsv, fmtDate, fmtMoney, fmtPct, isoDate, startOfWeek } from '@/utils/format'

export default function AnalyticsPage() {
  const t = useChartTheme()
  const navigate = useNavigate()
  const [dept, setDept] = useState('')
  const [start, setStart] = useState(isoDate(addDays(startOfWeek(), -14)))
  const [end, setEnd] = useState(isoDate(addDays(startOfWeek(), 13)))
  const params = { start, end, department_id: dept || undefined }
  const depts = useApi('/departments')
  const coverage = useApi('/analytics/coverage', { params })
  const hours = useApi('/analytics/hours', { params })
  const util = useApi('/analytics/departments', { params: { start, end } })
  const cost = useApi('/analytics/labor-cost', { params })
  const leave = useApi('/analytics/leave-trends', { params: { months: 6, department_id: dept || undefined } })
  const shortages = useApi('/analytics/shortages', { params })
  const comparison = useApi('/analytics/optimization-comparison', { params: { department_id: dept || undefined } })
  const schedules = useApi('/schedules', { params: { department_id: dept || undefined, page_size: 30 } })
  const [scheduleId, setScheduleId] = useState('')
  useEffect(() => { const s = schedules.data?.items.find((x) => x.status === 'published') || schedules.data?.items[0]; setScheduleId(s?.id || '') }, [schedules.data])
  const fairness = useApi('/analytics/fairness', { params: { schedule_id: scheduleId }, enabled: Boolean(scheduleId) })

  const daily = useMemo(() => {
    const m = {}
    for (const c of coverage.data?.cells || []) { m[c.date] = m[c.date] || { date: c.date, required: 0, filled: 0 }; m[c.date].required += c.required; m[c.date].filled += c.filled }
    return Object.values(m).map((d) => ({ ...d, label: fmtDate(d.date, { day: 'numeric', month: 'short' }), pct: d.required ? Math.round((100 * d.filled) / d.required) : 100 }))
  }, [coverage.data])
  const costRows = useMemo(() => {
    const m = {}
    const deps = new Set()
    for (const r of cost.data?.rows || []) { deps.add(r.department); m[r.date] = m[r.date] || { date: r.date, label: fmtDate(r.date, { day: 'numeric', month: 'short' }) }; m[r.date][r.department] = r.cost }
    return { rows: Object.values(m), deps: [...deps] }
  }, [cost.data])
  const leaveRows = useMemo(() => {
    const m = {}
    const types = new Set()
    for (const r of leave.data?.rows || []) { types.add(r.leave_type); m[r.month] = m[r.month] || { month: r.month }; m[r.month][r.leave_type] = (m[r.month][r.leave_type] || 0) + r.count }
    return { rows: Object.values(m).sort((a, b) => a.month.localeCompare(b.month)), types: [...types] }
  }, [leave.data])
  const totalCost = (cost.data?.rows || []).reduce((s, r) => s + r.cost, 0)
  const totalOt = (hours.data?.employees || []).reduce((s, r) => s + r.overtime_hours, 0)

  const exportCsv = async (report) => {
    try { const r = (await api.get(`/analytics/export/${report}`, { params })).data; downloadCsv(r.filename, r.csv); toast.success(`Exported ${r.rows} rows`) } catch (e) { toast.error(errorMessage(e)) }
  }

  return (
    <>
      <PageHeader icon={BarChart3} eyebrow="Insights" title="Workforce Analytics" description="Every chart is produced by MongoDB aggregation pipelines in the analytics service."
        actions={<>
          <Button variant="outline" onClick={() => window.print()}><FileText /> Print or save PDF</Button>
          <Button variant="outline" onClick={() => exportCsv('hours')}><Download /> Hours CSV</Button>
          <Button variant="outline" onClick={() => exportCsv('coverage')}><Download /> Coverage CSV</Button>
          <Button variant="outline" onClick={() => exportCsv('labor-cost')}><Download /> Cost CSV</Button>
        </>} />
      <Card className="mb-4 flex flex-wrap items-center gap-2 p-3">
        <NativeSelect className="w-52" value={dept} onChange={(e) => setDept(e.target.value)} aria-label="Department"><option value="">All departments</option>{(depts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</NativeSelect>
        <Input type="date" className="w-40" value={start} onChange={(e) => setStart(e.target.value)} aria-label="From" />
        <span className="text-xs text-muted-foreground">to</span>
        <Input type="date" className="w-40" value={end} min={start} onChange={(e) => setEnd(e.target.value)} aria-label="To" />
        <div className="ml-auto flex gap-4 text-xs">
          <span><span className="text-muted-foreground">Labor cost</span> <span className="num font-semibold">{fmtMoney(totalCost)}</span></span>
          <span><span className="text-muted-foreground">Overtime</span> <span className="num font-semibold">{totalOt}h</span></span>
          <span><span className="text-muted-foreground">Shortage slots</span> <span className="num font-semibold">{(shortages.data?.shortages || []).reduce((s, x) => s + x.missing, 0)}</span></span>
        </div>
      </Card>

      <div className="grid gap-4 xl:grid-cols-2">
        <ChartCard title="Weekly staffing coverage" description="Filled versus required staff slots per day">
          {coverage.loading ? <Skeleton className="h-64" /> : coverage.error ? <ErrorState error={coverage.error} /> : (
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={daily}>
                <defs><linearGradient id="gf" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#818cf8" stopOpacity={0.5} /><stop offset="100%" stopColor="#818cf8" stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid vertical={false} stroke={t.grid} />
                <XAxis dataKey="label" {...axisProps(t)} minTickGap={12} />
                <YAxis {...axisProps(t)} width={32} />
                <RTooltip {...t.tooltip} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Area type="monotone" dataKey="required" name="Required" stroke="#94a3b8" strokeDasharray="4 4" fill="transparent" />
                <Area type="monotone" dataKey="filled" name="Filled" stroke="#818cf8" strokeWidth={2} fill="url(#gf)" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
        <ChartCard title="Department utilization" description="Assigned hours as a share of contracted capacity">
          {util.loading ? <Skeleton className="h-64" /> : (
            <div className="space-y-4 px-2 pt-2">
              {(util.data?.departments || []).map((d, i) => (
                <div key={d.id}>
                  <div className="mb-1 flex justify-between text-xs"><span className="font-medium">{d.name} <span className="text-muted-foreground">· {d.staff} staff</span></span><span className="num">{d.utilization_pct}% · {fmtMoney(d.labor_cost)}</span></div>
                  <Progress value={d.utilization_pct} indicatorClassName={['from-indigo-500 to-violet-500', 'from-violet-500 to-fuchsia-500', 'from-sky-500 to-indigo-500'][i % 3]} />
                  <p className="num mt-1 text-[10px] text-muted-foreground">{d.assigned_hours}h assigned of {d.capacity_hours}h capacity · {d.required_hours}h required · {d.shortage_slots} unfilled slots</p>
                </div>
              ))}
            </div>
          )}
        </ChartCard>
      </div>

      <ChartCard className="mt-4" title="Staffing coverage heatmap" description="Each cell shows filled/required staff for that shift">
        {coverage.loading ? <Skeleton className="h-40" /> : <CoverageHeatmap cells={coverage.data?.cells} />}
      </ChartCard>

      <div className="mt-4 grid gap-4 xl:grid-cols-2">
        <ChartCard title="Employee working hours" description="Hours in range, with overtime above the weekly threshold">
          {hours.loading ? <Skeleton className="h-80" /> : (
            <ResponsiveContainer width="100%" height={Math.max(260, (hours.data?.employees.length || 0) * 18)}>
              <BarChart data={hours.data?.employees || []} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid horizontal={false} stroke={t.grid} />
                <XAxis type="number" {...axisProps(t)} />
                <YAxis type="category" dataKey="name" {...axisProps(t)} width={120} tick={{ fontSize: 10, fill: t.axis }} />
                <RTooltip {...t.tooltip} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="hours" name="Hours" stackId="h" fill="#818cf8" />
                <Bar dataKey="overtime_hours" name="Overtime" stackId="o" fill="#fb7185" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
        <div className="grid gap-4">
          <ChartCard title="Labor cost estimate" description="Daily base cost by department (INR)">
            {cost.loading ? <Skeleton className="h-56" /> : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={costRows.rows}>
                  <CartesianGrid vertical={false} stroke={t.grid} />
                  <XAxis dataKey="label" {...axisProps(t)} minTickGap={12} />
                  <YAxis {...axisProps(t)} width={44} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
                  <RTooltip {...t.tooltip} formatter={(v) => fmtMoney(v)} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  {costRows.deps.map((d, i) => <Bar key={d} dataKey={d} stackId="c" fill={PALETTE[i]} />)}
                </BarChart>
              </ResponsiveContainer>
            )}
          </ChartCard>
          <ChartCard title="Night and weekend distribution" description="Unpopular shifts per employee in range">
            {hours.loading ? <Skeleton className="h-56" /> : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={(hours.data?.employees || []).slice(0, 18)}>
                  <CartesianGrid vertical={false} stroke={t.grid} />
                  <XAxis dataKey="code" {...axisProps(t)} tick={{ fontSize: 9, fill: t.axis }} interval={0} angle={-40} textAnchor="end" height={44} />
                  <YAxis {...axisProps(t)} width={24} allowDecimals={false} />
                  <RTooltip {...t.tooltip} labelFormatter={(c) => hours.data.employees.find((e) => e.code === c)?.name} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="nights" name="Night shifts" fill="#64748b" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="weekends" name="Weekend shifts" fill="#a78bfa" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </ChartCard>
        </div>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <Card className="xl:col-span-2">
          <CardHeader className="flex-row items-center justify-between gap-2">
            <div><CardTitle className="flex items-center gap-2"><Scale className="h-4 w-4" /> Fairness analysis</CardTitle><p className="text-xs text-muted-foreground">Transparent, normalized fairness score for one schedule</p></div>
            <NativeSelect className="w-72" value={scheduleId} onChange={(e) => setScheduleId(e.target.value)} aria-label="Schedule">
              {(schedules.data?.items || []).map((s) => <option key={s.id} value={s.id}>{s.department?.code} · {fmtDate(s.start_date)} – {fmtDate(s.end_date)} ({s.status})</option>)}
            </NativeSelect>
          </CardHeader>
          <CardContent>
            {fairness.loading ? <Skeleton className="h-48" /> : fairness.error ? <ErrorState error={fairness.error} /> : fairness.data && (
              <div className="grid gap-5 md:grid-cols-[200px_1fr]">
                <div className="flex flex-col items-center justify-center rounded-xl border bg-secondary/40 p-4">
                  <p className="text-xs text-muted-foreground">Fairness score</p>
                  <p className="num text-gradient text-5xl font-bold">{fairness.data.fairness_score.toFixed(0)}</p>
                  <p className="text-[11px] text-muted-foreground">out of 100</p>
                  <Button size="sm" variant="gradient" className="mt-3" onClick={() => navigate('/generator')}><Sparkles /> Rebalance</Button>
                </div>
                <div className="space-y-3">
                  {Object.entries(fairness.data.fairness_components).map(([k, v]) => (
                    <div key={k}><div className="mb-1 flex justify-between text-xs"><span className="capitalize">{k.replace(/_/g, ' ')} <span className="text-muted-foreground">x {fairness.data.fairness_weights[k]}</span></span><span className="num">{(v * 100).toFixed(1)}</span></div><Progress value={v * 100} /></div>
                  ))}
                  <p className="rounded-lg bg-secondary/60 p-2 font-mono text-[10px] leading-relaxed text-muted-foreground">{fairness.data.formula}</p>
                  {fairness.data.outliers.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5">{fairness.data.outliers.map((o) => <Badge key={o.employee_id} variant={o.direction === 'high' ? 'warning' : 'info'}>{o.name}: {o.hours}h ({o.direction} workload)</Badge>)}</div>
                  ) : <p className="text-xs text-success">No employee has an unusually high or low workload (beyond 1.5 standard deviations).</p>}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        <ChartCard title="Leave trends" description="Requests per month by type (last six months)">
          {leave.loading ? <Skeleton className="h-56" /> : leaveRows.rows.length === 0 ? <EmptyState title="No leave data" /> : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={leaveRows.rows}>
                <CartesianGrid vertical={false} stroke={t.grid} />
                <XAxis dataKey="month" {...axisProps(t)} />
                <YAxis {...axisProps(t)} width={24} allowDecimals={false} />
                <RTooltip {...t.tooltip} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                {leaveRows.types.map((ty, i) => <Bar key={ty} dataKey={ty} stackId="l" fill={PALETTE[i + 2]} />)}
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Schedule optimization comparison</CardTitle><p className="text-xs text-muted-foreground">Most recent generation run{comparison.data?.run ? ` · ${fmtDate(comparison.data.run.finished_at, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}` : ''}</p></CardHeader>
          <CardContent>
            {comparison.loading ? <Skeleton className="h-40" /> : !comparison.data?.rows.length ? <EmptyState title="No optimization runs yet" /> : (
              <Table>
                <THead><TR><TH>Strategy</TH><TH className="text-right">Coverage</TH><TH className="text-right">Fairness</TH><TH className="text-right">Pref.</TH><TH className="text-right">Cost</TH><TH className="text-right">Violations</TH></TR></THead>
                <TBody>{comparison.data.rows.map((r) => (
                  <TR key={r.strategy}><TD className="text-xs font-medium">{r.strategy}</TD><TD className="num text-right text-xs">{fmtPct(r.coverage_pct)}</TD><TD className="num text-right text-xs">{r.fairness_score.toFixed(1)}</TD><TD className="num text-right text-xs">{fmtPct(r.preference_satisfaction_pct)}</TD><TD className="num text-right text-xs">{fmtMoney(r.labor_cost)}</TD><TD className={`num text-right text-xs ${r.constraint_violations ? 'text-destructive' : 'text-success'}`}>{r.constraint_violations}</TD></TR>
                ))}</TBody>
              </Table>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex-row items-center justify-between"><div><CardTitle>Staffing shortages</CardTitle><p className="text-xs text-muted-foreground">Shifts below their requirement in range</p></div><Button size="sm" variant="outline" onClick={() => exportCsv('shortages')}><Download /> CSV</Button></CardHeader>
          <CardContent>
            {shortages.loading ? <Skeleton className="h-40" /> : !shortages.data?.shortages.length ? <EmptyState title="No shortages" description="Every shift in range is fully staffed." /> : (
              <div className="max-h-72 overflow-y-auto">
                <Table>
                  <THead><TR><TH>Date</TH><TH>Department</TH><TH>Shift</TH><TH className="text-right">Staffed</TH></TR></THead>
                  <TBody>{shortages.data.shortages.map((s) => (
                    <TR key={s.id}><TD className="num text-xs">{fmtDate(s.local_date, { weekday: 'short', day: 'numeric', month: 'short' })}</TD><TD className="text-xs">{s.department}</TD><TD className="text-xs">{s.name}</TD><TD className="text-right"><Badge variant="warning" className="num">{s.assigned_count}/{s.required_staff}</Badge></TD></TR>
                  ))}</TBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  )
}

