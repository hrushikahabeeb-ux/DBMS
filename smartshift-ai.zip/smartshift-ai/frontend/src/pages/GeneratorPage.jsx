import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { toast } from 'sonner'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis } from 'recharts'
import {
  AlertTriangle, BrainCircuit, CalendarPlus, CheckCircle2, Coins, FlaskConical, Gauge, HeartHandshake, History, Info,
  Loader2, Play, Scale, Send, Sparkles, Trash2, Trophy, XCircle,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, CardContent, CardHeader, CardTitle, Checkbox, Field, Input, NativeSelect, Progress, Skeleton, Table, TabsContent, TabsList, TabsTrigger, Tabs, TBody, TD, TH, THead, TR } from '@/components/ui/primitives'
import { ChartCard, ConfirmDialog, EmptyState, ErrorState, PageHeader, StatusBadge } from '@/components/common'
import { axisProps, useChartTheme } from '@/components/common/charts'
import { useApi } from '@/hooks/useApi'
import { api, errorMessage } from '@/services/api'
import { addDays, fmtDate, fmtDateTime, fmtMoney, fmtPct, isoDate, relativeTime, startOfWeek } from '@/utils/format'
import { cn } from '@/utils/cn'

const PRESETS = [
  { key: 'balanced', label: 'Balanced', icon: Scale, text: 'Balance fairness, preferences and labor cost.' },
  { key: 'cost', label: 'Cost Efficiency', icon: Coins, text: 'Minimize labor and overtime cost within hard constraints.' },
  { key: 'wellbeing', label: 'Employee Well-being', icon: HeartHandshake, text: 'Spread workload, nights and weekends evenly, then honor preferences.' },
]
const METRICS = [
  ['coverage_pct', 'Coverage', fmtPct, 'high'], ['fairness_score', 'Fairness score', (v) => v?.toFixed(1), 'high'],
  ['preference_satisfaction_pct', 'Preference match', fmtPct, 'high'], ['labor_cost', 'Labor cost', fmtMoney, 'low'],
  ['overtime_hours', 'Overtime hours', (v) => `${v}h`, 'low'], ['constraint_violations', 'Hard violations', (v) => v, 'low'],
  ['unfilled_count', 'Unfilled slots', (v) => v, 'low'],
]

function useRunPoller(runId, onDone) {
  const [run, setRun] = useState(null)
  const done = useRef(onDone)
  done.current = onDone
  useEffect(() => {
    if (!runId) { setRun(null); return undefined }
    let alive = true
    let timer
    const tick = async () => {
      try {
        const r = (await api.get(`/runs/${runId}`)).data
        if (!alive) return
        setRun(r)
        if (r.status === 'completed' || r.status === 'failed') { done.current?.(r); return }
      } catch (e) { if (alive) toast.error(errorMessage(e)) }
      timer = setTimeout(tick, 900)
    }
    tick()
    return () => { alive = false; clearTimeout(timer) }
  }, [runId])
  return run
}

export default function GeneratorPage() {
  const depts = useApi('/departments')
  const [dept, setDept] = useState('')
  useEffect(() => { if (!dept && depts.data?.length) setDept(depts.data[0].id) }, [depts.data, dept])
  const schedules = useApi('/schedules', { params: { department_id: dept, page_size: 30 }, enabled: Boolean(dept) })
  const [scheduleId, setScheduleId] = useState('')
  useEffect(() => {
    const items = schedules.data?.items || []
    if (!items.find((s) => s.id === scheduleId)) setScheduleId((items.find((s) => s.status === 'draft') || items[0])?.id || '')
  }, [schedules.data]) // eslint-disable-line react-hooks/exhaustive-deps
  const schedule = schedules.data?.items.find((s) => s.id === scheduleId)

  return (
    <>
      <PageHeader icon={Sparkles} eyebrow="Optimization workspace" title="AI Schedule Generator"
        description="Google OR-Tools CP-SAT searches for the schedule that satisfies every hard constraint and minimizes a weighted objective of fairness, preferences, overtime and cost. Results are compared against two baseline algorithms." />
      <Card className="mb-4 p-4">
        <div className="grid gap-3 md:grid-cols-[220px_1fr_auto]">
          <Field label="1. Department">
            <NativeSelect value={dept} onChange={(e) => { setDept(e.target.value); setScheduleId('') }}>
              {(depts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </NativeSelect>
          </Field>
          <Field label="2. Scheduling period">
            <NativeSelect value={scheduleId} onChange={(e) => setScheduleId(e.target.value)} disabled={!schedules.data?.items.length}>
              {!schedules.data?.items.length && <option>No schedules yet. Create a period.</option>}
              {(schedules.data?.items || []).map((s) => <option key={s.id} value={s.id}>{fmtDate(s.start_date)} – {fmtDate(s.end_date)} · {s.status} · {s.filled_slots}/{s.required_slots} filled</option>)}
            </NativeSelect>
          </Field>
          <div className="flex items-end"><NewPeriod departmentId={dept} onCreated={(id) => { schedules.reload().then(() => setScheduleId(id)) }} /></div>
        </div>
      </Card>
      {!schedule ? <EmptyState icon={CalendarPlus} title="Select or create a scheduling period" description="Create a 7-day draft period to generate an optimized schedule." /> : (
        <Tabs defaultValue="generate">
          <TabsList>
            <TabsTrigger value="generate"><BrainCircuit /> Generate and compare</TabsTrigger>
            <TabsTrigger value="whatif"><FlaskConical /> What-if simulation</TabsTrigger>
            <TabsTrigger value="history"><History /> Run history</TabsTrigger>
          </TabsList>
          <TabsContent value="generate"><GenerateTab schedule={schedule} onChanged={() => schedules.reload({ silent: true })} /></TabsContent>
          <TabsContent value="whatif"><WhatIfTab schedule={schedule} onChanged={() => schedules.reload({ silent: true })} /></TabsContent>
          <TabsContent value="history"><HistoryTab schedule={schedule} /></TabsContent>
        </Tabs>
      )}
    </>
  )
}

function NewPeriod({ departmentId, onCreated }) {
  const [busy, setBusy] = useState(false)
  const [start, setStart] = useState(isoDate(addDays(startOfWeek(), 14)))
  const [days, setDays] = useState(7)
  const [open, setOpen] = useState(false)
  const create = async () => {
    setBusy(true)
    try {
      const r = await api.post('/schedules', { department_id: departmentId, start_date: start, days: Number(days) })
      toast.success('Draft period created', { description: 'Shifts were generated from the department configuration.' })
      setOpen(false); onCreated(r.data.id)
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy(false) }
  }
  if (!open) return <Button variant="outline" onClick={() => setOpen(true)}><CalendarPlus /> New period</Button>
  return (
    <div className="flex items-end gap-2">
      <Field label="Start"><Input type="date" value={start} onChange={(e) => setStart(e.target.value)} className="w-40" /></Field>
      <Field label="Days"><Input type="number" min={1} max={31} value={days} onChange={(e) => setDays(e.target.value)} className="w-20" /></Field>
      <Button loading={busy} onClick={create}>Create</Button>
      <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
    </div>
  )
}

function Requirements({ schedule, onSaved }) {
  const detail = useApi(`/schedules/${schedule.id}`)
  const [values, setValues] = useState({})
  const [busy, setBusy] = useState(false)
  const templates = useMemo(() => {
    const m = {}
    for (const s of detail.data?.shifts || []) if (!m[s.template_code]) m[s.template_code] = s
    return Object.values(m)
  }, [detail.data])
  useEffect(() => setValues(Object.fromEntries(templates.map((t) => [t.template_code, t.required_staff]))), [templates])
  const dirty = templates.some((t) => Number(values[t.template_code]) !== t.required_staff)
  const save = async () => {
    setBusy(true)
    try {
      await api.patch(`/schedules/${schedule.id}/requirements`, { requirement_overrides: Object.fromEntries(Object.entries(values).map(([k, v]) => [k, Number(v)])) })
      toast.success('Staffing requirements updated'); detail.reload({ silent: true }); onSaved?.()
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy(false) }
  }
  if (detail.loading) return <Skeleton className="h-16" />
  return (
    <div>
      <p className="mb-2 text-xs font-medium text-muted-foreground">3. Staffing requirements per shift</p>
      <div className="flex flex-wrap items-end gap-2">
        {templates.map((t) => (
          <Field key={t.template_code} label={`${t.name} (${t.duration_hours}h)`}>
            <Input type="number" min={0} max={50} className="w-24" value={values[t.template_code] ?? ''} onChange={(e) => setValues((v) => ({ ...v, [t.template_code]: e.target.value }))} />
          </Field>
        ))}
        <Button variant="outline" size="sm" className="mb-0.5" disabled={!dirty} loading={busy} onClick={save}>Save requirements</Button>
      </div>
    </div>
  )
}

const STAGES = [[0, 'Queued in Redis'], [10, 'Worker picked up job'], [25, 'Loading MongoDB inputs'], [40, 'CP-SAT solving'], [100, 'Completed']]

function JobProgress({ run }) {
  if (!run) return null
  const pct = run.status === 'completed' ? 100 : Math.max(run.progress || 0, 5)
  const stage = [...STAGES].reverse().find(([p]) => pct >= p)?.[1]
  return (
    <Card className="p-4">
      <div className="mb-2 flex items-center justify-between text-sm">
        <span className="flex items-center gap-2 font-medium">{run.status === 'failed' ? <XCircle className="h-4 w-4 text-destructive" /> : run.status === 'completed' ? <CheckCircle2 className="h-4 w-4 text-success" /> : <Loader2 className="h-4 w-4 animate-spin text-primary" />}{run.status === 'failed' ? 'Optimization failed' : stage}</span>
        <span className="num text-xs text-muted-foreground">job {run.id.slice(-8)} · attempt {run.attempts || 1}</span>
      </div>
      <Progress value={pct} indicatorClassName={run.status === 'failed' ? 'from-rose-500 to-rose-600' : undefined} />
      {run.error && <p className="mt-2 text-xs text-destructive">{run.error}</p>}
    </Card>
  )
}

function GenerateTab({ schedule, onChanged }) {
  const navigate = useNavigate()
  const [presets, setPresets] = useState(['balanced', 'cost', 'wellbeing'])
  const [runId, setRunId] = useState(null)
  const [busy, setBusy] = useState(false)
  const [applying, setApplying] = useState(null)
  const [publishOpen, setPublishOpen] = useState(false)
  const latest = useApi(`/schedules/${schedule.id}/runs`)
  useEffect(() => {
    const last = latest.data?.find((r) => r.kind === 'generate')
    setRunId(last?.id || null)
  }, [latest.data])
  const run = useRunPoller(runId, (r) => { if (r.status === 'completed') onChanged() })
  const generate = async () => {
    setBusy(true)
    try {
      const r = await api.post(`/schedules/${schedule.id}/generate`, { presets })
      setRunId(r.data.job_id)
      toast('Optimization queued', { description: `Job ${r.data.job_id.slice(-8)} sent to the worker.` })
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy(false) }
  }
  const apply = async (variant) => {
    try {
      const r = await api.post(`/runs/${run.id}/apply`, { variant })
      toast.success(`${variant} schedule applied`, { description: `${r.data.assignments_created} assignments written in one MongoDB transaction.` })
      onChanged(); latest.reload({ silent: true })
    } catch (e) { toast.error(errorMessage(e)) }
  }
  const publish = async () => {
    try { await api.post(`/schedules/${schedule.id}/publish`); toast.success('Schedule published and employees notified'); onChanged() } catch (e) { toast.error(errorMessage(e)) }
  }
  const result = run?.status === 'completed' ? run.result : null
  const running = run && (run.status === 'queued' || run.status === 'running')

  return (
    <div className="space-y-4">
      <Card className="space-y-5 p-5">
        <Requirements schedule={schedule} onSaved={onChanged} />
        <div>
          <p className="mb-2 text-xs font-medium text-muted-foreground">4. Optimization priorities (select one or more to compare)</p>
          <div className="grid gap-2 md:grid-cols-3">
            {PRESETS.map((p) => {
              const on = presets.includes(p.key)
              return (
                <button key={p.key} type="button" onClick={() => setPresets((s) => (on ? s.filter((x) => x !== p.key) : [...s, p.key]))}
                  className={cn('flex items-start gap-3 rounded-xl border p-3 text-left transition', on ? 'border-primary/50 bg-primary/10 shadow-glow' : 'hover:border-primary/30')}>
                  <Checkbox checked={on} className="mt-0.5" tabIndex={-1} />
                  <div><p className="flex items-center gap-1.5 text-sm font-semibold"><p.icon className="h-4 w-4 text-primary" /> {p.label} Mode</p><p className="mt-0.5 text-xs text-muted-foreground">{p.text}</p></div>
                </button>
              )
            })}
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="gradient" size="lg" onClick={generate} loading={busy || running} disabled={!presets.length}><Play /> 5. Generate schedule</Button>
          <StatusBadge status={schedule.status} />
          <span className="num text-xs text-muted-foreground">{schedule.shift_count} shifts · {schedule.required_slots} staff slots · currently {schedule.filled_slots} filled</span>
          {schedule.status === 'draft' && schedule.filled_slots > 0 && <Button variant="outline" className="ml-auto" onClick={() => setPublishOpen(true)}><Send /> Publish schedule</Button>}
          {schedule.status === 'published' && <Button variant="outline" className="ml-auto" onClick={() => navigate('/planner')}>Open in planner</Button>}
        </div>
      </Card>
      {run && <JobProgress run={run} />}
      {result && <Results run={run} result={result} onApply={setApplying} />}
      <ConfirmDialog open={Boolean(applying)} onOpenChange={(o) => !o && setApplying(null)} title={`Apply the ${applying} schedule?`}
        description="Unlocked assignments in this period are replaced in a single transaction. Locked assignments are preserved. The result is re-validated against live data first."
        confirmLabel="Apply schedule" onConfirm={() => apply(applying)} />
      <ConfirmDialog open={publishOpen} onOpenChange={setPublishOpen} title="Publish this schedule?" description="Employees will be notified and can view their shifts." confirmLabel="Publish" onConfirm={publish} />
    </div>
  )
}

function Results({ run, result, onApply }) {
  const t = useChartTheme()
  const rows = useMemo(() => {
    const r = []
    for (const [k, v] of Object.entries(result.variants)) r.push({ key: k, label: `CP-SAT · ${PRESETS.find((p) => p.key === k)?.label || k}`, kind: 'cpsat', ...v })
    for (const [k, v] of Object.entries(result.baselines || {})) r.push({ key: k, label: k === 'greedy' ? 'Baseline · Greedy first-fit' : 'Baseline · Round robin', kind: 'baseline', ...v })
    return r
  }, [result])
  const valid = rows.filter((r) => r.metrics)
  const best = (key, dir) => {
    const vals = valid.map((r) => r.metrics[key])
    return dir === 'high' ? Math.max(...vals) : Math.min(...vals)
  }
  const short = (l) => l.replace('CP-SAT · ', '').replace('Baseline · ', '')
  const quality = valid.map((r) => ({ name: short(r.label), coverage: r.metrics.coverage_pct, fairness: r.metrics.fairness_score, preferences: r.metrics.preference_satisfaction_pct }))
  const costData = valid.map((r) => ({ name: r.label.replace('CP-SAT · ', '').replace('Baseline · ', ''), cost: r.metrics.labor_cost, violations: r.metrics.constraint_violations }))
  const anyInfeasible = rows.find((r) => r.status === 'INFEASIBLE')
  const balanced = result.variants.balanced || Object.values(result.variants)[0]

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
      <div className="grid gap-3 md:grid-cols-4">
        {Object.entries(result.variants).map(([k, v]) => (
          <Card key={k} className="p-4">
            <div className="flex items-center justify-between"><p className="text-xs font-medium text-muted-foreground">{PRESETS.find((p) => p.key === k)?.label}</p><StatusBadge status={v.status} /></div>
            <p className="num mt-2 text-2xl font-semibold">{v.metrics ? `${v.metrics.coverage_pct}%` : '—'}</p>
            <p className="num text-[11px] text-muted-foreground">solver {v.solver_status} · {v.solve_seconds}s · {v.variables ?? 0} vars</p>
          </Card>
        ))}
        <Card className="p-4">
          <p className="text-xs font-medium text-muted-foreground">Inputs</p>
          <p className="num mt-2 text-2xl font-semibold">{run.input_size?.shifts} <span className="text-sm text-muted-foreground">shifts</span></p>
          <p className="num text-[11px] text-muted-foreground">{run.input_size?.employees} employees · finished {relativeTime(run.finished_at)}</p>
        </Card>
      </div>

      {anyInfeasible && (
        <Card className="border-destructive/40 bg-destructive/5 p-4">
          <p className="flex items-center gap-2 font-semibold text-destructive"><XCircle className="h-4 w-4" /> No feasible schedule exists under the current hard constraints</p>
          <p className="mt-1 text-sm text-muted-foreground">The optimizer did not fabricate a schedule. Capacity analysis:</p>
          <Diagnosis d={anyInfeasible.diagnosis} />
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><Trophy className="h-4 w-4 text-warning" /> Strategy comparison</CardTitle><p className="text-xs text-muted-foreground">All metrics are recomputed from the actual assignments by an independent verifier. Best value per column is highlighted.</p></CardHeader>
        <CardContent>
          <Table>
            <THead><TR><TH>Strategy</TH>{METRICS.map(([k, l]) => <TH key={k} className="text-right">{l}</TH>)}<TH className="text-right">Time</TH><TH /></TR></THead>
            <TBody>
              {rows.map((r) => (
                <TR key={r.key + r.kind} className={r.kind === 'baseline' ? 'text-muted-foreground' : ''}>
                  <TD className="font-medium">{r.label}</TD>
                  {METRICS.map(([k, , fmt, dir]) => (
                    <TD key={k} className={cn('num text-right', r.metrics && r.metrics[k] === best(k, dir) && 'font-semibold text-success')}>{r.metrics ? fmt(r.metrics[k]) : '—'}</TD>
                  ))}
                  <TD className="num text-right text-xs">{r.solve_seconds}s</TD>
                  <TD className="text-right">{r.kind === 'cpsat' && r.status !== 'INFEASIBLE' && (run.applied_variant === r.key && run.applied ? <Badge variant="success">Applied</Badge> : <Button size="sm" onClick={() => onApply(r.key)}>Apply</Button>)}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <ChartCard title="Quality profile" description="Coverage, fairness and preference satisfaction per strategy (higher is better)">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={quality} barGap={2}>
              <CartesianGrid vertical={false} stroke={t.grid} />
              <XAxis dataKey="name" {...axisProps(t)} interval={0} tick={{ fontSize: 10, fill: t.axis }} />
              <YAxis {...axisProps(t)} width={32} domain={[0, 100]} />
              <RTooltip {...t.tooltip} formatter={(v) => Number(v).toFixed(1)} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="coverage" name="Coverage %" fill="#38bdf8" radius={[4, 4, 0, 0]} />
              <Bar dataKey="fairness" name="Fairness score" fill="#a78bfa" radius={[4, 4, 0, 0]} />
              <Bar dataKey="preferences" name="Preference match %" fill="#34d399" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Labor cost and hard-constraint violations" description="Lower is better for both">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={costData}>
              <CartesianGrid vertical={false} stroke={t.grid} />
              <XAxis dataKey="name" {...axisProps(t)} interval={0} tick={{ fontSize: 10, fill: t.axis }} />
              <YAxis yAxisId="l" {...axisProps(t)} width={60} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
              <YAxis yAxisId="r" orientation="right" {...axisProps(t)} width={28} allowDecimals={false} />
              <RTooltip {...t.tooltip} formatter={(v, n) => (n === 'Labor cost' ? fmtMoney(v) : v)} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar yAxisId="l" dataKey="cost" name="Labor cost" fill="#818cf8" radius={[6, 6, 0, 0]} />
              <Bar yAxisId="r" dataKey="violations" name="Violations" fill="#fb7185" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {balanced?.metrics && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><Gauge className="h-4 w-4" /> Fairness breakdown (balanced)</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(balanced.metrics.fairness_components).map(([k, v]) => (
                <div key={k}>
                  <div className="mb-1 flex justify-between text-xs"><span className="capitalize">{k.replace(/_/g, ' ')} <span className="text-muted-foreground">(weight {balanced.metrics.fairness_weights[k]})</span></span><span className="num">{(v * 100).toFixed(1)}</span></div>
                  <Progress value={v * 100} />
                </div>
              ))}
              <p className="pt-1 text-[11px] text-muted-foreground">Equity terms are 1 - Gini coefficient. Hours are normalized by each contract; nights are counted for staff who did not request them.</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><AlertTriangle className="h-4 w-4 text-warning" /> Warnings and explanations</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              {balanced.warnings.length === 0 && <p className="flex items-center gap-2 text-success"><CheckCircle2 className="h-4 w-4" /> All shifts filled with zero hard-constraint violations and no overtime.</p>}
              {balanced.warnings.map((w) => <p key={w} className="flex gap-2 text-xs"><Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" />{w}</p>)}
              {balanced.diagnosis && <Diagnosis d={balanced.diagnosis} />}
              {balanced.metrics.outliers.length > 0 && (
                <div className="pt-2"><p className="mb-1 text-xs font-medium">Workload outliers</p>{balanced.metrics.outliers.map((o) => <p key={o.employee_id} className="text-xs text-muted-foreground">{o.name}: {o.hours}h ({o.direction})</p>)}</div>
              )}
              <p className="pt-2 text-[11px] text-muted-foreground">Solver status {balanced.solver_status}: {balanced.solver_status === 'OPTIMAL' ? 'proven optimal for the weighted objective.' : 'best solution found within the time limit.'}</p>
            </CardContent>
          </Card>
        </div>
      )}
    </motion.div>
  )
}

function Diagnosis({ d }) {
  if (!d) return null
  return (
    <div className="mt-2 space-y-2 text-xs">
      <p className="num text-muted-foreground">Required {d.required_hours}h · available capacity {d.available_capacity_hours}h</p>
      {d.issues.slice(0, 8).map((i, n) => <p key={n} className="text-destructive">{i.message}{i.blocking_reasons ? ` Blocked by: ${Object.entries(i.blocking_reasons).map(([k, v]) => `${k.replace(/_/g, ' ')} (${v})`).join(', ')}` : ''}</p>)}
      {d.suggestions.length > 0 && <ul className="list-disc space-y-0.5 pl-4 text-muted-foreground">{d.suggestions.map((s) => <li key={s}>{s}</li>)}</ul>}
    </div>
  )
}

function WhatIfTab({ schedule, onChanged }) {
  const emps = useApi('/employees', { params: { department_id: schedule.department_id, page_size: 100, status: 'active' } })
  const [form, setForm] = useState({ absent_count: 3, absent_employee_ids: [], demand_increase_pct: 0, workforce_reduction_pct: 0, extra_skill: '', extra_min: 1, max_weekly_hours: '', preset: 'balanced' })
  const [runId, setRunId] = useState(null)
  const [busy, setBusy] = useState(false)
  const [applyOpen, setApplyOpen] = useState(false)
  const run = useRunPoller(runId)
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }))
  const simulate = async () => {
    setBusy(true)
    try {
      const body = { absent_count: Number(form.absent_count), absent_employee_ids: form.absent_employee_ids, demand_increase_pct: Number(form.demand_increase_pct), workforce_reduction_pct: Number(form.workforce_reduction_pct), preset: form.preset }
      if (form.extra_skill) body.extra_skill = { skill: form.extra_skill, min: Number(form.extra_min) }
      if (form.max_weekly_hours) body.max_weekly_hours = Number(form.max_weekly_hours)
      const r = await api.post(`/schedules/${schedule.id}/simulate`, body)
      setRunId(r.data.job_id)
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy(false) }
  }
  const apply = async () => {
    try {
      const r = await api.post(`/runs/${run.id}/apply`, { variant: form.preset })
      toast.success('Simulated schedule applied', { description: `${r.data.assignments_created} assignments written after re-validation against real data.` })
      onChanged()
    } catch (e) { toast.error(errorMessage(e)) }
  }
  const res = run?.status === 'completed' ? run.result : null
  const sim = res?.variants?.[form.preset]
  const cur = res?.current
  const skills = useMemo(() => [...new Set((emps.data?.items || []).flatMap((e) => e.skills))].sort(), [emps.data])

  return (
    <div className="grid gap-4 xl:grid-cols-[380px_1fr]">
      <Card className="space-y-4 p-5">
        <div><p className="text-sm font-semibold">Hypothetical scenario</p><p className="text-xs text-muted-foreground">Inputs are cloned; the published schedule is never modified by a simulation.</p></div>
        <Field label="Unexpected absences (highest-load employees)"><Input type="number" min={0} max={20} value={form.absent_count} onChange={(e) => set('absent_count', e.target.value)} /></Field>
        <Field label="Or choose specific absent employees">
          <div className="max-h-36 space-y-1 overflow-y-auto rounded-lg border p-2">
            {(emps.data?.items || []).map((e) => (
              <label key={e.id} className="flex items-center gap-2 text-xs"><Checkbox checked={form.absent_employee_ids.includes(e.id)} onCheckedChange={() => set('absent_employee_ids', form.absent_employee_ids.includes(e.id) ? form.absent_employee_ids.filter((x) => x !== e.id) : [...form.absent_employee_ids, e.id])} />{e.full_name}</label>
            ))}
          </div>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Demand increase %"><Input type="number" min={0} max={300} value={form.demand_increase_pct} onChange={(e) => set('demand_increase_pct', e.target.value)} /></Field>
          <Field label="Workforce reduction %"><Input type="number" min={0} max={90} value={form.workforce_reduction_pct} onChange={(e) => set('workforce_reduction_pct', e.target.value)} /></Field>
          <Field label="Extra qualified staff (skill)">
            <NativeSelect value={form.extra_skill} onChange={(e) => set('extra_skill', e.target.value)}><option value="">None</option>{skills.map((s) => <option key={s}>{s}</option>)}</NativeSelect>
          </Field>
          <Field label="Minimum per shift"><Input type="number" min={1} max={10} value={form.extra_min} onChange={(e) => set('extra_min', e.target.value)} disabled={!form.extra_skill} /></Field>
          <Field label="Max weekly hours (all)"><Input type="number" min={4} max={80} placeholder="unchanged" value={form.max_weekly_hours} onChange={(e) => set('max_weekly_hours', e.target.value)} /></Field>
          <Field label="Preset"><NativeSelect value={form.preset} onChange={(e) => set('preset', e.target.value)}>{PRESETS.map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}</NativeSelect></Field>
        </div>
        <Button variant="gradient" className="w-full" onClick={simulate} loading={busy || (run && !['completed', 'failed'].includes(run.status))}><FlaskConical /> Run simulation</Button>
      </Card>
      <div className="space-y-4">
        {run && <JobProgress run={run} />}
        {!run && <EmptyState icon={FlaskConical} title="Configure a scenario and run the simulation" description="Compare coverage, fairness and cost of the hypothetical schedule against the current one." />}
        {res && sim && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <Card className="p-5">
              <p className="mb-3 text-sm font-semibold">Current versus simulated</p>
              {!cur && <p className="mb-3 text-xs text-muted-foreground">The current schedule has no assignments yet; deltas are shown against an empty schedule.</p>}
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {[['coverage_pct', 'Coverage', fmtPct, 1], ['fairness_score', 'Fairness', (v) => v?.toFixed(1), 1], ['labor_cost', 'Labor cost', fmtMoney, -1], ['unfilled_count', 'Unfilled slots', (v) => v, -1]].map(([k, l, fmt, good]) => {
                  const a = cur?.[k] ?? 0
                  const b = sim.metrics?.[k] ?? 0
                  const delta = b - a
                  const better = delta * good > 0
                  return (
                    <div key={k} className="rounded-xl border p-3">
                      <p className="text-xs text-muted-foreground">{l}</p>
                      <p className="num mt-1 text-lg font-semibold">{fmt(b)}</p>
                      <p className={cn('num text-xs', delta === 0 ? 'text-muted-foreground' : better ? 'text-success' : 'text-destructive')}>{delta > 0 ? '+' : ''}{k === 'labor_cost' ? fmtMoney(delta) : Number(delta).toFixed(1)} vs current {fmt(a)}</p>
                    </div>
                  )
                })}
              </div>
              <div className="mt-4 grid gap-4 text-xs md:grid-cols-2">
                <div>
                  <p className="mb-1 font-medium">Hypothetical changes</p>
                  {res.scenario_changes.removed_employees.length > 0 && <p className="text-muted-foreground">Absent: {res.scenario_changes.removed_employees.map((e) => e.name).join(', ')}</p>}
                  {Object.keys(res.scenario_changes.requirement_changes).length > 0 && <p className="text-muted-foreground">{Object.keys(res.scenario_changes.requirement_changes).length} shift requirement(s) increased</p>}
                  {res.scenario_changes.extra_skill && <p className="text-muted-foreground">At least {res.scenario_changes.extra_skill.min} x {res.scenario_changes.extra_skill.skill} per shift</p>}
                  {res.scenario_changes.max_weekly_hours && <p className="text-muted-foreground">Max weekly hours set to {res.scenario_changes.max_weekly_hours}</p>}
                </div>
                <div><p className="mb-1 font-medium">Outcome</p><StatusBadge status={sim.status} /> {sim.warnings.map((w) => <p key={w} className="mt-1 text-muted-foreground">{w}</p>)}</div>
              </div>
              {sim.diagnosis && <Diagnosis d={sim.diagnosis} />}
              <div className="mt-4 flex gap-2">
                <Button variant="outline" onClick={() => setRunId(null)}><Trash2 /> Discard</Button>
                {sim.status !== 'INFEASIBLE' && <Button onClick={() => setApplyOpen(true)}>Apply to schedule</Button>}
              </div>
            </Card>
          </motion.div>
        )}
      </div>
      <ConfirmDialog open={applyOpen} onOpenChange={setApplyOpen} title="Apply the simulated schedule?" description="This explicitly replaces unlocked assignments. The proposal is re-validated against real data (actual availability, leave and contract limits) and rejected if anything is violated."
        confirmLabel="Apply" onConfirm={apply} />
    </div>
  )
}

function HistoryTab({ schedule }) {
  const { data, error, loading, reload } = useApi(`/schedules/${schedule.id}/runs`)
  if (error) return <ErrorState error={error} onRetry={reload} />
  if (loading) return <Skeleton className="h-40" />
  if (!data.length) return <EmptyState icon={History} title="No optimization runs yet" />
  return (
    <Card className="p-4">
      <Table>
        <THead><TR><TH>Started</TH><TH>Kind</TH><TH>Presets</TH><TH>Status</TH><TH>Applied</TH><TH className="text-right">Coverage</TH><TH className="text-right">Fairness</TH></TR></THead>
        <TBody>
          {data.map((r) => {
            const v = r.result?.variants?.[r.applied_variant || r.presets?.[0]]
            return (
              <TR key={r.id}>
                <TD className="num text-xs">{fmtDateTime(r.created_at)}</TD>
                <TD className="capitalize">{r.kind}</TD>
                <TD className="text-xs">{(r.presets || []).join(', ')}</TD>
                <TD><StatusBadge status={r.status} /></TD>
                <TD>{r.applied ? <Badge variant="success">{r.applied_variant}</Badge> : <span className="text-xs text-muted-foreground">—</span>}</TD>
                <TD className="num text-right">{v?.metrics ? `${v.metrics.coverage_pct}%` : '—'}</TD>
                <TD className="num text-right">{v?.metrics ? v.metrics.fairness_score : '—'}</TD>
              </TR>
            )
          })}
        </TBody>
      </Table>
    </Card>
  )
}
