import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { AlertTriangle, Check, Plane, Plus, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, Field, Input, NativeSelect, Table, TBody, TD, TH, THead, TR, Textarea } from '@/components/ui/primitives'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/overlay'
import { Avatar, EmptyState, ErrorState, LoadingRows, PageHeader, Pagination, StatusBadge } from '@/components/common'
import { useApi } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { api, errorMessage } from '@/services/api'
import { fmtDate, fmtDateTime, isoDate } from '@/utils/format'

const TYPES = ['annual', 'sick', 'casual', 'emergency', 'training', 'unpaid']

export default function LeavePage() {
  const { isManager, isEmployee } = useAuth()
  const [status, setStatus] = useState(isManager ? 'pending' : '')
  const [page, setPage] = useState(1)
  const [open, setOpen] = useState(false)
  const [decide, setDecide] = useState(null)
  const { data, error, loading, reload } = useApi('/leave', { params: { status: status || undefined, page, page_size: 15 } })

  return (
    <>
      <PageHeader icon={Plane} eyebrow="Time off" title="Leave Management"
        description={isManager ? 'Approving leave blocks the employee from scheduling on those dates and opens replacement planning for any affected published shifts.' : 'Request leave and track approval history.'}
        actions={isEmployee && <Button onClick={() => setOpen(true)}><Plus /> Request leave</Button>} />
      <Card className="p-4">
        <div className="mb-4 flex gap-1 rounded-lg bg-secondary p-1 sm:w-fit">
          {['pending', 'approved', 'rejected', ''].map((s) => <Button key={s || 'all'} size="sm" variant={status === s ? 'default' : 'ghost'} onClick={() => { setStatus(s); setPage(1) }} className="capitalize">{s || 'All'}</Button>)}
        </div>
        {error ? <ErrorState error={error} onRetry={reload} /> : loading && !data ? <LoadingRows /> : data.items.length === 0 ? <EmptyState icon={Plane} title="No leave requests" description={status ? `No ${status} requests.` : undefined} /> : (
          <Table>
            <THead><TR>{!isEmployee && <TH>Employee</TH>}<TH>Type</TH><TH>Dates</TH><TH>Reason</TH><TH>Requested</TH><TH>Status</TH>{isManager && <TH />}{isEmployee && <TH />}</TR></THead>
            <TBody>
              {data.items.map((l) => (
                <TR key={l.id}>
                  {!isEmployee && <TD><div className="flex items-center gap-2"><Avatar name={l.employee?.full_name} className="h-7 w-7 text-[10px]" /><div><p className="text-sm font-medium">{l.employee?.full_name}</p><p className="text-[11px] text-muted-foreground">{l.department?.name}</p></div></div></TD>}
                  <TD className="capitalize">{l.leave_type}</TD>
                  <TD className="num text-xs">{fmtDate(l.start_date, { day: 'numeric', month: 'short' })} – {fmtDate(l.end_date, { day: 'numeric', month: 'short', year: 'numeric' })}</TD>
                  <TD className="max-w-xs truncate text-xs text-muted-foreground">{l.reason}</TD>
                  <TD className="text-xs text-muted-foreground">{fmtDateTime(l.created_at)}</TD>
                  <TD><StatusBadge status={l.status} /></TD>
                  {isManager && <TD className="text-right">{l.status === 'pending' && <Button size="sm" onClick={() => setDecide(l)}>Review</Button>}</TD>}
                  {isEmployee && <TD className="text-right">{l.status === 'pending' && <Button size="sm" variant="ghost" onClick={async () => { try { await api.post(`/leave/${l.id}/cancel`); toast.success('Request cancelled'); reload({ silent: true }) } catch (e) { toast.error(errorMessage(e)) } }}>Cancel</Button>}</TD>}
                </TR>
              ))}
            </TBody>
          </Table>
        )}
        {data && <div className="mt-4"><Pagination page={data.page} pages={data.pages} total={data.total} onPage={setPage} /></div>}
      </Card>
      <RequestDialog open={open} onOpenChange={setOpen} onSaved={() => reload({ silent: true })} />
      <DecisionDialog leave={decide} onOpenChange={(o) => !o && setDecide(null)} onDone={() => reload({ silent: true })} />
    </>
  )
}

function RequestDialog({ open, onOpenChange, onSaved }) {
  const [form, setForm] = useState({ leave_type: 'annual', start_date: isoDate(new Date()), end_date: isoDate(new Date()), reason: '' })
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async (e) => {
    e.preventDefault()
    if (form.end_date < form.start_date) { setErr('End date must be on or after the start date.'); return }
    if (form.reason.trim().length < 3) { setErr('Please give a short reason.'); return }
    setBusy(true); setErr('')
    try { await api.post('/leave', form); toast.success('Leave requested', { description: 'Your manager has been notified.' }); onSaved(); onOpenChange(false) } catch (er) { setErr(errorMessage(er)) } finally { setBusy(false) }
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="sm">
        <DialogHeader><DialogTitle>Request leave</DialogTitle><DialogDescription>Approved leave is excluded from scheduling automatically.</DialogDescription></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <Field label="Leave type"><NativeSelect value={form.leave_type} onChange={(e) => setForm({ ...form, leave_type: e.target.value })}>{TYPES.map((t) => <option key={t} value={t} className="capitalize">{t}</option>)}</NativeSelect></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="From"><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></Field>
            <Field label="To"><Input type="date" value={form.end_date} min={form.start_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} /></Field>
          </div>
          <Field label="Reason"><Textarea value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} rows={3} /></Field>
          {err && <p className="text-xs text-destructive" role="alert">{err}</p>}
          <DialogFooter><Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button><Button type="submit" loading={busy}>Submit request</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function DecisionDialog({ leave, onOpenChange, onDone }) {
  const navigate = useNavigate()
  const impact = useApi(leave ? `/leave/${leave.id}/impact` : null, { enabled: Boolean(leave) })
  const [note, setNote] = useState('')
  const [busy, setBusy] = useState('')
  const [result, setResult] = useState(null)
  const decide = async (approve) => {
    setBusy(approve ? 'a' : 'r')
    try {
      const r = (await api.post(`/leave/${leave.id}/decision`, { approve, note: note || null })).data
      toast.success(`Leave ${r.status}`)
      onDone()
      if (r.replacement_required) setResult(r)
      else onOpenChange(false)
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy('') }
  }
  return (
    <Dialog open={Boolean(leave)} onOpenChange={(o) => { if (!o) { setResult(null); setNote('') } onOpenChange(o) }}>
      <DialogContent size="md">
        {leave && !result && <>
          <DialogHeader>
            <DialogTitle>{leave.employee?.full_name} · {leave.leave_type} leave</DialogTitle>
            <DialogDescription>{fmtDate(leave.start_date, { weekday: 'short', day: 'numeric', month: 'short' })} to {fmtDate(leave.end_date, { weekday: 'short', day: 'numeric', month: 'short' })} · {leave.reason}</DialogDescription>
          </DialogHeader>
          {impact.data?.count > 0 ? (
            <div className="rounded-lg border border-warning/40 bg-warning/10 p-3 text-sm"><p className="flex items-center gap-2 font-medium text-warning"><AlertTriangle className="h-4 w-4" /> Conflicts with {impact.data.count} assigned shift(s)</p><p className="mt-1 text-xs text-muted-foreground">Approving marks those assignments absent and opens them for emergency replacement.</p></div>
          ) : impact.data && <p className="text-xs text-success">No assigned shifts are affected.</p>}
          <Field label="Note (optional)"><Textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} /></Field>
          <DialogFooter>
            <Button variant="outline" loading={busy === 'r'} onClick={() => decide(false)}><X /> Reject</Button>
            <Button variant="success" loading={busy === 'a'} onClick={() => decide(true)}><Check /> Approve</Button>
          </DialogFooter>
        </>}
        {result && <>
          <DialogHeader><DialogTitle>Replacement planning started</DialogTitle><DialogDescription>{result.affected_assignments.length} shift(s) now need cover. Ranked, validated candidates are ready.</DialogDescription></DialogHeader>
          <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Later</Button><Button onClick={() => navigate('/emergency')}>Open Emergency Replacement</Button></DialogFooter>
        </>}
      </DialogContent>
    </Dialog>
  )
}
