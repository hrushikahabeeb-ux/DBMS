import { useState } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Activity, ArrowRight, BrainCircuit, CalendarCheck2, Lock, Mail, ShieldCheck, Siren } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, Field, Input } from '@/components/ui/primitives'
import { useAuth } from '@/contexts/AuthContext'
import { errorMessage } from '@/services/api'

const DEMO = [
  { label: 'Super Admin', email: 'admin@smartshift.ai', password: 'Admin@123', note: 'Organization-wide' },
  { label: 'ER Manager', email: 'er.manager@smartshift.ai', password: 'Manager@123', note: 'Emergency dept.' },
  { label: 'Employee', email: 'ananya.sharma@smartshift.ai', password: 'Employee@123', note: 'Senior Nurse, ER' },
]

const FEATURES = [
  { icon: BrainCircuit, title: 'Constraint optimization', text: 'Google OR-Tools CP-SAT balances coverage, fairness, preferences and cost.' },
  { icon: ShieldCheck, title: 'Explainable decisions', text: 'Every assignment is backed by the exact constraint checks that allowed it.' },
  { icon: Siren, title: 'Emergency recovery', text: 'Ranked, validated replacements in seconds when someone calls in sick.' },
]

export default function LoginPage() {
  const { user, login } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  if (user) return <Navigate to={location.state?.from || '/'} replace />

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    if (!email || !password) { setError('Enter your email and password.'); return }
    setBusy(true)
    try {
      await login(email.trim(), password)
      navigate(location.state?.from || '/', { replace: true })
    } catch (err) {
      setError(errorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="grid min-h-full lg:grid-cols-[1.1fr_1fr]">
      <div className="relative hidden overflow-hidden border-r bg-surface lg:block">
        <div className="grid-bg absolute inset-0 opacity-40 [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" />
        <div className="absolute -left-24 top-24 h-80 w-80 rounded-full bg-indigo-600/30 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-fuchsia-600/20 blur-3xl" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-glow">
              <Activity className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="font-bold tracking-tight">SmartShift <span className="text-gradient">AI</span></p>
              <p className="text-xs text-muted-foreground">City General Hospital</p>
            </div>
          </div>
          <div>
            <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="max-w-lg text-4xl font-semibold leading-tight tracking-tight">
              Intelligent workforce scheduling that is <span className="text-gradient">fair, safe and explainable.</span>
            </motion.h1>
            <div className="mt-10 grid max-w-lg gap-4">
              {FEATURES.map((f, i) => (
                <motion.div key={f.title} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 + i * 0.08 }} className="flex gap-4 rounded-xl border bg-card/60 p-4 backdrop-blur">
                  <f.icon className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
                  <div>
                    <p className="text-sm font-semibold">{f.title}</p>
                    <p className="text-xs text-muted-foreground">{f.text}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
          <p className="flex items-center gap-2 text-xs text-muted-foreground"><CalendarCheck2 className="h-4 w-4" /> FastAPI · MongoDB · OR-Tools CP-SAT · React</p>
        </div>
      </div>

      <div className="flex items-center justify-center p-6">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-sm">
          <h2 className="text-2xl font-semibold tracking-tight">Sign in</h2>
          <p className="mt-1 text-sm text-muted-foreground">Access your scheduling workspace.</p>
          <form onSubmit={submit} className="mt-8 space-y-4" noValidate>
            <Field label="Email">
              <div className="relative">
                <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input type="email" autoComplete="email" className="h-10 pl-9" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@smartshift.ai" aria-invalid={Boolean(error)} />
              </div>
            </Field>
            <Field label="Password">
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input type="password" autoComplete="current-password" className="h-10 pl-9" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" aria-invalid={Boolean(error)} />
              </div>
            </Field>
            {error && <p role="alert" className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">{error}</p>}
            <Button type="submit" variant="gradient" size="lg" className="w-full" loading={busy}>Sign in <ArrowRight /></Button>
          </form>

          <Card className="mt-8 p-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Expo demo accounts</p>
            <div className="mt-3 grid gap-2">
              {DEMO.map((d) => (
                <button key={d.email} type="button" onClick={() => { setEmail(d.email); setPassword(d.password); setError('') }}
                  className="flex items-center justify-between rounded-lg border px-3 py-2 text-left transition hover:border-primary/40 hover:bg-primary/5">
                  <span>
                    <span className="block text-sm font-medium">{d.label}</span>
                    <span className="block text-[11px] text-muted-foreground">{d.email}</span>
                  </span>
                  <span className="text-[11px] text-muted-foreground">{d.note}</span>
                </button>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}
