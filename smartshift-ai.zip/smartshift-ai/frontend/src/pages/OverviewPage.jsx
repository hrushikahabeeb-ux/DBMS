import { useEffect, useMemo } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis } from 'recharts'
import {
  AlertTriangle, ArrowRight, Building2, CalendarCheck, CalendarClock, CalendarRange, Clock, Flame, Gauge, LayoutDashboard,
  Plane, Repeat2, Siren, Sparkles, UserCheck, Users,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, CardContent, CardHeader, CardTitle, Progress, Skeleton } from '@/components/ui/primitives'
import { Avatar, ChartCard, EmptyState, ErrorState, PageHeader, StatCard, StatusBadge } from '@/components/common'
import CoverageHeatmap from '@/components/common/CoverageHeatmap'
import { axisProps, useChartTheme } from '@/components/common/charts'
import { useApi } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { useNotifications } from '@/contexts/NotificationContext'
import { addDays, fmtDate, fmtDateTime, fmtNum, fmtTime, isoDate, relativeTime, SHIFT_COLORS } from '@/utils/format'

export default function OverviewPage() {
  const { isEmployee } = useAuth()
  return isEmployee ? <EmployeeHome /> : <ManagerOverview />
}

function greeting() {
  const h = new Date().getHours()
  return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'
}

function ManagerOverview() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const t = useChartTheme()
  const { lastEvent } = useNotifications()
  const { data, error, loading, reload } = useApi('/analytics/overview')
  const today = new Date()
  const cov = useApi('/analytics/coverage', { params: { start: isoDate(today), end: isoDate(addDays(today, 6)) } })
  useEffect(() => { if (lastEvent) { reload({ silent: true }); cov.reload({ silent: true }) } }, [lastEvent]) // eslint-disable-line react-hooks/exhaustive-deps
  const k = data?.kpis || {}
  const weekly = useMemo(() => (data?.weekly_distribution || []).map((d) => ({ ...d, label: fmtDate(d.date, { weekday: 'short', day: 'numeric' }), gap: d.required - d.filled })), [data])

  if (error) return <ErrorState error={error} onRetry={reload} />
  return (
    <>
      <PageHeader icon={LayoutDashboard} eyebrow="Workforce overview" title={`${greeting()}, ${user.full_name.split(' ')[0]}`}
        description={`Live staffing status as of ${data ? fmtDateTime(data.as_of) : '...'}. All figures are computed from MongoDB in real time.`}
        actions={<>
          <Button variant="outline" onClick={() => navigate('/emergency')}><Siren /> Emergency cover</Button>
          <Button variant="gradient" onClick={() => navigate('/generator')}><Sparkles /> Generate schedule</Button>
        </>} />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard loading={loading} label="Total employees" value={fmtNum(k.total_employees)} icon={Users} delay={0} />
        <StatCard loading={loading} label="Scheduled next 24h" value={fmtNum(k.scheduled_today)} icon={UserCheck} tone="success" delay={0.03} />
        <StatCard loading={loading} label="Active departments" value={fmtNum(k.active_departments)} icon={Building2} tone="violet" delay={0.06} />
        <StatCard loading={loading} label="Today's shifts" value={fmtNum(k.todays_shifts)} icon={CalendarCheck} tone="info" delay={0.09} />
        <StatCard loading={loading} label="Unfilled shifts (7 days)" value={fmtNum(k.unfilled_shifts)} hint={`${fmtNum(k.unfilled_slots)} open staff slots`} icon={AlertTriangle} tone={k.unfilled_shifts ? 'danger' : 'success'} delay={0.12} />
        <StatCard loading={loading} label="On leave today" value={fmtNum(k.employees_on_leave)} icon={Plane} tone="warning" delay={0.15} />
        <StatCard loading={loading} label="Overtime risk" value={fmtNum(k.overtime_risk)} hint="Above threshold or 90% of contract" icon={Flame} tone={k.overtime_risk ? 'warning' : 'success'} delay={0.18} />
        <StatCard loading={loading} label="Weekly coverage" value={k.weekly_coverage_pct != null ? `${k.weekly_coverage_pct}%` : '—'} hint="Filled / required, next 7 days" icon={Gauge} tone="primary" delay={0.21} />
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <ChartCard className="xl:col-span-2" title="Weekly workforce distribution" description="Required versus filled staff slots for the next seven days">
          {loading ? <Skeleton className="h-64 w-full" /> : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={weekly} barGap={4}>
                <CartesianGrid vertical={false} stroke={t.grid} />
                <XAxis dataKey="label" {...axisProps(t)} />
                <YAxis {...axisProps(t)} width={32} />
                <RTooltip {...t.tooltip} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="filled" name="Filled" stackId="a" fill="#818cf8" />
                <Bar dataKey="gap" name="Open" stackId="a" fill="#fb7185" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
        <ChartCard title="Scheduling alerts" description="Conflicts needing attention">
          {loading ? <Skeleton className="h-64" /> : (
            <div className="space-y-2 px-2">
              <button onClick={() => navigate('/emergency')} className="flex w-full items-center justify-between rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2.5 text-left transition hover:bg-destructive/10">
                <span className="flex items-center gap-2 text-sm"><Siren className="h-4 w-4 text-destructive" /> Open absences needing cover</span>
                <span className="num text-lg font-semibold text-destructive">{data.alerts.open_vacancies}</span>
              </button>
              {data.alerts.understaffed_shifts.length === 0 && <EmptyState title="No understaffed shifts" description="Every shift in the next week meets its staffing requirement." className="py-6" />}
              {data.alerts.understaffed_shifts.slice(0, 5).map((s) => (
                <div key={s.id} className="flex items-center justify-between rounded-lg border px-3 py-2">
                  <div>
                    <p className="text-[13px] font-medium">{s.department} · {s.name}</p>
                    <p className="text-[11px] text-muted-foreground">{fmtDate(s.local_date, { weekday: 'short', day: 'numeric', month: 'short' })} · schedule {s.schedule_status}</p>
                  </div>
                  <Badge variant="warning" className="num">{s.assigned_count}/{s.required_staff}</Badge>
                </div>
              ))}
            </div>
          )}
        </ChartCard>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-3">
        <ChartCard className="xl:col-span-2" title="Staffing coverage heatmap" description="Filled versus required staff per shift for the next seven days">
          {cov.loading ? <Skeleton className="h-40" /> : <CoverageHeatmap cells={cov.data?.cells} />}
        </ChartCard>
        <Card>
          <CardHeader><CardTitle>Department staffing</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {loading ? <Skeleton className="h-32" /> : data.department_overview.map((d) => {
              const pct = d.required ? Math.round((100 * d.filled) / d.required) : 100
              return (
                <div key={d.id}>
                  <div className="mb-1.5 flex items-center justify-between text-xs">
                    <span className="font-medium">{d.name}</span>
                    <span className="num text-muted-foreground">{d.filled}/{d.required} · {d.staff} staff</span>
                  </div>
                  <Progress value={pct} indicatorClassName={pct < 85 ? 'from-amber-500 to-rose-500' : undefined} />
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2 xl:grid-cols-4">
        <Card className="xl:col-span-2">
          <CardHeader className="flex-row items-center justify-between"><CardTitle>Upcoming shifts</CardTitle><Link to="/planner" className="text-xs text-primary hover:underline">Open planner</Link></CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-48" /> : data.timeline.length === 0 ? <EmptyState title="No shifts in the next 30 hours" /> : (
              <ol className="relative space-y-3 border-l pl-5">
                {data.timeline.map((s) => (
                  <li key={s.id} className="relative">
                    <span className="absolute -left-[25px] top-1.5 h-2.5 w-2.5 rounded-full ring-4 ring-background" style={{ background: SHIFT_COLORS[s.template_code]?.bg || '#818cf8' }} />
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="text-[13px] font-medium">{s.department?.name} · {s.name} <span className="num text-xs text-muted-foreground">{fmtTime(s.start)}–{fmtTime(s.end)}</span></p>
                      <Badge variant={s.assigned_count >= s.required_staff ? 'success' : 'warning'} className="num">{s.assigned_count}/{s.required_staff}</Badge>
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">{fmtDate(s.start, { weekday: 'short', day: 'numeric', month: 'short' })} · {s.assignees.join(', ') || 'No one assigned'}</p>
                  </li>
                ))}
              </ol>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Availability summary</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            {loading ? <Skeleton className="h-32" /> : (<>
              <Row label="Submitted availability" value={`${data.availability.with_availability}/${data.availability.employees}`} />
              <Row label="Unavailable today" value={data.availability.unavailable_today} />
              <div className="pt-1">
                <p className="mb-2 text-xs text-muted-foreground">Shift preferences</p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.entries(data.availability.preferences).map(([code, n]) => (
                    <Badge key={code} variant="secondary" className="capitalize">{code} <span className="num">{n}</span></Badge>
                  ))}
                </div>
              </div>
              <div className="pt-2">
                <p className="mb-2 text-xs text-muted-foreground">Overtime risk this week</p>
                {data.overtime_risk.length === 0 ? <p className="text-xs text-muted-foreground">Nobody is near their limit.</p> : data.overtime_risk.slice(0, 4).map((o) => (
                  <div key={o.id} className="flex justify-between text-xs"><span>{o.name}</span><span className="num">{o.hours}h / {o.max}h</span></div>
                ))}
              </div>
            </>)}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex-row items-center justify-between"><CardTitle>Recent activity</CardTitle><Link to="/audit" className="text-xs text-primary hover:underline">Audit log</Link></CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-48" /> : (
              <ul className="space-y-3">
                {data.activity.map((a) => (
                  <li key={a.id} className="flex gap-2.5">
                    <Avatar name={a.actor_email} className="h-6 w-6 text-[9px]" />
                    <div className="min-w-0">
                      <p className="truncate text-xs"><span className="font-medium">{a.actor_email.split('@')[0]}</span> <span className="text-muted-foreground">{a.action.replace('.', ' ')}</span></p>
                      <p className="text-[10px] text-muted-foreground">{relativeTime(a.created_at)}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4 p-4">
        <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Quick actions</p>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
          {[
            ['/generator', Sparkles, 'Generate a 7-day schedule'],
            ['/planner', CalendarRange, 'Open shift planner'],
            ['/leave', Plane, 'Review leave requests'],
            ['/swaps', Repeat2, 'Approve shift swaps'],
            ['/analytics', Gauge, 'Fairness and cost analytics'],
          ].map(([to, Icon, label]) => (
            <Button key={to} variant="secondary" className="justify-between" onClick={() => navigate(to)}><span className="flex items-center gap-2"><Icon /> {label}</span><ArrowRight className="opacity-50" /></Button>
          ))}
        </div>
      </Card>
    </>
  )
}

function Row({ label, value }) {
  return <div className="flex items-center justify-between"><span className="text-xs text-muted-foreground">{label}</span><span className="num font-semibold">{value}</span></div>
}

function EmployeeHome() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const t = useChartTheme()
  const { lastEvent } = useNotifications()
  const { data, error, loading, reload } = useApi('/me/overview')
  useEffect(() => { if (lastEvent) reload({ silent: true }) }, [lastEvent]) // eslint-disable-line react-hooks/exhaustive-deps
  if (error) return <ErrorState error={error} onRetry={reload} />
  const next = data?.upcoming?.[0]
  const thisWeek = data?.weekly_hours?.find((w) => w.week === isoWeek(new Date()))
  return (
    <>
      <PageHeader icon={LayoutDashboard} eyebrow="My workspace" title={`Hello, ${user.full_name.split(' ')[0]}`} description="Your upcoming shifts, working hours and requests."
        actions={<><Button variant="outline" onClick={() => navigate('/leave')}><Plane /> Request leave</Button><Button variant="gradient" onClick={() => navigate('/planner')}><CalendarRange /> My schedule</Button></>} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard loading={loading} label="Next shift" value={next ? fmtDate(next.start, { weekday: 'short', day: 'numeric' }) : 'None'} hint={next ? `${next.shift?.name} · ${fmtTime(next.start)}` : 'No published shifts'} icon={Clock} />
        <StatCard loading={loading} label="Hours this week" value={thisWeek ? `${thisWeek.hours}h` : '0h'} hint={`Contract ${data?.employee?.max_weekly_hours ?? '—'}h`} icon={Gauge} tone="violet" />
        <StatCard loading={loading} label="Upcoming shifts" value={data?.upcoming?.length ?? 0} icon={CalendarCheck} tone="success" />
        <StatCard loading={loading} label="Pending requests" value={(data?.pending_swaps_for_me ?? 0) + (data?.pending_leave ?? 0)} hint={`${data?.pending_swaps_for_me ?? 0} swap · ${data?.pending_leave ?? 0} leave`} icon={Repeat2} tone="warning" />
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Upcoming shifts</CardTitle></CardHeader>
          <CardContent>
            {loading ? <Skeleton className="h-40" /> : data.upcoming.length === 0 ? <EmptyState icon={CalendarClock} title="No upcoming shifts" description="Published schedules will appear here." /> : (
              <div className="space-y-2">
                {data.upcoming.map((a) => (
                  <div key={a.id} className="flex items-center justify-between rounded-lg border px-3 py-2.5">
                    <div className="flex items-center gap-3">
                      <span className="h-8 w-1 rounded-full" style={{ background: SHIFT_COLORS[a.shift?.template_code]?.bg }} />
                      <div>
                        <p className="text-sm font-medium">{a.shift?.name} · {a.department?.name}</p>
                        <p className="num text-xs text-muted-foreground">{fmtDate(a.start, { weekday: 'long', day: 'numeric', month: 'short' })} · {fmtTime(a.start)}–{fmtTime(a.end)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {a.source !== 'optimizer' && <StatusBadge status={a.source} />}
                      {new Date(a.start) > new Date() ? <Button size="sm" variant="ghost" onClick={() => navigate(`/swaps?assignment=${a.id}`)}><Repeat2 /> Swap</Button> : <Badge variant="success">In progress</Badge>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
        <ChartCard title="Weekly working hours" description="Published assignments by ISO week">
          {loading ? <Skeleton className="h-56" /> : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={data.weekly_hours}>
                <CartesianGrid vertical={false} stroke={t.grid} />
                <XAxis dataKey="week" {...axisProps(t)} tickFormatter={(w) => w.split('-')[1]} />
                <YAxis {...axisProps(t)} width={28} />
                <RTooltip {...t.tooltip} />
                <Bar dataKey="hours" name="Hours" fill="#a78bfa" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
      </div>
    </>
  )
}

function isoWeek(d) {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()))
  const day = date.getUTCDay() || 7
  date.setUTCDate(date.getUTCDate() + 4 - day)
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1))
  const week = Math.ceil(((date - yearStart) / 86400000 + 1) / 7)
  return `${date.getUTCFullYear()}-W${String(week).padStart(2, '0')}`
}
