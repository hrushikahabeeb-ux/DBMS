import { useState } from 'react'
import { Bell, BellOff, CalendarCheck, CheckCheck, Plane, Repeat2, Siren, Sparkles, Wifi, WifiOff } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card } from '@/components/ui/primitives'
import { EmptyState, PageHeader } from '@/components/common'
import { useNotifications } from '@/contexts/NotificationContext'
import { fmtDateTime, relativeTime } from '@/utils/format'
import { cn } from '@/utils/cn'

const ICONS = { shift: CalendarCheck, schedule: CalendarCheck, leave: Plane, swap: Repeat2, replacement: Siren, optimization: Sparkles }

export default function NotificationsPage() {
  const { items, unread, connected, markRead, markAll, refresh } = useNotifications()
  const [filter, setFilter] = useState('all')
  const shown = items.filter((n) => (filter === 'unread' ? !n.read : true))
  return (
    <>
      <PageHeader icon={Bell} eyebrow="Inbox" title="Notifications" description="Delivered in real time over WebSockets by the notification service and persisted in MongoDB."
        actions={<>
          {connected ? <Badge variant="success"><Wifi className="h-3 w-3" /> Live connection</Badge> : <Badge variant="secondary"><WifiOff className="h-3 w-3" /> Reconnecting</Badge>}
          <Button variant="outline" onClick={refresh}>Refresh</Button>
          <Button onClick={markAll} disabled={!unread}><CheckCheck /> Mark all read</Button>
        </>} />
      <Card className="p-4">
        <div className="mb-4 flex gap-1 rounded-lg bg-secondary p-1 sm:w-fit">
          {[['all', 'All'], ['unread', `Unread (${unread})`]].map(([k, l]) => <Button key={k} size="sm" variant={filter === k ? 'default' : 'ghost'} onClick={() => setFilter(k)}>{l}</Button>)}
        </div>
        {shown.length === 0 ? <EmptyState icon={BellOff} title={filter === 'unread' ? 'No unread notifications' : 'No notifications yet'} /> : (
          <div className="divide-y rounded-xl border">
            {shown.map((n) => {
              const Icon = ICONS[n.type.split('.')[0]] || Bell
              return (
                <div key={n.id} className={cn('flex items-start gap-3 p-4 transition', !n.read && 'bg-primary/5')}>
                  <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-lg', n.read ? 'bg-secondary text-muted-foreground' : 'bg-primary/15 text-primary')}><Icon className="h-4 w-4" /></div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2"><p className="text-sm font-medium">{n.title}</p><Badge variant="outline" className="text-[10px]">{n.type}</Badge></div>
                    <p className="text-sm text-muted-foreground">{n.message}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground">{relativeTime(n.created_at)} · {fmtDateTime(n.created_at)}</p>
                  </div>
                  {!n.read && <Button size="sm" variant="ghost" onClick={() => markRead(n.id)}>Mark read</Button>}
                </div>
              )
            })}
          </div>
        )}
      </Card>
    </>
  )
}
