import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { toast } from 'sonner'
import { ArrowDownUp, MoreHorizontal, Pencil, Plus, Power, Search, UserRound, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, Input, NativeSelect, Table, TBody, TD, TH, THead, TR } from '@/components/ui/primitives'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/overlay'
import { Avatar, ConfirmDialog, EmptyState, ErrorState, LoadingRows, PageHeader, Pagination, StatusBadge } from '@/components/common'
import EmployeeForm from '@/components/common/EmployeeForm'
import { useApi, useDebounce } from '@/hooks/useApi'
import { api, errorMessage } from '@/services/api'
import { fmtMoney } from '@/utils/format'

const SORTS = [
  ['full_name', 'Name (A-Z)'], ['-full_name', 'Name (Z-A)'], ['employee_code', 'Employee ID'], ['-hourly_wage', 'Wage (high-low)'],
  ['hourly_wage', 'Wage (low-high)'], ['-max_weekly_hours', 'Weekly hours'], ['joining_date', 'Joining date'],
]

export default function EmployeesPage() {
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const [search, setSearch] = useState(params.get('search') || '')
  const [dept, setDept] = useState('')
  const [skill, setSkill] = useState('')
  const [status, setStatus] = useState('active')
  const [sort, setSort] = useState('full_name')
  const [page, setPage] = useState(1)
  const [editing, setEditing] = useState(null)
  const [formOpen, setFormOpen] = useState(false)
  const [confirm, setConfirm] = useState(null)
  const q = useDebounce(search)

  const depts = useApi('/departments')
  const facets = useApi('/employees/facets')
  const list = useApi('/employees', { params: { search: q || undefined, department_id: dept || undefined, skill: skill || undefined, status: status || undefined, sort, page, page_size: 15 } })
  const deptName = Object.fromEntries((depts.data || []).map((d) => [d.id, d.name]))

  const reset = (fn) => (v) => { fn(v); setPage(1) }

  const toggleStatus = async (e) => {
    try {
      if (e.status === 'active') {
        const r = await api.delete(`/employees/${e.id}`)
        toast.success(`${e.full_name} deactivated`, { description: r.data.upcoming_assignments_to_review ? `${r.data.upcoming_assignments_to_review} upcoming assignment(s) should be reviewed for replacement.` : 'They will not receive new assignments.' })
      } else {
        await api.post(`/employees/${e.id}/reactivate`)
        toast.success(`${e.full_name} reactivated`)
      }
      list.reload({ silent: true })
    } catch (err) { toast.error(errorMessage(err)) }
  }

  return (
    <>
      <PageHeader icon={Users} eyebrow="People" title="Employees" description="Manage staff records, qualifications, eligibility and contract limits."
        actions={<Button onClick={() => { setEditing(null); setFormOpen(true) }}><Plus /> Add employee</Button>} />
      <Card className="p-4">
        <div className="mb-4 grid gap-2 md:grid-cols-[1fr_180px_180px_140px_180px]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => reset(setSearch)(e.target.value)} placeholder="Search name, ID, email or role" className="pl-9" aria-label="Search employees" />
          </div>
          <NativeSelect value={dept} onChange={(e) => reset(setDept)(e.target.value)} aria-label="Department filter">
            <option value="">All departments</option>
            {(depts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </NativeSelect>
          <NativeSelect value={skill} onChange={(e) => reset(setSkill)(e.target.value)} aria-label="Skill filter">
            <option value="">Any skill</option>
            {(facets.data?.skills || []).map((s) => <option key={s} value={s}>{s}</option>)}
          </NativeSelect>
          <NativeSelect value={status} onChange={(e) => reset(setStatus)(e.target.value)} aria-label="Status filter">
            <option value="">Any status</option><option value="active">Active</option><option value="inactive">Inactive</option>
          </NativeSelect>
          <div className="relative">
            <ArrowDownUp className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <NativeSelect value={sort} onChange={(e) => setSort(e.target.value)} className="pl-8" aria-label="Sort">
              {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </NativeSelect>
          </div>
        </div>

        {list.error ? <ErrorState error={list.error} onRetry={list.reload} /> : list.loading && !list.data ? <LoadingRows rows={8} /> : list.data.items.length === 0 ? (
          <EmptyState icon={UserRound} title="No employees match these filters" description="Try clearing the search or filters." />
        ) : (
          <Table>
            <THead><TR className="hover:bg-transparent"><TH>Employee</TH><TH>Role</TH><TH>Departments</TH><TH>Skills</TH><TH className="text-right">Max h/week</TH><TH className="text-right">Wage</TH><TH>Status</TH><TH /></TR></THead>
            <TBody>
              {list.data.items.map((e) => (
                <TR key={e.id} className="cursor-pointer" onClick={() => navigate(`/employees/${e.id}`)}>
                  <TD>
                    <div className="flex items-center gap-3">
                      <Avatar name={e.full_name} />
                      <div><p className="font-medium">{e.full_name}</p><p className="num text-[11px] text-muted-foreground">{e.employee_code} · {e.email}</p></div>
                    </div>
                  </TD>
                  <TD className="text-xs">{e.job_role}</TD>
                  <TD><div className="flex flex-wrap gap-1">{e.department_ids.map((d) => <Badge key={d} variant={d === e.primary_department_id ? 'default' : 'secondary'}>{deptName[d] || '...'}</Badge>)}</div></TD>
                  <TD><div className="flex max-w-[240px] flex-wrap gap-1">{e.skills.map((s) => <Badge key={s} variant="outline">{s}</Badge>)}</div></TD>
                  <TD className="num text-right">{e.max_weekly_hours}</TD>
                  <TD className="num text-right">{fmtMoney(e.hourly_wage)}</TD>
                  <TD><StatusBadge status={e.status} /></TD>
                  <TD onClick={(ev) => ev.stopPropagation()}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="icon-sm" aria-label="Actions"><MoreHorizontal /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onSelect={() => navigate(`/employees/${e.id}`)}><UserRound /> View profile</DropdownMenuItem>
                        <DropdownMenuItem onSelect={() => { setEditing(e); setFormOpen(true) }}><Pencil /> Edit</DropdownMenuItem>
                        <DropdownMenuItem onSelect={() => setConfirm(e)} className={e.status === 'active' ? 'text-destructive focus:text-destructive' : ''}><Power /> {e.status === 'active' ? 'Deactivate' : 'Reactivate'}</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
        {list.data && <div className="mt-4"><Pagination page={list.data.page} pages={list.data.pages} total={list.data.total} onPage={setPage} /></div>}
      </Card>

      <EmployeeForm open={formOpen} onOpenChange={setFormOpen} employee={editing} departments={depts.data || []} onSaved={() => list.reload({ silent: true })} />
      <ConfirmDialog open={Boolean(confirm)} onOpenChange={(o) => !o && setConfirm(null)}
        title={confirm?.status === 'active' ? `Deactivate ${confirm?.full_name}?` : `Reactivate ${confirm?.full_name}?`}
        description={confirm?.status === 'active' ? 'Deactivated employees cannot receive new assignments and their login is disabled. History is preserved.' : 'The employee becomes eligible for scheduling again.'}
        variant={confirm?.status === 'active' ? 'destructive' : 'default'} confirmLabel={confirm?.status === 'active' ? 'Deactivate' : 'Reactivate'}
        onConfirm={() => toggleStatus(confirm)} />
    </>
  )
}
