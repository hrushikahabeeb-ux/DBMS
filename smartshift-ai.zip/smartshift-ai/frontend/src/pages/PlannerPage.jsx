import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import timeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction'
import { toast } from 'sonner'
import { AlertTriangle, CalendarRange, CheckCircle2, Lock, RefreshCw, Repeat2, Send, ShieldAlert, Undo2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, NativeSelect, Skeleton, Switch } from '@/components/ui/primitives'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/overlay'
import { ConfirmDialog, EmptyState, ErrorState, PageHeader, StatusBadge } from '@/components/common'
import { AssignmentDialog, ShiftDialog } from '@/components/common/ScheduleDialogs'
import { useApi } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { useNotifications } from '@/contexts/NotificationContext'
import { api, errorMessage } from '@/services/api'
import { fmtDate, fmtTime, isoDate, SHIFT_COLORS } from '@/utils/format'

export default function PlannerPage() {
  const { isEmployee } = useAuth()
  return isEmployee ? <EmployeeCalendar /> : <ManagerPlanner />
}

function useCalendarRange() {
  const [range, setRange] = useState(null)
  const onDatesSet = useCallback((arg) => {
    const start = isoDate(arg.start)
    const end = isoDate(new Date(arg.end.getTime() - 1))
    setRange((r) => (r?.start === start && r?.end === end ? r : { start, end }))
  }, [])
  return [range, onDatesSet]
}

function ManagerPlanner() {
  const navigate = useNavigate()
  const { lastEvent } = useNotifications()
  const calRef = useRef(null)
  const [range, onDatesSet] = useCalendarRange()
  const [dept, setDept] = useState('')
  const [employee, setEmployee] = useState('')
  const [showOpen, setShowOpen] = useState(true)
  const [selShift, setSelShift] = useState(null)
  const [selAssign, setSelAssign] = useState(null)
  const [conflict, setConflict] = useState(null)
  const [publishing, setPublishing] = useState(null)
  const depts = useApi('/departments')
  const emps = useApi('/employees', { params: { department_id: dept || undefined, page_size: 100, status: 'active' } })
  const cal = useApi('/calendar', { params: { ...range, department_id: dept || undefined, employee_id: employee || undefined }, enabled: Boolean(range) })
  const schedules = useApi('/schedules', { params: { department_id: dept || undefined, page_size: 50 } })
  useEffect(() => { if (lastEvent) cal.reload({ silent: true }) }, [lastEvent]) // eslint-disable-line react-hooks/exhaustive-deps

  const shiftsById = useMemo(() => Object.fromEntries((cal.data?.shifts || []).map((s) => [s.id, s])), [cal.data])
  const visibleSchedules = useMemo(() => {
    if (!range || !schedules.data) return []
    return schedules.data.items.filter((s) => s.start_date <= range.end && s.end_date >= range.start)
  }, [schedules.data, range])

  const events = useMemo(() => {
    if (!cal.data) return []
    const out = []
    for (const a of cal.data.assignments) {
      const s = shiftsById[a.shift_id]
      if (!s) continue
      const c = SHIFT_COLORS[s.template_code] || { bg: '#6366f1' }
      const absent = a.status === 'absent'
      out.push({
        id: a.id, start: a.start, end: a.end, title: a.employee?.full_name || 'Employee',
        backgroundColor: absent ? 'rgba(244,63,94,0.18)' : c.bg, borderColor: absent ? '#f43f5e' : c.bg,
        textColor: absent ? '#fb7185' : '#fff', editable: !absent,
        classNames: [s.schedule?.status === 'draft' ? 'opacity-80' : '', absent ? 'line-through' : ''],
        extendedProps: { kind: 'assignment', assignment: a, shift: s },
      })
    }
    if (showOpen && !employee) {
      for (const s of cal.data.shifts) {
        const active = cal.data.assignments.filter((a) => a.shift_id === s.id && a.status === 'active').length
        const missing = s.required_staff - active
        if (missing > 0) {
          out.push({
            id: `open-${s.id}`, start: s.start, end: s.end, title: `${missing} open · ${s.department?.code} ${s.name}`,
            backgroundColor: 'transparent', borderColor: '#f59e0b', textColor: '#f59e0b', editable: false,
            classNames: ['border-dashed', 'border-2'], extendedProps: { kind: 'open', shift: s },
          })
        }
      }
    }
    return out
  }, [cal.data, shiftsById, showOpen, employee])

  const onDrop = async (info) => {
    const { assignment, shift } = info.event.extendedProps
    const newStart = info.event.start.getTime()
    const target = (cal.data?.shifts || []).find((s) => s.department_id === shift.department_id && new Date(s.start).getTime() === newStart)
    if (!target) {
      info.revert()
      toast.error('Drop the assignment onto an existing shift slot', { description: 'Shifts follow the department configuration; there is no shift starting at that time.' })
      return
    }
    try {
      await api.patch(`/assignments/${assignment.id}/move`, { target_shift_id: target.id })
      toast.success('Assignment moved', { description: `${assignment.employee?.full_name} → ${target.name}, ${fmtDate(target.start, { weekday: 'short', day: 'numeric' })}. Validated by the backend.` })
      cal.reload({ silent: true })
    } catch (err) {
      info.revert()
      setConflict({ err, assignment, target })
    }
  }

  const publishToggle = async (s) => {
    try {
      await api.post(`/schedules/${s.id}/${s.status === 'draft' ? 'publish' : 'unpublish'}`)
      toast.success(s.status === 'draft' ? 'Schedule published; employees notified' : 'Schedule moved back to draft')
      schedules.reload({ silent: true }); cal.reload({ silent: true })
    } catch (err) { toast.error(errorMessage(err)) }
  }

  return (
    <>
      <PageHeader icon={CalendarRange} eyebrow="Scheduling" title="Shift Planner"
        description="Drag an assignment to another shift to move it. Every change is validated by the backend before it is saved; invalid moves are reverted with an explanation."
        actions={<Button variant="outline" onClick={() => { cal.reload(); schedules.reload() }}><RefreshCw /> Refresh</Button>} />
      <div className="grid gap-4 2xl:grid-cols-[1fr_340px]">
        <Card className="p-4">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <NativeSelect className="w-48" value={dept} onChange={(e) => { setDept(e.target.value); setEmployee('') }} aria-label="Department">
              <option value="">All departments</option>
              {(depts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </NativeSelect>
            <NativeSelect className="w-52" value={employee} onChange={(e) => setEmployee(e.target.value)} aria-label="Employee">
              <option value="">All employees</option>
              {(emps.data?.items || []).map((e) => <option key={e.id} value={e.id}>{e.full_name}</option>)}
            </NativeSelect>
            <label className="ml-1 flex items-center gap-2 text-xs text-muted-foreground"><Switch checked={showOpen} onCheckedChange={setShowOpen} /> Show open slots</label>
            <div className="ml-auto flex flex-wrap items-center gap-3 text-[11px] text-muted-foreground">
              {Object.entries(SHIFT_COLORS).map(([k, v]) => <span key={k} className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-sm" style={{ background: v.bg }} />{v.label}</span>)}
              <span className="flex items-center gap-1"><span className="h-2.5 w-2.5 rounded-sm border-2 border-dashed border-amber-500" />Open slot</span>
            </div>
          </div>
          {cal.error && <ErrorState error={cal.error} onRetry={cal.reload} className="mb-4" />}
          <div className="relative">
            {cal.loading && !cal.data && <Skeleton className="absolute inset-0 z-10 h-full" />}
            <FullCalendar
              ref={calRef}
              plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
              initialView="timeGridWeek"
              headerToolbar={{ left: 'prev,next today', center: 'title', right: 'timeGridDay,timeGridWeek,dayGridMonth' }}
              firstDay={1} height="auto" slotMinTime="00:00:00" slotMaxTime="24:00:00" expandRows nowIndicator
              slotDuration="01:00:00" allDaySlot={false} eventTimeFormat={{ hour: '2-digit', minute: '2-digit', hour12: false }}
              slotLabelFormat={{ hour: '2-digit', minute: '2-digit', hour12: false }}
              events={events} datesSet={onDatesSet} eventDrop={onDrop} editable eventDurationEditable={false} eventOverlap
              dayMaxEvents={4}
              eventClick={(info) => {
                const p = info.event.extendedProps
                if (p.kind === 'open') setSelShift(p.shift)
                else setSelAssign({ assignment: p.assignment, shift: p.shift })
              }}
              eventContent={(arg) => {
                const p = arg.event.extendedProps
                return (
                  <div className="overflow-hidden px-0.5 leading-tight">
                    <p className="truncate text-[11px] font-semibold">{p.assignment?.locked && <Lock className="mr-0.5 inline h-2.5 w-2.5" />}{arg.event.title}</p>
                    {p.kind === 'assignment' && arg.view.type !== 'dayGridMonth' && <p className="truncate text-[10px] opacity-80">{p.shift.department?.code} · {p.shift.name}</p>}
                  </div>
                )
              }}
            />
          </div>
        </Card>

        <div className="space-y-4">
          <Card className="p-4">
            <p className="mb-3 text-sm font-semibold">Schedules in view</p>
            {schedules.loading ? <Skeleton className="h-24" /> : visibleSchedules.length === 0 ? <EmptyState title="No schedules for this period" description="Create one in the AI Schedule Generator." className="py-6" action={<Button size="sm" onClick={() => navigate('/generator')}>Open generator</Button>} /> : (
              <div className="space-y-2">
                {visibleSchedules.map((s) => (
                  <div key={s.id} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between"><p className="text-[13px] font-medium">{s.department?.name}</p><StatusBadge status={s.status} /></div>
                    <p className="num mt-0.5 text-[11px] text-muted-foreground">{fmtDate(s.start_date)} – {fmtDate(s.end_date)} · {s.filled_slots}/{s.required_slots} filled</p>
                    <div className="mt-2 flex gap-1.5">
                      <Button size="sm" variant={s.status === 'draft' ? 'default' : 'outline'} onClick={() => setPublishing(s)}>{s.status === 'draft' ? <><Send /> Publish</> : <><Undo2 /> Unpublish</>}</Button>
                      <ConflictButton schedule={s} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
          <Card className="p-4 text-xs text-muted-foreground">
            <p className="mb-2 text-sm font-semibold text-foreground">How editing works</p>
            <ul className="list-disc space-y-1 pl-4">
              <li>Click an open slot to see ranked eligible staff and assign manually or automatically.</li>
              <li>Click an assignment to see why the employee was assigned, lock it, remove it or mark them absent.</li>
              <li>Drag an assignment to a different day or shift time. The backend rechecks availability, rest, hours and qualifications.</li>
            </ul>
          </Card>
        </div>
      </div>

      <ShiftDialog open={Boolean(selShift)} onOpenChange={(o) => !o && setSelShift(null)} shift={selShift ? shiftsById[selShift.id] || selShift : null}
        assignments={cal.data?.assignments || []} onChanged={() => { cal.reload({ silent: true }); schedules.reload({ silent: true }) }} />
      <AssignmentDialog open={Boolean(selAssign)} onOpenChange={(o) => !o && setSelAssign(null)} assignment={selAssign?.assignment} shift={selAssign?.shift} canManage
        onChanged={() => { cal.reload({ silent: true }); schedules.reload({ silent: true }) }} />
      <Dialog open={Boolean(conflict)} onOpenChange={(o) => !o && setConflict(null)}>
        <DialogContent size="md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-destructive"><ShieldAlert className="h-5 w-5" /> Move rejected by conflict detection</DialogTitle>
            <DialogDescription>{conflict?.assignment.employee?.full_name} cannot be moved to {conflict?.target.name} on {conflict && fmtDate(conflict.target.start, { weekday: 'long', day: 'numeric', month: 'short' })}. The schedule was not changed.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            {(conflict?.err.details?.failed || []).map((f) => (
              <div key={f.code} className="flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" /><div><p className="font-medium capitalize">{f.code.replace('_', ' ')}</p><p className="text-xs text-muted-foreground">{f.message}</p></div></div>
            ))}
            {!conflict?.err.details?.failed && <p className="text-sm">{conflict && errorMessage(conflict.err)}</p>}
          </div>
          <DialogFooter><Button onClick={() => setConflict(null)}>Understood</Button></DialogFooter>
        </DialogContent>
      </Dialog>
      <ConfirmDialog open={Boolean(publishing)} onOpenChange={(o) => !o && setPublishing(null)}
        title={publishing?.status === 'draft' ? `Publish ${publishing?.department?.name} schedule?` : 'Move schedule back to draft?'}
        description={publishing?.status === 'draft' ? 'Assigned employees will be notified and can see their shifts.' : 'Employees will no longer see this schedule until it is published again.'}
        confirmLabel={publishing?.status === 'draft' ? 'Publish' : 'Unpublish'} onConfirm={() => publishToggle(publishing)} />
    </>
  )
}

function ConflictButton({ schedule }) {
  const [open, setOpen] = useState(false)
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const run = async () => {
    setOpen(true); setData(null); setError(null)
    try { setData((await api.get(`/schedules/${schedule.id}/conflicts`)).data) } catch (e) { setError(e) }
  }
  return (
    <>
      <Button size="sm" variant="outline" onClick={run}><ShieldAlert /> Conflicts</Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent size="lg">
          <DialogHeader>
            <DialogTitle>Conflict resolution · {schedule.department?.name}</DialogTitle>
            <DialogDescription>Independent verifier output for {fmtDate(schedule.start_date)} – {fmtDate(schedule.end_date)}.</DialogDescription>
          </DialogHeader>
          {error && <ErrorState error={error} onRetry={run} />}
          {!data && !error && <Skeleton className="h-40" />}
          {data && (data.total === 0 ? (
            <div className="flex items-center gap-2 rounded-lg border border-success/30 bg-success/5 p-4 text-sm text-success"><CheckCircle2 className="h-5 w-5" /> No conflicts. Every assignment satisfies every hard constraint and all shifts are fully staffed.</div>
          ) : (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-1.5">{Object.entries(data.summary).map(([k, v]) => <Badge key={k} variant="secondary" className="capitalize">{k.replace('_', ' ')} <span className="num">{v}</span></Badge>)}</div>
              <div className="max-h-[50vh] space-y-2 overflow-y-auto pr-1">
                {data.conflicts.map((c, i) => (
                  <div key={i} className="rounded-lg border p-3">
                    <div className="flex items-center justify-between gap-2"><p className="text-sm font-medium capitalize">{c.type.replace(/_/g, ' ')}</p><StatusBadge status={c.severity} /></div>
                    <p className="mt-1 text-xs">{c.message}</p>
                    <p className="mt-1 text-xs text-muted-foreground">Affected: {c.employee_name || 'Shift staffing'}{c.shift_label ? ` · ${c.shift_label}` : ''}</p>
                    <p className="mt-1.5 text-xs text-primary">Suggested resolution: {c.suggestion}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </DialogContent>
      </Dialog>
    </>
  )
}

function EmployeeCalendar() {
  const navigate = useNavigate()
  const { lastEvent } = useNotifications()
  const [range, onDatesSet] = useCalendarRange()
  const [sel, setSel] = useState(null)
  const cal = useApi('/calendar', { params: range || {}, enabled: Boolean(range) })
  useEffect(() => { if (lastEvent) cal.reload({ silent: true }) }, [lastEvent]) // eslint-disable-line react-hooks/exhaustive-deps
  const events = (cal.data?.assignments || []).map((a) => {
    const c = SHIFT_COLORS[a.shift?.template_code] || { bg: '#6366f1' }
    return { id: a.id, start: a.start, end: a.end, title: `${a.shift?.name} · ${a.department?.name}`, backgroundColor: a.status === 'absent' ? 'rgba(244,63,94,0.2)' : c.bg, borderColor: c.bg, extendedProps: { a } }
  })
  return (
    <>
      <PageHeader icon={CalendarRange} eyebrow="My schedule" title="My Schedule" description="Only your shifts from published schedules are shown." />
      <Card className="p-4">
        {cal.error && <ErrorState error={cal.error} onRetry={cal.reload} />}
        <FullCalendar plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]} initialView="timeGridWeek" firstDay={1} height="auto" allDaySlot={false}
          headerToolbar={{ left: 'prev,next today', center: 'title', right: 'timeGridWeek,dayGridMonth' }} nowIndicator
          slotLabelFormat={{ hour: '2-digit', minute: '2-digit', hour12: false }} eventTimeFormat={{ hour: '2-digit', minute: '2-digit', hour12: false }}
          events={events} datesSet={onDatesSet} eventClick={(i) => setSel(i.event.extendedProps.a)} />
      </Card>
      <Dialog open={Boolean(sel)} onOpenChange={(o) => !o && setSel(null)}>
        <DialogContent size="sm">
          {sel && <>
            <DialogHeader>
              <DialogTitle>{sel.shift?.name} shift · {sel.department?.name}</DialogTitle>
              <DialogDescription>{fmtDate(sel.start, { weekday: 'long', day: 'numeric', month: 'long' })} · {fmtTime(sel.start)}–{fmtTime(sel.end)}</DialogDescription>
            </DialogHeader>
            <div className="flex gap-1.5"><StatusBadge status={sel.status} /><Badge variant="secondary" className="capitalize">{sel.source}</Badge></div>
            <DialogFooter>
              {sel.status === 'active' && new Date(sel.start) > new Date() && <Button onClick={() => navigate(`/swaps?assignment=${sel.id}`)}><Repeat2 /> Request swap</Button>}
            </DialogFooter>
          </>}
        </DialogContent>
      </Dialog>
    </>
  )
}

