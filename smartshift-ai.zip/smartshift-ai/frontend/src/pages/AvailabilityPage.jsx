import { useEffect, useMemo, useState } from 'react'
import { toast } from 'sonner'
import { CalendarClock, Plus, Save, Trash2, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Card, CardContent, CardHeader, CardTitle, Checkbox, Field, Input, NativeSelect, Skeleton, Textarea } from '@/components/ui/primitives'
import { EmptyState, ErrorState, PageHeader } from '@/components/common'
import { useApi } from '@/hooks/useApi'
import { useAuth } from '@/contexts/AuthContext'
import { api, errorMessage } from '@/services/api'
import { addDays, fmtDate, isoDate, WEEKDAYS } from '@/utils/format'
import { cn } from '@/utils/cn'

const PRESETS = {
  day: [{ start: '07:00', end: '23:00' }],
  full: [{ start: '07:00', end: '23:00' }, { start: '23:00', end: '07:00' }],
  morning: [{ start: '07:00', end: '15:00' }],
  night: [{ start: '23:00', end: '07:00' }],
}

export default function AvailabilityPage() {
  const { isManager, user } = useAuth()
  const [tab, setTab] = useState(isManager ? 'team' : 'mine')
  return (
    <>
      <PageHeader icon={CalendarClock} eyebrow="Availability" title="Availability and preferences"
        description="Recurring time windows, blocked dates and shift preferences. The optimizer treats windows and blocked dates as hard constraints and preferences as soft goals."
        actions={isManager && user.employee_id == null ? null : isManager && (
          <div className="flex gap-1 rounded-lg bg-secondary p-1">{['team', 'mine'].map((t) => <Button key={t} size="sm" variant={tab === t ? 'default' : 'ghost'} onClick={() => setTab(t)}>{t === 'team' ? 'Team view' : 'My availability'}</Button>)}</div>
        )} />
      {isManager && tab === 'team' ? <TeamAvailability /> : <AvailabilityEditor />}
    </>
  )
}

export function AvailabilityEditor({ employeeId }) {
  const { data, error, loading, reload } = useApi('/availability', { params: employeeId ? { employee_id: employeeId } : undefined })
  const [form, setForm] = useState(null)
  const [newDate, setNewDate] = useState('')
  const [busy, setBusy] = useState(false)
  useEffect(() => { if (data) setForm({ recurring: data.recurring || [], unavailable_dates: data.unavailable_dates || [], preferred_shifts: data.preferred_shifts || [], preferred_days_off: data.preferred_days_off || [], notes: data.notes || '' }) }, [data])
  if (error) return <ErrorState error={error} onRetry={reload} />
  if (loading || !form) return <Skeleton className="h-96" />
  const windowsFor = (d) => form.recurring.map((r, i) => ({ ...r, i })).filter((r) => r.weekday === d)
  const setDay = (d, windows) => setForm((f) => ({ ...f, recurring: [...f.recurring.filter((r) => r.weekday !== d), ...windows.map((w) => ({ weekday: d, ...w }))] }))
  const updateWindow = (i, k, v) => setForm((f) => ({ ...f, recurring: f.recurring.map((r, j) => (j === i ? { ...r, [k]: v } : r)) }))
  const toggle = (k, v) => setForm((f) => ({ ...f, [k]: f[k].includes(v) ? f[k].filter((x) => x !== v) : [...f[k], v] }))
  const save = async () => {
    for (const r of form.recurring) if (!/^\d\d:\d\d$/.test(r.start) || !/^\d\d:\d\d$/.test(r.end)) { toast.error('Each window needs a start and end time'); return }
    setBusy(true)
    try {
      await api.put('/availability', form, { params: employeeId ? { employee_id: employeeId } : undefined })
      toast.success('Availability saved', { description: 'Future optimizations will use these windows and preferences.' })
      reload({ silent: true })
    } catch (e) { toast.error(errorMessage(e)) } finally { setBusy(false) }
  }
  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
      <Card>
        <CardHeader><CardTitle>Weekly recurring availability</CardTitle><p className="text-xs text-muted-foreground">A window ending earlier than it starts runs overnight (e.g. 23:00–07:00).</p></CardHeader>
        <CardContent className="space-y-2">
          {WEEKDAYS.map((d, wd) => (
            <div key={d} className="flex flex-col gap-2 rounded-lg border p-3 sm:flex-row sm:items-center">
              <p className="w-12 text-sm font-semibold">{d}</p>
              <div className="flex flex-1 flex-wrap items-center gap-2">
                {windowsFor(wd).length === 0 && <Badge variant="secondary">Unavailable</Badge>}
                {windowsFor(wd).map((w) => (
                  <div key={w.i} className="flex items-center gap-1 rounded-lg bg-secondary/60 px-2 py-1">
                    <Input type="time" value={w.start} onChange={(e) => updateWindow(w.i, 'start', e.target.value)} className="h-7 w-24 border-0 bg-transparent px-1 shadow-none" aria-label={`${d} start`} />
                    <span className="text-muted-foreground">–</span>
                    <Input type="time" value={w.end} onChange={(e) => updateWindow(w.i, 'end', e.target.value)} className="h-7 w-24 border-0 bg-transparent px-1 shadow-none" aria-label={`${d} end`} />
                    <Button variant="ghost" size="icon-sm" className="h-6 w-6" onClick={() => setForm((f) => ({ ...f, recurring: f.recurring.filter((_, j) => j !== w.i) }))} aria-label="Remove window"><X /></Button>
                  </div>
                ))}
              </div>
              <div className="flex flex-wrap gap-1">
                {Object.keys(PRESETS).map((p) => <Button key={p} size="sm" variant="ghost" className="h-7 px-2 text-[11px] capitalize" onClick={() => setDay(wd, PRESETS[p])}>{p}</Button>)}
                <Button size="sm" variant="ghost" className="h-7 px-2 text-[11px]" onClick={() => setDay(wd, [])}>Off</Button>
                <Button size="icon-sm" variant="outline" className="h-7 w-7" onClick={() => setForm((f) => ({ ...f, recurring: [...f.recurring, { weekday: wd, start: '09:00', end: '17:00' }] }))} aria-label="Add window"><Plus /></Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
      <div className="space-y-4">
        <Card>
          <CardHeader><CardTitle>Preferences</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <Field label="Preferred shifts">
              <div className="flex gap-3 pt-1">{['morning', 'evening', 'night'].map((c) => <label key={c} className="flex items-center gap-1.5 text-sm capitalize"><Checkbox checked={form.preferred_shifts.includes(c)} onCheckedChange={() => toggle('preferred_shifts', c)} />{c}</label>)}</div>
            </Field>
            <Field label="Preferred days off">
              <div className="flex flex-wrap gap-1.5 pt-1">{WEEKDAYS.map((d, i) => (
                <button key={d} type="button" onClick={() => toggle('preferred_days_off', i)} className={cn('rounded-md border px-2.5 py-1 text-xs transition', form.preferred_days_off.includes(i) ? 'border-primary bg-primary/15 text-foreground' : 'text-muted-foreground hover:bg-secondary')}>{d}</button>
              ))}</div>
            </Field>
            <Field label="Notes for your manager"><Textarea rows={2} value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} /></Field>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Unavailable dates</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="flex gap-2">
              <Input type="date" value={newDate} min={isoDate(new Date())} onChange={(e) => setNewDate(e.target.value)} />
              <Button variant="outline" disabled={!newDate} onClick={() => { if (!form.unavailable_dates.includes(newDate)) setForm((f) => ({ ...f, unavailable_dates: [...f.unavailable_dates, newDate].sort() })); setNewDate('') }}>Add</Button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {form.unavailable_dates.length === 0 && <p className="text-xs text-muted-foreground">No blocked dates.</p>}
              {form.unavailable_dates.map((d) => <Badge key={d} variant="warning" className="gap-1.5">{fmtDate(d, { weekday: 'short', day: 'numeric', month: 'short' })}<button onClick={() => setForm((f) => ({ ...f, unavailable_dates: f.unavailable_dates.filter((x) => x !== d) }))} aria-label="Remove date"><Trash2 className="h-3 w-3" /></button></Badge>)}
            </div>
          </CardContent>
        </Card>
        <Button className="w-full" size="lg" onClick={save} loading={busy}><Save /> Save availability</Button>
      </div>
    </div>
  )
}

function TeamAvailability() {
  const depts = useApi('/departments')
  const [dept, setDept] = useState('')
  useEffect(() => { if (!dept && depts.data?.length) setDept(depts.data[0].id) }, [depts.data, dept])
  const [start, setStart] = useState(isoDate(new Date()))
  const { data, error, loading, reload } = useApi('/availability/team', { params: { department_id: dept, start, days: 14 }, enabled: Boolean(dept) })
  const days = useMemo(() => Array.from({ length: 14 }, (_, i) => addDays(new Date(`${start}T00:00:00`), i)), [start])
  const status = (e, d) => {
    const iso = isoDate(d)
    if (e.leave.some((l) => l.start_date <= iso && l.end_date >= iso)) return { label: 'Leave', cls: 'bg-violet-500/25 text-violet-700 dark:text-violet-300' }
    if ((e.availability?.unavailable_dates || []).includes(iso)) return { label: 'Blocked', cls: 'bg-rose-500/25 text-rose-700 dark:text-rose-300' }
    const wd = (d.getDay() + 6) % 7
    const w = (e.availability?.recurring || []).filter((r) => r.weekday === wd)
    if (!w.length) return { label: 'Off', cls: 'bg-muted text-muted-foreground' }
    if (w.some((x) => x.start === '23:00' || x.end < x.start)) return { label: '24h', cls: 'bg-emerald-500/25 text-emerald-700 dark:text-emerald-300' }
    return { label: 'Day', cls: 'bg-sky-500/25 text-sky-700 dark:text-sky-300' }
  }
  return (
    <Card className="p-4">
      <div className="mb-4 flex flex-wrap gap-2">
        <NativeSelect className="w-52" value={dept} onChange={(e) => setDept(e.target.value)}>{(depts.data || []).map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</NativeSelect>
        <Input type="date" className="w-44" value={start} onChange={(e) => setStart(e.target.value)} />
        <div className="ml-auto flex flex-wrap items-center gap-2 text-[11px]">
          {[['Day', 'bg-sky-500/25'], ['24h', 'bg-emerald-500/25'], ['Leave', 'bg-violet-500/25'], ['Blocked', 'bg-rose-500/25'], ['Off', 'bg-muted']].map(([l, c]) => <span key={l} className="flex items-center gap-1"><span className={cn('h-2.5 w-2.5 rounded-sm', c)} />{l}</span>)}
        </div>
      </div>
      {error ? <ErrorState error={error} onRetry={reload} /> : loading || !data ? <Skeleton className="h-96" /> : data.employees.length === 0 ? <EmptyState title="No employees in this department" /> : (
        <div className="overflow-x-auto">
          <table className="w-full border-separate text-xs" style={{ borderSpacing: 3 }}>
            <thead><tr><th className="sticky left-0 bg-card text-left font-medium text-muted-foreground">Employee</th>{days.map((d) => <th key={d} className="min-w-[52px] text-center font-medium text-muted-foreground">{fmtDate(isoDate(d), { weekday: 'short' })}<br /><span className="num">{d.getDate()}</span></th>)}<th className="text-left font-medium text-muted-foreground">Prefers</th></tr></thead>
            <tbody>
              {data.employees.map((e) => (
                <tr key={e.id}>
                  <td className="sticky left-0 whitespace-nowrap bg-card pr-3"><p className="font-medium">{e.full_name}</p><p className="text-[10px] text-muted-foreground">{e.job_role}</p></td>
                  {days.map((d) => { const s = status(e, d); return <td key={d}><div className={cn('rounded-md py-1.5 text-center text-[10px] font-semibold', s.cls)}>{s.label}</div></td> })}
                  <td className="whitespace-nowrap pl-2 capitalize text-muted-foreground">{(e.availability?.preferred_shifts || []).join(', ') || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  )
}
