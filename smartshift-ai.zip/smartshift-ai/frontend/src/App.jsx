import { lazy, Suspense } from 'react'
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { Toaster } from 'sonner'
import { Loader2 } from 'lucide-react'
import { AuthProvider, useAuth } from '@/contexts/AuthContext'
import { ThemeProvider, useTheme } from '@/contexts/ThemeContext'
import { NotificationProvider } from '@/contexts/NotificationContext'
import { TooltipProvider } from '@/components/ui/primitives'
import AppLayout from '@/layouts/AppLayout'
import LoginPage from '@/pages/LoginPage'

const OverviewPage = lazy(() => import('@/pages/OverviewPage'))
const EmployeesPage = lazy(() => import('@/pages/EmployeesPage'))
const EmployeeProfilePage = lazy(() => import('@/pages/EmployeeProfilePage'))
const DepartmentsPage = lazy(() => import('@/pages/DepartmentsPage'))
const PlannerPage = lazy(() => import('@/pages/PlannerPage'))
const GeneratorPage = lazy(() => import('@/pages/GeneratorPage'))
const AvailabilityPage = lazy(() => import('@/pages/AvailabilityPage'))
const LeavePage = lazy(() => import('@/pages/LeavePage'))
const SwapsPage = lazy(() => import('@/pages/SwapsPage'))
const EmergencyPage = lazy(() => import('@/pages/EmergencyPage'))
const AnalyticsPage = lazy(() => import('@/pages/AnalyticsPage'))
const NotificationsPage = lazy(() => import('@/pages/NotificationsPage'))
const AuditPage = lazy(() => import('@/pages/AuditPage'))
const SettingsPage = lazy(() => import('@/pages/SettingsPage'))

function Spinner() {
  return <div className="flex h-[60vh] items-center justify-center"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
}

function Protected({ roles, children }) {
  const { user, ready } = useAuth()
  const location = useLocation()
  if (!ready) return <Spinner />
  if (!user) return <Navigate to="/login" replace state={{ from: location.pathname }} />
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />
  return children
}

const MANAGERS = ['super_admin', 'manager']

function ThemedToaster() {
  const { theme } = useTheme()
  return <Toaster theme={theme} position="bottom-right" richColors closeButton />
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <NotificationProvider>
          <TooltipProvider>
            <BrowserRouter>
              <Routes>
                <Route path="/login" element={<LoginPage />} />
                <Route element={<Protected><AppLayout /></Protected>}>
                  <Route path="/" element={<Suspense fallback={<Spinner />}><OverviewPage /></Suspense>} />
                  <Route path="/employees" element={<Protected roles={MANAGERS}><Suspense fallback={<Spinner />}><EmployeesPage /></Suspense></Protected>} />
                  <Route path="/employees/:id" element={<Suspense fallback={<Spinner />}><EmployeeProfilePage /></Suspense>} />
                  <Route path="/departments" element={<Protected roles={MANAGERS}><Suspense fallback={<Spinner />}><DepartmentsPage /></Suspense></Protected>} />
                  <Route path="/planner" element={<Suspense fallback={<Spinner />}><PlannerPage /></Suspense>} />
                  <Route path="/generator" element={<Protected roles={MANAGERS}><Suspense fallback={<Spinner />}><GeneratorPage /></Suspense></Protected>} />
                  <Route path="/availability" element={<Suspense fallback={<Spinner />}><AvailabilityPage /></Suspense>} />
                  <Route path="/leave" element={<Suspense fallback={<Spinner />}><LeavePage /></Suspense>} />
                  <Route path="/swaps" element={<Suspense fallback={<Spinner />}><SwapsPage /></Suspense>} />
                  <Route path="/emergency" element={<Protected roles={MANAGERS}><Suspense fallback={<Spinner />}><EmergencyPage /></Suspense></Protected>} />
                  <Route path="/analytics" element={<Protected roles={MANAGERS}><Suspense fallback={<Spinner />}><AnalyticsPage /></Suspense></Protected>} />
                  <Route path="/notifications" element={<Suspense fallback={<Spinner />}><NotificationsPage /></Suspense>} />
                  <Route path="/audit" element={<Protected roles={MANAGERS}><Suspense fallback={<Spinner />}><AuditPage /></Suspense></Protected>} />
                  <Route path="/settings" element={<Suspense fallback={<Spinner />}><SettingsPage /></Suspense>} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Route>
              </Routes>
            </BrowserRouter>
            <ThemedToaster />
          </TooltipProvider>
        </NotificationProvider>
      </AuthProvider>
    </ThemeProvider>
  )
}
