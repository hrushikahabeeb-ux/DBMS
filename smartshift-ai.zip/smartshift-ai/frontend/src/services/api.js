import axios from 'axios'

const TOKEN_KEY = 'smartshift.token'

export const tokenStore = {
  get: () => { try { return localStorage.getItem(TOKEN_KEY) } catch { return null } },
  set: (t) => { try { localStorage.setItem(TOKEN_KEY, t) } catch { /* storage unavailable */ } },
  clear: () => { try { localStorage.removeItem(TOKEN_KEY) } catch { /* storage unavailable */ } },
}

export const api = axios.create({ baseURL: '/api', timeout: 60000 })
export const notifyApi = axios.create({ baseURL: '/notify', timeout: 15000 })

for (const inst of [api, notifyApi]) {
  inst.interceptors.request.use((config) => {
    const t = tokenStore.get()
    if (t) config.headers.Authorization = `Bearer ${t}`
    return config
  })
  inst.interceptors.response.use(
    (r) => r,
    (error) => {
      const status = error.response?.status
      const body = error.response?.data?.error
      const normalized = {
        status,
        code: body?.code || (status ? 'http_error' : 'network_error'),
        message: body?.message || (status ? `Request failed (${status})` : 'Cannot reach the server. Check that the backend services are running.'),
        details: body?.details,
        correlationId: body?.correlation_id,
      }
      if (status === 401 && !error.config.url.includes('/auth/login')) {
        tokenStore.clear()
        window.dispatchEvent(new Event('smartshift:logout'))
      }
      return Promise.reject(normalized)
    },
  )
}

export function errorMessage(err) {
  if (!err) return ''
  if (err.details?.failed?.length) return `${err.message}: ${err.details.failed.map((f) => f.message).join('; ')}`
  if (err.details?.reasons?.length) return `${err.message}: ${err.details.reasons.join('; ')}`
  if (Array.isArray(err.details) && err.details[0]?.field) return `${err.message}: ${err.details.map((d) => `${d.field} ${d.message}`).join('; ')}`
  return err.message || String(err)
}

export function fieldErrors(err) {
  if (!Array.isArray(err?.details)) return {}
  return Object.fromEntries(err.details.filter((d) => d.field).map((d) => [d.field, d.message]))
}

export function wsUrl(token) {
  const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
  return `${proto}://${window.location.host}/notify/ws?token=${encodeURIComponent(token)}`
}
