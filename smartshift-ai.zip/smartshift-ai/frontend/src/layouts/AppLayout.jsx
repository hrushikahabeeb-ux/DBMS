import { useEffect, useMemo, useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity, BarChart3, Bell, Building2, CalendarClock, CalendarRange, ChevronsLeft, ChevronsRight, ClipboardList,
  LayoutDashboard, LogOut, Menu, Moon, Plane, Repeat2, Search, Settings, Siren, Sparkles, Sun, Users, Wifi, WifiOff,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge, Input, Popover, PopoverContent, PopoverTrigger, Tooltip } from '@/components/ui/primitives'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/overlay'
import { Avatar } from '@/components/common'
import { useAuth } from '@/contexts/AuthContext'
import { useTheme } from '@/contexts/ThemeContext'
import { useNotifications } from '@/contexts/NotificationContext'
import { cn } from '@/utils/cn'
import { ROLE_LABELS, relativeTime } from '@/utils/format'

const NAV = [
  { to: '/', label: 'Overview', icon: LayoutDashboard, roles: ['super_admin', 'manager', 'employee'] },
  { to: '/employees', label: 'Employees', icon: Users, roles: ['super_admin', 'manager'] },
  { to: '/departments', label: 'Departments', icon: Building2, roles: ['super_admin', 'manager'] },
  { to: '/planner', label: 'Shift Planner', icon: CalendarRange, roles: ['super_admin', 'manager', 'employee'], employeeLabel: 'My Schedule' },
  { to: '/generator', label: 'AI Schedule Generator', icon: Sparkles, roles: ['super_admin', 'manager'] },
  { to: '/availability', label: 'Availability', icon: CalendarClock, roles: ['super_admin', 'manager', 'employee'] },
  { to: '/leave', label: 'Leave Management', icon: Plane, roles: ['super_admin', 'manager', 'employee'] },
  { to: '/swaps', label: 'Shift Swaps', icon: Repeat2, roles: ['super_admin', 'manager', 'employee'] },
  { to: '/emergency', label: 'Emergency Replacement', icon: Siren, roles: ['super_admin', 'manager'] },
  { to: '/analytics', label: 'Workforce Analytics', icon: BarChart3, roles: ['super_admin', 'manager'] },
  { to: '/notifications', label: 'Notifications', icon: Bell, roles: ['super_admin', 'manager', 'employee'] },
  { to: '/audit', label: 'Audit Logs', icon: ClipboardList, roles: ['super_admin', 'manager'] },
  { to: '/settings', label: 'Settings', icon: Settings, roles: ['super_admin', 'manager', 'employee'] },
]

function Brand({ collapsed }) {
  return (
    <div className="flex h-16 items-center gap-2.5 px-4">
      <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-glow">
        <Activity className="h-5 w-5 text-white" />
      </div>
      {!collapsed && (
        <div className="leading-tight">
          <p className="text-sm font-bold tracking-tight">SmartShift <span className="text-gradient">AI</span></p>
          <p className="text-[10px] text-muted-foreground">Workforce Intelligence</p>
        </div>
      )}
    </div>
  )
}

function SidebarNav({ collapsed, onNavigate }) {
  const { user } = useAuth()
  const { unread } = useNotifications()
  const items = NAV.filter((n) => n.roles.includes(user.role))
  return (
    <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-2" aria-label="Main">
      {items.map((n) => {
        const label = user.role === 'employee' && n.employeeLabel ? n.employeeLabel : n.label
        const link = (
          <NavLink key={n.to} to={n.to} end={n.to === '/'} onClick={onNavigate}
            className={({ isActive }) => cn(
              'group relative flex items-center gap-3 rounded-lg px-3 py-2 text-[13px] font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground',
              isActive && 'bg-primary/10 text-foreground',
              collapsed && 'justify-center px-0',
            )}>
            {({ isActive }) => (
              <>
                {isActive && <motion.span layoutId="nav-active" className="absolute inset-y-1.5 left-0 w-[3px] rounded-r-full bg-gradient-to-b from-indigo-400 to-violet-500" />}
                <n.icon className={cn('h-[18px] w-[18px] shrink-0', isActive && 'text-primary')} />
                {!collapsed && <span className="truncate">{label}</span>}
                {n.to === '/notifications' && unread > 0 && (
                  <span className={cn('num ml-auto rounded-full bg-primary px-1.5 text-[10px] font-semibold text-primary-foreground', collapsed && 'absolute right-1 top-1')}>{unread > 99 ? '99+' : unread}</span>
                )}
              </>
            )}
          </NavLink>
        )
        return collapsed ? <Tooltip key={n.to} content={label} side="right">{link}</Tooltip> : link
      })}
    </nav>
  )
}

function NotificationBell() {
  const { items, unread, markAll, markRead, connected } = useNotifications()
  const navigate = useNavigate()
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label={`Notifications, ${unread} unread`}>
          <Bell />
          {unread > 0 && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-fuchsia-500 ring-2 ring-background" />}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold">Notifications</p>
            {connected ? <Badge variant="success"><Wifi className="h-3 w-3" /> Live</Badge> : <Badge variant="secondary"><WifiOff className="h-3 w-3" /> Offline</Badge>}
          </div>
          <Button variant="link" size="sm" className="h-auto p-0 text-xs" onClick={markAll} disabled={!unread}>Mark all read</Button>
        </div>
        <div className="max-h-96 overflow-y-auto">
          {items.length === 0 && <p className="p-6 text-center text-xs text-muted-foreground">You are all caught up.</p>}
          {items.slice(0, 8).map((n) => (
            <button key={n.id} onClick={() => !n.read && markRead(n.id)} className={cn('flex w-full gap-3 border-b px-4 py-3 text-left transition hover:bg-secondary/60', !n.read && 'bg-primary/5')}>
              <span className={cn('mt-1.5 h-2 w-2 shrink-0 rounded-full', n.read ? 'bg-transparent' : 'bg-primary')} />
              <span className="min-w-0">
                <span className="block text-[13px] font-medium">{n.title}</span>
                <span className="block text-xs text-muted-foreground">{n.message}</span>
                <span className="mt-1 block text-[10px] text-muted-foreground">{relativeTime(n.created_at)}</span>
              </span>
            </button>
          ))}
        </div>
        <div className="p-2"><Button variant="ghost" size="sm" className="w-full" onClick={() => navigate('/notifications')}>View all</Button></div>
      </PopoverContent>
    </Popover>
  )
}

function GlobalSearch() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const pages = useMemo(() => NAV.filter((n) => n.roles.includes(user.role)), [user.role])
  const matches = q ? pages.filter((p) => p.label.toLowerCase().includes(q.toLowerCase())).slice(0, 5) : []
  const submit = (e) => {
    e.preventDefault()
    if (matches[0]) { navigate(matches[0].to); setQ(''); return }
    if (user.role !== 'employee' && q.trim()) { navigate(`/employees?search=${encodeURIComponent(q.trim())}`); setQ('') }
  }
  return (
    <form onSubmit={submit} className="relative hidden w-full max-w-sm md:block" role="search">
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={user.role === 'employee' ? 'Jump to a page...' : 'Search pages or employees...'} className="h-9 bg-secondary/50 pl-9" aria-label="Search" />
      {matches.length > 0 && (
        <div className="absolute left-0 right-0 top-11 z-40 rounded-xl border bg-popover p-1 shadow-xl">
          {matches.map((m) => (
            <button type="button" key={m.to} onClick={() => { navigate(m.to); setQ('') }} className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-secondary">
              <m.icon className="h-4 w-4 text-muted-foreground" /> {m.label}
            </button>
          ))}
          {user.role !== 'employee' && <p className="px-2 py-1 text-[11px] text-muted-foreground">Press Enter to search employees</p>}
        </div>
      )}
    </form>
  )
}

export default function AppLayout() {
  const { user, logout } = useAuth()
  const { theme, toggle } = useTheme()
  const [collapsed, setCollapsed] = useState(() => { try { return localStorage.getItem('smartshift.sidebar') === '1' } catch { return false } })
  const [mobile, setMobile] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()
  useEffect(() => { try { localStorage.setItem('smartshift.sidebar', collapsed ? '1' : '0') } catch { /* ignore */ } }, [collapsed])
  useEffect(() => setMobile(false), [location.pathname])

  return (
    <div className="flex h-full">
      <aside className={cn('sticky top-0 hidden h-screen shrink-0 flex-col border-r bg-surface/70 backdrop-blur-xl transition-[width] duration-300 lg:flex', collapsed ? 'w-[72px]' : 'w-64')}>
        <Brand collapsed={collapsed} />
        <SidebarNav collapsed={collapsed} />
        <div className="border-t p-3">
          <Button variant="ghost" size="sm" className={cn('w-full', collapsed ? 'justify-center' : 'justify-start')} onClick={() => setCollapsed((c) => !c)} aria-label="Toggle sidebar">
            {collapsed ? <ChevronsRight /> : <><ChevronsLeft /> Collapse</>}
          </Button>
        </div>
      </aside>

      <AnimatePresence>
        {mobile && (
          <motion.div className="fixed inset-0 z-50 lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <div className="absolute inset-0 bg-black/60" onClick={() => setMobile(false)} />
            <motion.aside initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }} transition={{ type: 'spring', damping: 30, stiffness: 300 }} className="absolute inset-y-0 left-0 flex w-64 flex-col border-r bg-surface">
              <Brand />
              <SidebarNav onNavigate={() => setMobile(false)} />
            </motion.aside>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/70 px-4 backdrop-blur-xl sm:px-6">
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobile(true)} aria-label="Open menu"><Menu /></Button>
          <GlobalSearch />
          <div className="ml-auto flex items-center gap-1">
            <Tooltip content={theme === 'dark' ? 'Light mode' : 'Dark mode'}>
              <Button variant="ghost" size="icon" onClick={toggle} aria-label="Toggle theme">{theme === 'dark' ? <Sun /> : <Moon />}</Button>
            </Tooltip>
            <NotificationBell />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="ml-1 flex items-center gap-2 rounded-lg p-1 pr-2 transition hover:bg-secondary focus:outline-none focus-visible:ring-2 focus-visible:ring-ring" aria-label="Profile menu">
                  <Avatar name={user.full_name} />
                  <span className="hidden text-left leading-tight sm:block">
                    <span className="block text-[13px] font-medium">{user.full_name}</span>
                    <span className="block text-[11px] text-muted-foreground">{ROLE_LABELS[user.role]}</span>
                  </span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuLabel>{user.email}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {user.employee_id && <DropdownMenuItem onSelect={() => navigate(`/employees/${user.employee_id}`)}><Users /> My profile</DropdownMenuItem>}
                <DropdownMenuItem onSelect={() => navigate('/settings')}><Settings /> Settings</DropdownMenuItem>
                <DropdownMenuItem onSelect={toggle}>{theme === 'dark' ? <Sun /> : <Moon />} Toggle theme</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => { logout(); navigate('/login') }} className="text-destructive focus:text-destructive"><LogOut /> Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <motion.div key={location.pathname} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25 }} className="mx-auto max-w-[1500px]">
            <Outlet />
          </motion.div>
        </main>
      </div>
    </div>
  )
}
